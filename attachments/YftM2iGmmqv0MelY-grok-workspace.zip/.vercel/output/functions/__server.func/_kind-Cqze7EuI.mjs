import { v as Link, x as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { b as KIND_META, i as Route$2, m as listKind, o as SearchBox, p as isKind, v as socialDirectory } from "./_ssr/router-3x6f2zop.mjs";
import { t as KIND_ICON } from "./_ssr/kind-mark-BDWQJV1X.mjs";
import { t as EntityCard } from "./_ssr/entity-card-GzSLAuZM.mjs";
import { n as LIVE_SOURCE_LINE } from "./_ssr/sources-Cj8xlN2Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_kind-Cqze7EuI.js
var import_jsx_runtime = require_jsx_runtime();
var LIVE_KINDS = /* @__PURE__ */ new Set([
	"performers",
	"productions",
	"companies"
]);
var LIVE_PLACEHOLDER = {
	performers: "Search a performer in the live databases…",
	productions: "Search a title in the live databases…",
	companies: "Search a studio or distributor…"
};
function BrowseKind() {
	const { kind } = Route$2.useParams();
	if (!isKind(kind)) return null;
	const meta = KIND_META[kind];
	const Icon = KIND_ICON[kind];
	if (kind === "social") {
		const rows = socialDirectory();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
			kicker: "Directory",
			title: meta.label,
			blurb: meta.blurb
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[32rem] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-[11px] uppercase tracking-[0.14em] text-subtle",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-4 font-medium",
								children: "Platform"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 pr-4 font-medium",
								children: "Handle"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Record"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border/80",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 pr-4 text-muted",
							children: row.platform
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3 pr-4 font-mono",
							children: row.handle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/$kind/$id",
								params: {
									kind: row.entity.kind,
									id: row.entity.id
								},
								className: "hover:text-accent",
								children: row.entity.name
							})
						})
					]
				}, `${row.entity.kind}-${row.entity.id}-${row.platform}-${row.handle}`)) })]
			})
		})] });
	}
	const list = listKind(kind);
	const upcoming = kind === "events" ? list.filter((e) => e.status === "Upcoming") : [];
	const rest = kind === "events" ? list.filter((e) => e.status !== "Upcoming") : list;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
			kicker: "Browse",
			title: meta.label,
			blurb: meta.blurb,
			count: list.length
		}),
		LIVE_KINDS.has(kind) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDeskBanner, { kind }),
		upcoming.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
				children: "Upcoming"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: upcoming.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityCard, { entity: e }, e.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: upcoming.length ? "mt-10" : "mt-8",
			children: [
				upcoming.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
					children: "Archive"
				}),
				LIVE_KINDS.has(kind) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
					children: "Desk roster"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-3 sm:grid-cols-2",
					children: rest.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityCard, { entity: e }, e.id))
				})
			]
		})
	] });
}
function LiveDeskBanner({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
				children: "Live databases"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 max-w-xl text-sm leading-relaxed text-muted",
				children: [
					"Search a name to query the public industry databases for ",
					kind === "performers" ? "performers" : kind === "productions" ? "titles" : "studios",
					". The roster below is the demonstration desk. Performers need a Wikidata birth year of 21+."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-[11px] uppercase tracking-[0.14em] text-subtle",
				children: LIVE_SOURCE_LINE
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 max-w-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBox, {
					size: "sm",
					kind,
					placeholder: LIVE_PLACEHOLDER[kind]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/sources",
					className: "text-muted hover:text-fg",
					children: "How the index is sourced"
				})
			})
		]
	});
}
function Header({ icon, kicker, title, blurb, count }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
			children: [
				icon,
				kicker,
				typeof count === "number" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono tabular-nums text-muted",
					children: count
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl tracking-tight",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-xl text-muted",
			children: blurb
		})
	] });
}
//#endregion
export { BrowseKind as component };
