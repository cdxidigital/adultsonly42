import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link, x as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { d as Bookmark, f as BookmarkCheck, o as ExternalLink } from "./_libs/lucide-react.mjs";
import { b as KIND_META, c as useSaved, l as Button, n as Route } from "./_ssr/router-3x6f2zop.mjs";
import { n as Portrait, t as KIND_ICON } from "./_ssr/kind-mark-BDWQJV1X.mjs";
import { t as Badge } from "./_ssr/badge-Dcv4z_EB.mjs";
import { t as getLiveRecord } from "./_ssr/queries-CWf2DY0z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_qid-1Do_qQUm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LiveRecordPage() {
	const { qid } = Route.useParams();
	const [hit, setHit] = (0, import_react.useState)(void 0);
	const saved = useSaved((s) => hit ? s.has({
		kind: hit.kind,
		id: hit.qid
	}) : false);
	const toggle = useSaved((s) => s.toggle);
	(0, import_react.useEffect)(() => {
		let alive = true;
		setHit(void 0);
		getLiveRecord({ data: { qid } }).then((row) => {
			if (alive) setHit(row);
		});
		return () => {
			alive = false;
		};
	}, [qid]);
	if (hit === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-12 text-muted",
		children: "Looking up the live industry databases…"
	});
	if (!hit) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "Not in the live index"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-md text-muted",
			children: "No adult-industry database record matched this identifier, or the performer did not pass the 21+ birth-year filter."
		})]
	});
	const Icon = KIND_ICON[hit.kind];
	const saveRef = {
		kind: hit.kind,
		id: hit.qid,
		name: hit.name
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/$kind",
				params: { kind: hit.kind },
				className: "hover:text-fg",
				children: KIND_META[hit.kind].singular
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "· Live databases" })
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 grid gap-8 lg:grid-cols-[minmax(0,1fr)_16rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
					id: hit.qid,
					name: hit.name,
					kind: hit.kind,
					className: "hidden h-36 w-[6.8rem] shrink-0 sm:block"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl leading-[1.1] tracking-tight sm:text-5xl",
							children: hit.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Live index" }), hit.region && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: hit.region
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: saved ? "secondary" : "outline",
							className: "mt-4 min-h-11 lg:hidden",
							onClick: () => toggle(saveRef),
							children: [saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), saved ? "Saved" : "Save record"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 max-w-2xl text-base leading-relaxed text-fg",
				children: hit.summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-sm leading-relaxed text-muted",
				children: "Metadata is drawn from Wikidata identifiers for IAFD, Adult Film Database, AVN, XXXBios, EGAFD, BGAFD, and EuroBabeIndex. fleshsesh does not host explicit media, scene descriptions, or photographs. Birth dates are used only to enforce a 21+ filter and are not published. Outbound links open the source database."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
					children: "Industry databases"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 divide-y divide-border",
					children: [hit.databases.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: d.href,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "flex min-h-11 items-center justify-between gap-3 py-2.5 text-sm hover:text-accent",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: d.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5 shrink-0 text-subtle" })]
					}) }, d.name + d.href)), hit.wikipedia && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: hit.wikipedia,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "flex min-h-11 items-center justify-between gap-3 py-2.5 text-sm hover:text-accent",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Wikipedia" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5 shrink-0 text-subtle" })]
					}) })]
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "space-y-4 lg:pt-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: saved ? "secondary" : "outline",
				className: "hidden min-h-11 w-full lg:inline-flex",
				onClick: () => toggle(saveRef),
				children: [saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), saved ? "Saved" : "Save record"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-border py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[11px] uppercase tracking-[0.14em] text-subtle",
						children: "Wikidata"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-mono text-sm",
						children: hit.qid
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[11px] uppercase tracking-[0.14em] text-subtle",
						children: "Sources"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-sm",
						children: hit.databases.map((d) => d.name).filter((n, i, a) => a.indexOf(n) === i).join(", ") || "Wikidata"
					})]
				})]
			})]
		})]
	})] });
}
//#endregion
export { LiveRecordPage as component };
