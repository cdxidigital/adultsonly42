import { v as Link, x as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { d as Bookmark, f as BookmarkCheck } from "./_libs/lucide-react.mjs";
import { b as KIND_META, c as useSaved, f as getEntity, g as resolveCredit, h as relatedOf, l as Button, p as isKind, r as Route$1 } from "./_ssr/router-3x6f2zop.mjs";
import { n as Portrait, t as KIND_ICON } from "./_ssr/kind-mark-BDWQJV1X.mjs";
import { t as EntityCard } from "./_ssr/entity-card-GzSLAuZM.mjs";
import { t as Badge } from "./_ssr/badge-Dcv4z_EB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-L5rd8GTj.js
var import_jsx_runtime = require_jsx_runtime();
function EntityPage() {
	const { kind, id } = Route$1.useParams();
	if (!isKind(kind)) return null;
	const entity = getEntity(kind, id);
	if (!entity) return null;
	const Icon = KIND_ICON[entity.kind];
	const related = relatedOf(entity);
	const saved = useSaved((s) => s.has({
		kind: entity.kind,
		id: entity.id
	}));
	const toggle = useSaved((s) => s.toggle);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/$kind",
				params: { kind: entity.kind },
				className: "hover:text-fg",
				children: KIND_META[entity.kind].singular
			}),
			entity.source === "public" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "· Public record" })
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 grid gap-8 lg:grid-cols-[minmax(0,1fr)_16rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
					id: entity.id,
					name: entity.name,
					kind: entity.kind,
					className: "hidden h-36 w-[6.8rem] shrink-0 sm:block"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl leading-[1.1] tracking-tight sm:text-5xl",
							children: entity.name
						}),
						entity.subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-lg text-muted",
							children: entity.subtitle
						}),
						entity.aka && entity.aka.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-subtle",
							children: ["Also ", entity.aka.join(", ")]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [
								entity.status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: entity.status }),
								entity.region && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: entity.region
								}),
								entity.jurisdiction && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: entity.jurisdiction
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: saved ? "secondary" : "outline",
							className: "mt-4 min-h-11 lg:hidden",
							onClick: () => toggle({
								kind: entity.kind,
								id: entity.id
							}),
							children: [saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), saved ? "Saved" : "Save record"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 max-w-2xl text-base leading-relaxed text-fg",
				children: entity.summary
			}),
			entity.body && entity.body.split("\n\n").map((para) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-base leading-relaxed text-muted",
				children: para
			}, para.slice(0, 40))),
			entity.credits && entity.credits.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
					children: "Credits"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
					className: "mt-3 w-full text-left text-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: entity.credits.map((c, i) => {
						const target = resolveCredit(c);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-4 text-subtle",
									children: c.role
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 pr-4",
									children: target ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/$kind/$id",
										params: {
											kind: target.kind,
											id: target.id
										},
										className: "hover:text-accent",
										children: c.title
									}) : c.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 font-mono tabular-nums text-muted",
									children: c.year
								})
							]
						}, i);
					}) })
				})]
			}),
			entity.socials && entity.socials.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
					children: "Public socials"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-1",
					children: entity.socials.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24 text-subtle",
							children: s.platform
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: s.handle
						})]
					}, `${s.platform}-${s.handle}`))
				})]
			}),
			related.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
					children: "Related"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-3 sm:grid-cols-2",
					children: related.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityCard, {
						entity: r,
						compact: true
					}, `${r.kind}:${r.id}`))
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "space-y-4 lg:pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: saved ? "secondary" : "outline",
					className: "hidden min-h-11 w-full lg:inline-flex",
					onClick: () => toggle({
						kind: entity.kind,
						id: entity.id
					}),
					children: [saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), saved ? "Saved" : "Save record"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						entity.citation && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
							label: "Citation",
							value: entity.citation
						}),
						entity.venue && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
							label: "Venue",
							value: entity.venue
						}),
						entity.dateStart && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
							label: "Dates",
							value: entity.dateEnd ? `${entity.dateStart} – ${entity.dateEnd}` : entity.dateStart
						}),
						entity.facts.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
							label: f.label,
							value: f.value
						}, f.label))
					]
				}),
				entity.tags.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: entity.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/search",
						search: {
							q: t,
							kind: "all"
						},
						className: "rounded-full px-2.5 py-1 text-xs text-muted shadow-[var(--shadow-border)] hover:text-fg",
						children: t
					}, t))
				})
			]
		})]
	})] });
}
function Fact({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-border py-2.5 last:border-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-[11px] uppercase tracking-[0.14em] text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 text-sm text-fg",
			children: value
		})]
	});
}
//#endregion
export { EntityPage as component };
