import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { x as cn } from "./router-3x6f2zop.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-Dcv4z_EB.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-raised text-muted shadow-[var(--shadow-border)]",
		accent: "bg-accent text-accent-fg",
		outline: "text-muted shadow-[var(--shadow-border)]"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Badge as t };
