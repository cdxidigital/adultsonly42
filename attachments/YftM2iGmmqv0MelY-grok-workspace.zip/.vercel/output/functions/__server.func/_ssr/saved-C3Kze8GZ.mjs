import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as useSaved, f as getEntity, s as isLiveId } from "./router-3x6f2zop.mjs";
import { n as Portrait } from "./kind-mark-BDWQJV1X.mjs";
import { t as EntityCard } from "./entity-card-GzSLAuZM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/saved-C3Kze8GZ.js
var import_jsx_runtime = require_jsx_runtime();
function SavedPage() {
	const items = useSaved((s) => s.items);
	const local = items.map((r) => ({
		ref: r,
		entity: getEntity(r.kind, r.id)
	})).filter((x) => x.entity);
	const live = items.filter((r) => !getEntity(r.kind, r.id) && isLiveId(r.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
			children: "This device"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl tracking-tight",
			children: "Saved"
		}),
		local.length === 0 && live.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-8 max-w-md text-muted",
			children: "Nothing pinned yet. Open a record and save it — the list stays in this browser."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-3 sm:grid-cols-2",
			children: [local.map(({ entity }) => entity ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityCard, { entity }, `${entity.kind}:${entity.id}`) : null), live.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/live/$qid",
				params: { qid: r.id },
				className: "flex items-center gap-3 rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
					id: r.id,
					name: r.name ?? r.id,
					kind: r.kind,
					className: "size-14 shrink-0"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.14em] text-subtle",
						children: "Live index"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg",
						children: r.name ?? r.id
					})]
				})]
			}, `live:${r.id}`))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-8 text-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "text-muted hover:text-fg",
				children: "Back to the index"
			})
		})
	] });
}
//#endregion
export { SavedPage as component };
