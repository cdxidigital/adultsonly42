import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Gavel, c as Calendar, l as Building2, r as Share2, s as Clapperboard, t as UserRound, u as Briefcase } from "../_libs/lucide-react.mjs";
import { x as cn } from "./router-3x6f2zop.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kind-mark-BDWQJV1X.js
var import_jsx_runtime = require_jsx_runtime();
function hash(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function initials(name) {
	const parts = name.replace(/[§.]/g, " ").split(/\s+/).filter(Boolean);
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
var FIELDS = [
	[
		"#1a1917",
		"#c5c9d1",
		"#6a6762"
	],
	[
		"#16151a",
		"#f3f1ec",
		"#8c8984"
	],
	[
		"#1c1b19",
		"#b8b3a8",
		"#4a4844"
	],
	[
		"#121214",
		"#d7d3c8",
		"#7a7772"
	],
	[
		"#181614",
		"#a8adb6",
		"#5c5954"
	]
];
function Portrait({ id, name, kind, className }) {
	const h = hash(id + kind);
	const [bg, fg, mid] = FIELDS[h % FIELDS.length];
	const letters = initials(name);
	const rot = h % 18 - 9;
	const offset = h % 7 - 3;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative overflow-hidden rounded-md bg-raised shadow-[var(--shadow-border)]", className),
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 160 200",
			className: "size-full",
			preserveAspectRatio: "xMidYMid slice",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "160",
					height: "200",
					fill: bg
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 12 + offset,
					y: "18",
					width: "136",
					height: "164",
					fill: "none",
					stroke: mid,
					strokeWidth: "0.6"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: 28,
					y: 40,
					width: "104",
					height: "88",
					fill: mid,
					opacity: "0.18",
					transform: `rotate(${rot} 80 84)`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "20",
					y: "148",
					width: "120",
					height: "1",
					fill: mid,
					opacity: "0.5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: 40 + h % 80,
					cy: 50 + h % 40,
					r: "22",
					fill: fg,
					opacity: "0.08"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "80",
					y: "168",
					textAnchor: "middle",
					fill: fg,
					fontFamily: "Newsreader, Georgia, serif",
					fontSize: "28",
					letterSpacing: "2",
					children: letters
				}),
				Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "4",
					y: 16 + i * 22,
					width: "6",
					height: "8",
					rx: "1",
					fill: mid,
					opacity: "0.45"
				}, i))
			]
		})
	});
}
var KIND_ICON = {
	performers: UserRound,
	productions: Clapperboard,
	companies: Building2,
	agents: Briefcase,
	events: Calendar,
	social: Share2,
	law: Gavel
};
//#endregion
export { Portrait as n, KIND_ICON as t };
