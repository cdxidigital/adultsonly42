import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as search, a as Route$4, b as KIND_META, o as SearchBox, p as isKind, v as socialDirectory, x as cn, y as KINDS } from "./router-3x6f2zop.mjs";
import { n as Portrait, t as KIND_ICON } from "./kind-mark-BDWQJV1X.mjs";
import { n as EntityRow, r as Highlight } from "./entity-card-GzSLAuZM.mjs";
import { n as searchLiveIndex } from "./queries-CWf2DY0z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-CDV7mxDh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LiveRow({ hit, q }) {
	const Icon = KIND_ICON[hit.kind];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/live/$qid",
		params: { qid: hit.qid },
		className: "group flex items-start gap-3 rounded-lg px-2 py-3 transition-colors duration-[var(--motion-quick)] hover:bg-raised",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portrait, {
			id: hit.qid,
			name: hit.name,
			kind: hit.kind,
			className: "size-12 shrink-0"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-baseline gap-x-2 gap-y-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg leading-snug text-fg group-hover:text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Highlight, {
							text: hit.name,
							q
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 text-[11px] font-medium uppercase tracking-[0.14em] text-subtle",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3" }), KIND_META[hit.kind].singular]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 line-clamp-2 text-sm text-muted",
					children: hit.summary
				}),
				hit.databases.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-[11px] uppercase tracking-[0.12em] text-subtle",
					children: hit.databases.map((d) => d.name).filter((n, i, a) => a.indexOf(n) === i).join(" · ")
				})
			]
		})]
	});
}
function SearchPage() {
	const { q, kind } = Route$4.useSearch();
	const hits = kind === "social" ? [] : search(q, kind === "all" || !isKind(kind) ? "all" : kind);
	const socialHits = kind === "all" || kind === "social" ? socialDirectory().filter((row) => {
		if (!q.trim()) return kind === "social";
		const blob = `${row.platform} ${row.handle} ${row.entity.name}`.toLowerCase();
		return q.toLowerCase().split(/\s+/).every((t) => blob.includes(t));
	}) : [];
	const [live, setLive] = (0, import_react.useState)([]);
	const [liveState, setLiveState] = (0, import_react.useState)("idle");
	const [liveError, setLiveError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const query = q.trim();
		if (query.length < 2 || kind === "social" || kind === "agents" || kind === "events" || kind === "law") {
			setLive([]);
			setLiveState("idle");
			setLiveError(null);
			return;
		}
		let alive = true;
		setLiveState("loading");
		searchLiveIndex({ data: {
			q: query,
			kind
		} }).then((res) => {
			if (!alive) return;
			setLive(res.hits);
			setLiveError(res.error ?? null);
			setLiveState(res.error ? "error" : "done");
		});
		return () => {
			alive = false;
		};
	}, [q, kind]);
	const liveKinds = kind === "all" || kind === "performers" || kind === "productions" || kind === "companies";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
			children: "Index"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl tracking-tight",
			children: "Search"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 max-w-2xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBox, {
				initial: q,
				autoFocus: true,
				kind
			}, `${kind}:${q}`)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 flex flex-wrap gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				label: "All",
				kind: "all",
				current: kind,
				q
			}), KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				label: KIND_META[k].label,
				kind: k,
				current: kind,
				q
			}, k))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-sm text-muted",
			children: [
				kind === "social" ? `${socialHits.length} public handle${socialHits.length === 1 ? "" : "s"}` : `${hits.length} desk record${hits.length === 1 ? "" : "s"}`,
				liveKinds && q.trim().length >= 2 ? ` · ${liveState === "loading" ? "querying live databases" : `${live.length} live`}` : "",
				q.trim() ? ` for “${q}”` : ""
			]
		}),
		hits.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
				children: "Desk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 divide-y divide-border",
				children: hits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityRow, {
					entity: h.entity,
					q
				}, `${h.entity.kind}:${h.entity.id}`))
			})]
		}),
		(kind === "social" || kind === "all" && socialHits.length > 0 && q.trim()) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 divide-y divide-border",
			children: socialHits.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/$kind/$id",
				params: {
					kind: row.entity.kind,
					id: row.entity.id
				},
				className: "flex items-center gap-3 py-3 hover:text-accent",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-24 shrink-0 text-[11px] uppercase tracking-[0.14em] text-subtle",
						children: row.platform
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-sm",
						children: row.handle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: row.entity.name
					})
				]
			}, `${row.entity.id}-${row.platform}-${row.handle}`))
		}),
		liveKinds && q.trim().length >= 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
					children: ["Live databases · ", "IAFD · AFDB · AVN · XXXBios · EGAFD · BGAFD"]
				}),
				liveState === "loading" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "Querying Wikidata…"
				}),
				liveState === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-muted",
					children: [
						"Live index unavailable",
						liveError ? ` (${liveError})` : "",
						". Desk records above still search."
					]
				}),
				live.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 divide-y divide-border",
					children: live.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveRow, {
						hit,
						q
					}, hit.qid))
				}),
				liveState === "done" && live.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md text-sm text-muted",
					children: "No live database match. Try a performer, title, or studio name. Performers need a Wikidata birth year of 21+."
				})
			]
		}),
		hits.length === 0 && socialHits.length === 0 && live.length === 0 && liveState !== "loading" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-10 max-w-md text-muted",
			children: q.trim() ? "Nothing matched the desk. Live results appear below when a public industry database has a record." : "Type a name, title, statute, or city. Two characters open the live industry databases."
		})
	] });
}
function FilterChip({ label, kind, current, q }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/search",
		search: {
			q,
			kind
		},
		className: cn("rounded-full px-3 py-2 text-sm transition-colors duration-[var(--motion-quick)]", current === kind ? "bg-accent text-accent-fg" : "text-muted shadow-[var(--shadow-border)] hover:text-fg"),
		children: label
	});
}
//#endregion
export { SearchPage as component };
