import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-BBbnV4mD.js
var import_jsx_runtime = require_jsx_runtime();
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
				children: "Methodology"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl tracking-tight",
				children: "About the index"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-5 text-base leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "fleshsesh is a search engine for the adult entertainment trade: performers, productions, companies, agents, events, public socials, and the law. It is built as a professional register, not a tube." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The live index queries Wikidata for records that carry identifiers from IAFD, Adult Film Database, AVN, XXXBios, EGAFD, BGAFD, and EuroBabeIndex. Tube platforms and clip storefronts are not indexed. No explicit media, scene descriptions, or photographs are hosted. Performer rows require a Wikidata birth year of 21 or older; the date itself is not displayed." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A smaller demonstration roster (talent, titles, houses, representation) sits on the desk for browsing when you are not searching a live name. The law desk and parts of the calendar are public record. Summaries are orientation, not legal advice." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Saved records live only on this device. There are no accounts. Report trafficking to law enforcement or the U.S. National Human Trafficking Hotline, 1-888-373-7888." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/sources",
						className: "text-fg hover:text-accent",
						children: "Databases we index"
					}) })
				]
			})
		]
	});
}
//#endregion
export { About as component };
