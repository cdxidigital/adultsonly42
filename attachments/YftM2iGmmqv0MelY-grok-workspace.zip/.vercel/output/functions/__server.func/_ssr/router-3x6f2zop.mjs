import { i as __toESM } from "../_runtime.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { V as notFound, _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, x as require_jsx_runtime, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Bookmark, i as Search, n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/types-DA6ctQI7.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var KINDS = [
	"performers",
	"productions",
	"companies",
	"agents",
	"events",
	"social",
	"law"
];
var KIND_META = {
	performers: {
		label: "Performers",
		singular: "Performer",
		blurb: "Working adults credited on camera. Search a name to query the live industry databases (21+)."
	},
	productions: {
		label: "Productions",
		singular: "Production",
		blurb: "Features, series, and titles listed in the public industry databases."
	},
	companies: {
		label: "Companies",
		singular: "Company",
		blurb: "Studios, platforms, agencies, distributors, and trade bodies — including houses listed in IAFD and AFDB."
	},
	agents: {
		label: "Agents",
		singular: "Agent",
		blurb: "Representation, casting, and roster management."
	},
	events: {
		label: "Events",
		singular: "Event",
		blurb: "Awards, expos, trade fairs, and industry convenings."
	},
	social: {
		label: "Social",
		singular: "Profile",
		blurb: "Public handles attached to talent, houses, and organizations."
	},
	law: {
		label: "Law",
		singular: "Statute",
		blurb: "Statutes, cases, and compliance notes that govern the trade."
	}
};
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/search-LYBm1BLT.js
var industry = [
	{
		id: "helix-house",
		kind: "companies",
		name: "Helix House",
		subtitle: "Premium studio",
		summary: "Los Angeles house known for director-led features, long contracts, and a closed 2257 desk. Flagship imprint of the contemporary West Coast scene.",
		body: "Founded in 2012 in Silver Lake, Helix House produces a short slate of high-budget features and a standing series, Glass Harbor. The company keeps a staff custodian of records, will not shoot without picture identification on file, and books through Redwood Talent and Meridian Casting. Contract talent typically sign two-year terms with first-look on directing.",
		tags: [
			"studio",
			"los-angeles",
			"features",
			"2257"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [
			{
				label: "Founded",
				value: "2012"
			},
			{
				label: "HQ",
				value: "Silver Lake, Los Angeles"
			},
			{
				label: "Imprint",
				value: "Features & series"
			},
			{
				label: "Custodian",
				value: "On-staff, inspected"
			}
		],
		related: [
			{
				kind: "productions",
				id: "glass-harbor",
				label: "Flagship series"
			},
			{
				kind: "productions",
				id: "wintering",
				label: "Feature"
			},
			{
				kind: "agents",
				id: "mara-ellison"
			},
			{
				kind: "law",
				id: "usc-2257"
			}
		],
		socials: [
			{
				platform: "X",
				handle: "@helixhouse"
			},
			{
				platform: "Instagram",
				handle: "@helixhouse"
			},
			{
				platform: "Site",
				handle: "helix.house"
			}
		],
		source: "index"
	},
	{
		id: "northstar-pictures",
		kind: "companies",
		name: "Northstar Pictures",
		subtitle: "Feature studio",
		summary: "Narrative-first studio in the San Fernando Valley. Known for long-form features, union-style call sheets, and Palisade nominations.",
		body: "Northstar treats adult features as a production discipline: department heads, rehearsal days, and a published 2257 statement on every title card. Distributes through Eastbound. Several directors (Wren Solis, Evander Crowe) move between Northstar and Nightjar.",
		tags: [
			"studio",
			"features",
			"valley",
			"narrative"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [
			{
				label: "Founded",
				value: "2008"
			},
			{
				label: "HQ",
				value: "Van Nuys, California"
			},
			{
				label: "Distribution",
				value: "Eastbound"
			}
		],
		related: [
			{
				kind: "productions",
				id: "the-night-ledger"
			},
			{
				kind: "productions",
				id: "eastern-standard"
			},
			{
				kind: "companies",
				id: "eastbound"
			},
			{
				kind: "performers",
				id: "wren-solis"
			}
		],
		socials: [{
			platform: "X",
			handle: "@northstarpix"
		}],
		source: "index"
	},
	{
		id: "nightjar-films",
		kind: "companies",
		name: "Nightjar Films",
		subtitle: "Auteur imprint",
		summary: "Director-owned imprint. Small crews, location work, and a roster of performers who also direct.",
		tags: [
			"studio",
			"indie",
			"directors"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "Founded",
			value: "2018"
		}, {
			label: "Model",
			value: "Director-owned"
		}],
		related: [
			{
				kind: "performers",
				id: "isla-vane"
			},
			{
				kind: "performers",
				id: "wren-solis"
			},
			{
				kind: "productions",
				id: "low-light"
			},
			{
				kind: "productions",
				id: "second-unit"
			},
			{
				kind: "events",
				id: "nightjar-forum-2026"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@nightjarfilms"
		}],
		source: "index"
	},
	{
		id: "afterlight-media",
		kind: "companies",
		name: "Afterlight Media",
		subtitle: "European house",
		summary: "Berlin studio and sales agent. Shoots in German, French, and English; handles EU DSA age-assurance for its own storefront.",
		tags: [
			"studio",
			"berlin",
			"europe",
			"dsa"
		],
		region: "Berlin",
		status: "Active",
		facts: [
			{
				label: "Founded",
				value: "2014"
			},
			{
				label: "HQ",
				value: "Neukölln, Berlin"
			},
			{
				label: "Markets",
				value: "EU, UK, North America"
			}
		],
		related: [
			{
				kind: "performers",
				id: "omar-leclerc"
			},
			{
				kind: "performers",
				id: "tamsin-rowe"
			},
			{
				kind: "agents",
				id: "sabine-kohler"
			},
			{
				kind: "productions",
				id: "corridor"
			},
			{
				kind: "events",
				id: "venus-berlin-2026"
			},
			{
				kind: "law",
				id: "eu-dsa"
			}
		],
		socials: [{
			platform: "X",
			handle: "@afterlightmedia"
		}],
		source: "index"
	},
	{
		id: "pine-vale",
		kind: "companies",
		name: "Pine & Vale",
		subtitle: "Boutique studio",
		summary: "Vancouver boutique. Short-run series, stills-led campaigns, and a reputation for performer-directors.",
		tags: [
			"studio",
			"vancouver",
			"boutique"
		],
		region: "Vancouver",
		status: "Active",
		facts: [{
			label: "Founded",
			value: "2016"
		}, {
			label: "HQ",
			value: "Vancouver, BC"
		}],
		related: [
			{
				kind: "performers",
				id: "maren-dahl"
			},
			{
				kind: "performers",
				id: "sienna-park"
			},
			{
				kind: "productions",
				id: "salt-and-copper"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@pineandvale"
		}],
		source: "index"
	},
	{
		id: "vellum-digital",
		kind: "companies",
		name: "Vellum",
		subtitle: "Direct-to-fan platform",
		summary: "Subscription platform for independent adult creators. Secondary-producer 2257 posture; creators remain primary producers of their own work.",
		body: "Vellum is the catalog's stand-in for the direct-to-fan stack: subscriptions, PPV, and tipping. The company stores copies of creator IDs as a secondary producer and requires a 2257 statement on every profile. TAKE IT DOWN Act notice-and-removal is published in the footer, with a 48-hour SLA.",
		tags: [
			"platform",
			"direct-to-fan",
			"2257",
			"take-it-down"
		],
		region: "United States",
		status: "Active",
		facts: [
			{
				label: "Launched",
				value: "2019"
			},
			{
				label: "Role",
				value: "Secondary producer"
			},
			{
				label: "Removal SLA",
				value: "48 hours"
			}
		],
		related: [
			{
				kind: "performers",
				id: "noa-pell"
			},
			{
				kind: "performers",
				id: "aisha-nasser"
			},
			{
				kind: "law",
				id: "usc-2257"
			},
			{
				kind: "law",
				id: "take-it-down"
			},
			{
				kind: "law",
				id: "card-networks"
			}
		],
		socials: [{
			platform: "X",
			handle: "@vellum"
		}, {
			platform: "Site",
			handle: "vellum.example"
		}],
		source: "index"
	},
	{
		id: "cobalt-interactive",
		kind: "companies",
		name: "Cobalt",
		subtitle: "Live platform",
		summary: "Live-cam and ticketed shows. Age-gates at signup; geo-blocks jurisdictions with strict AV statutes when it cannot verify.",
		tags: [
			"platform",
			"live",
			"age-assurance"
		],
		region: "United States",
		status: "Active",
		facts: [{
			label: "Launched",
			value: "2011"
		}, {
			label: "Format",
			value: "Live + tickets"
		}],
		related: [
			{
				kind: "performers",
				id: "kade-morin"
			},
			{
				kind: "law",
				id: "fsc-v-paxton"
			},
			{
				kind: "law",
				id: "state-av-laws"
			}
		],
		socials: [{
			platform: "X",
			handle: "@cobaltlive"
		}],
		source: "index"
	},
	{
		id: "aurelia-network",
		kind: "companies",
		name: "Aurelia Network",
		subtitle: "Aggregator",
		summary: "Licensed tube and clip aggregator. DMCA agent on file; 2257 statements inherited from studio partners; geo-fencing after FSC v. Paxton.",
		tags: [
			"platform",
			"tube",
			"dmca",
			"geo-fence"
		],
		region: "Cyprus / United States",
		status: "Active",
		facts: [{
			label: "Launched",
			value: "2007"
		}, {
			label: "Model",
			value: "Licensed aggregator"
		}],
		related: [
			{
				kind: "companies",
				id: "eastbound"
			},
			{
				kind: "law",
				id: "dmca-512"
			},
			{
				kind: "law",
				id: "fsc-v-paxton"
			},
			{
				kind: "law",
				id: "fosta-sesta"
			}
		],
		socials: [{
			platform: "X",
			handle: "@aurelia"
		}],
		source: "index"
	},
	{
		id: "eastbound",
		kind: "companies",
		name: "Eastbound Distribution",
		subtitle: "Sales & distribution",
		summary: "North American sales agent for Helix, Northstar, Pine & Vale, and Afterlight's English-language slate.",
		tags: ["distributor", "sales"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "Founded",
			value: "2004"
		}, {
			label: "HQ",
			value: "Hollywood, California"
		}],
		related: [
			{
				kind: "companies",
				id: "helix-house"
			},
			{
				kind: "companies",
				id: "northstar-pictures"
			},
			{
				kind: "companies",
				id: "afterlight-media"
			},
			{
				kind: "events",
				id: "avn-expo-2026"
			}
		],
		socials: [{
			platform: "X",
			handle: "@eastboundhq"
		}],
		source: "index"
	},
	{
		id: "redwood-talent",
		kind: "companies",
		name: "Redwood Talent",
		subtitle: "Talent agency",
		summary: "Full-service agency for on-camera talent, directors, and a growing direct-to-fan book. Los Angeles with a Berlin desk via Sabine Köhler.",
		tags: ["agency", "representation"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "Founded",
			value: "2009"
		}, {
			label: "Desks",
			value: "Los Angeles, Berlin"
		}],
		related: [
			{
				kind: "agents",
				id: "mara-ellison"
			},
			{
				kind: "agents",
				id: "devon-reyes"
			},
			{
				kind: "companies",
				id: "helix-house"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@redwoodtalent"
		}],
		source: "index"
	},
	{
		id: "meridian-casting",
		kind: "companies",
		name: "Meridian Casting",
		subtitle: "Casting",
		summary: "Casting office for features and series. Keeps a private 2257 pre-clear list; will not submit a performer without current identification on file.",
		tags: ["casting", "2257"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "Founded",
			value: "2011"
		}, {
			label: "Specialty",
			value: "Features & series"
		}],
		related: [
			{
				kind: "agents",
				id: "jonah-peck"
			},
			{
				kind: "companies",
				id: "northstar-pictures"
			},
			{
				kind: "law",
				id: "usc-2257"
			}
		],
		source: "index"
	},
	{
		id: "palisade-institute",
		kind: "companies",
		name: "Palisade Institute",
		subtitle: "Awards body",
		summary: "Trade academy behind the Palisade Honors. Publishes eligibility rules, a performer-safety pledge, and an annual craft ballot.",
		tags: ["awards", "trade-body"],
		region: "Las Vegas",
		status: "Active",
		facts: [{
			label: "Founded",
			value: "1999"
		}, {
			label: "Flagship",
			value: "Palisade Honors"
		}],
		related: [{
			kind: "events",
			id: "palisade-honors-2026"
		}, {
			kind: "events",
			id: "avn-expo-2026"
		}],
		socials: [{
			platform: "X",
			handle: "@palisadehonors"
		}],
		source: "index"
	},
	{
		id: "counsel-group",
		kind: "companies",
		name: "Counsel Group",
		subtitle: "Industry counsel",
		summary: "Boutique firm for 2257 programs, performer contracts, platform terms, and state age-verification maps. Hosts Counsel Day.",
		tags: [
			"law-firm",
			"compliance",
			"2257"
		],
		region: "Los Angeles / Washington",
		status: "Active",
		facts: [{
			label: "Founded",
			value: "2006"
		}, {
			label: "Desks",
			value: "Los Angeles, D.C."
		}],
		related: [
			{
				kind: "events",
				id: "counsel-day-2026"
			},
			{
				kind: "law",
				id: "usc-2257"
			},
			{
				kind: "law",
				id: "fsc-v-paxton"
			},
			{
				kind: "law",
				id: "take-it-down"
			}
		],
		socials: [{
			platform: "Site",
			handle: "counsel.group"
		}],
		source: "index"
	},
	{
		id: "copperline-pr",
		kind: "companies",
		name: "Copperline",
		subtitle: "Public relations",
		summary: "Trade PR and awards campaign shop. Books talent at expos and manages Palisade campaigns.",
		tags: ["pr", "awards"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "Founded",
			value: "2015"
		}],
		related: [
			{
				kind: "events",
				id: "avn-expo-2026"
			},
			{
				kind: "events",
				id: "xbiz-2026"
			},
			{
				kind: "companies",
				id: "palisade-institute"
			}
		],
		source: "index"
	},
	{
		id: "fsc",
		kind: "companies",
		name: "Free Speech Coalition",
		subtitle: "Trade association",
		summary: "U.S. trade association for the adult industry. Plaintiff in Free Speech Coalition v. Paxton (2025). Advocacy, compliance education, and performer resources.",
		body: "The Free Speech Coalition is the principal U.S. trade group for adult producers, platforms, and performers. It litigates and lobbies on First Amendment, record-keeping, payment, and age-verification issues, and publishes compliance guidance for members. In 2025 it was the named petitioner in Free Speech Coalition v. Paxton, the Supreme Court case on Texas H.B. 1181.",
		tags: [
			"trade-body",
			"advocacy",
			"united-states",
			"public"
		],
		region: "United States",
		status: "Active",
		facts: [
			{
				label: "Founded",
				value: "1991"
			},
			{
				label: "Type",
				value: "Trade association"
			},
			{
				label: "Record",
				value: "FSC v. Paxton (2025)"
			}
		],
		related: [
			{
				kind: "law",
				id: "fsc-v-paxton"
			},
			{
				kind: "law",
				id: "fosta-sesta"
			},
			{
				kind: "law",
				id: "usc-2257"
			},
			{
				kind: "companies",
				id: "asacp"
			}
		],
		socials: [{
			platform: "X",
			handle: "@FreeSpeechFSC"
		}, {
			platform: "Site",
			handle: "freespeechcoalition.com"
		}],
		source: "public"
	},
	{
		id: "asacp",
		kind: "companies",
		name: "ASACP",
		subtitle: "Child-protection nonprofit",
		summary: "Association of Sites Advocating Child Protection. Independent nonprofit that fights child sexual abuse material online and runs a hotline used across the adult trade.",
		tags: [
			"nonprofit",
			"child-protection",
			"public"
		],
		region: "United States",
		status: "Active",
		facts: [{
			label: "Founded",
			value: "1996"
		}, {
			label: "Type",
			value: "Nonprofit"
		}],
		related: [{
			kind: "companies",
			id: "fsc"
		}, {
			kind: "law",
			id: "usc-2257"
		}],
		socials: [{
			platform: "Site",
			handle: "asacp.org"
		}],
		source: "public"
	},
	{
		id: "mara-ellison",
		kind: "agents",
		name: "Mara Ellison",
		subtitle: "Partner, Redwood Talent",
		summary: "Books Helix House contracts and a select independent list. Known for long-term deals with first-look directing clauses.",
		tags: [
			"agent",
			"los-angeles",
			"contracts"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [
			{
				label: "Agency",
				value: "Redwood Talent"
			},
			{
				label: "Desk",
				value: "On-camera & directors"
			},
			{
				label: "Since",
				value: "2013"
			}
		],
		credits: [
			{
				role: "Represents",
				title: "Isla Vane",
				year: "2019–",
				kind: "performers",
				id: "isla-vane"
			},
			{
				role: "Represents",
				title: "Roman Calder",
				year: "2016–",
				kind: "performers",
				id: "roman-calder"
			},
			{
				role: "Represents",
				title: "Juniper Hale",
				year: "2021–",
				kind: "performers",
				id: "juniper-hale"
			},
			{
				role: "Represents",
				title: "Cassian Wolfe",
				year: "2018–",
				kind: "performers",
				id: "cassian-wolfe"
			}
		],
		related: [
			{
				kind: "companies",
				id: "redwood-talent"
			},
			{
				kind: "companies",
				id: "helix-house"
			},
			{
				kind: "performers",
				id: "isla-vane"
			}
		],
		socials: [{
			platform: "X",
			handle: "@maraellison"
		}],
		source: "index"
	},
	{
		id: "devon-reyes",
		kind: "agents",
		name: "Devon Reyes",
		subtitle: "Agent, Redwood Talent",
		summary: "Direct-to-fan and crossover book. Places clients on Vellum and brokered the Pine & Vale Vancouver slate.",
		tags: ["agent", "direct-to-fan"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "Agency",
			value: "Redwood Talent"
		}, {
			label: "Desk",
			value: "Direct-to-fan"
		}],
		credits: [
			{
				role: "Represents",
				title: "Noa Pell",
				year: "2022–",
				kind: "performers",
				id: "noa-pell"
			},
			{
				role: "Represents",
				title: "Aisha Nasser",
				year: "2023–",
				kind: "performers",
				id: "aisha-nasser"
			},
			{
				role: "Represents",
				title: "Sienna Park",
				year: "2020–",
				kind: "performers",
				id: "sienna-park"
			}
		],
		related: [{
			kind: "companies",
			id: "redwood-talent"
		}, {
			kind: "companies",
			id: "vellum-digital"
		}],
		source: "index"
	},
	{
		id: "jonah-peck",
		kind: "agents",
		name: "Jonah Peck",
		subtitle: "Casting director, Meridian",
		summary: "Casts Northstar features and the Glass Harbor rotating company. Runs Meridian's 2257 pre-clear.",
		tags: ["casting", "features"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "Office",
			value: "Meridian Casting"
		}, {
			label: "Since",
			value: "2011"
		}],
		related: [
			{
				kind: "companies",
				id: "meridian-casting"
			},
			{
				kind: "companies",
				id: "northstar-pictures"
			},
			{
				kind: "productions",
				id: "glass-harbor"
			}
		],
		source: "index"
	},
	{
		id: "sabine-kohler",
		kind: "agents",
		name: "Sabine Köhler",
		subtitle: "EU desk, Redwood / Afterlight",
		summary: "Berlin-based booker for Afterlight and Redwood's European list. Places talent at Venus Berlin and handles DSA-facing storefront copy.",
		tags: [
			"agent",
			"berlin",
			"europe"
		],
		region: "Berlin",
		status: "Active",
		facts: [{
			label: "Desks",
			value: "Redwood Talent, Afterlight"
		}, {
			label: "Market",
			value: "EU & UK"
		}],
		credits: [
			{
				role: "Represents",
				title: "Omar Leclerc",
				year: "2017–",
				kind: "performers",
				id: "omar-leclerc"
			},
			{
				role: "Represents",
				title: "Tamsin Rowe",
				year: "2019–",
				kind: "performers",
				id: "tamsin-rowe"
			},
			{
				role: "Represents",
				title: "Felix Arden",
				year: "2021–",
				kind: "performers",
				id: "felix-arden"
			}
		],
		related: [
			{
				kind: "companies",
				id: "afterlight-media"
			},
			{
				kind: "companies",
				id: "redwood-talent"
			},
			{
				kind: "events",
				id: "venus-berlin-2026"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@sabinekohler"
		}],
		source: "index"
	},
	{
		id: "nina-braswell",
		kind: "agents",
		name: "Nina Braswell",
		subtitle: "Independent manager",
		summary: "Manager for performer-directors and a small trans roster. Advises on TAKE IT DOWN notices and platform terms.",
		tags: ["manager", "independent"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "Practice",
			value: "Independent management"
		}, {
			label: "Since",
			value: "2020"
		}],
		credits: [
			{
				role: "Manages",
				title: "Wren Solis",
				year: "2020–",
				kind: "performers",
				id: "wren-solis"
			},
			{
				role: "Manages",
				title: "Percy Lane",
				year: "2021–",
				kind: "performers",
				id: "percy-lane"
			},
			{
				role: "Manages",
				title: "Ellis Hart",
				year: "2022–",
				kind: "performers",
				id: "ellis-hart"
			}
		],
		related: [{
			kind: "performers",
			id: "wren-solis"
		}, {
			kind: "law",
			id: "take-it-down"
		}],
		source: "index"
	},
	{
		id: "haruki-mori",
		kind: "agents",
		name: "Haruki Mori",
		subtitle: "Pacific booker",
		summary: "Independent booker splitting Tokyo and Los Angeles. Places bilingual talent on Helix and Afterlight English-language days.",
		tags: [
			"agent",
			"tokyo",
			"los-angeles"
		],
		region: "Tokyo / Los Angeles",
		status: "Active",
		facts: [{
			label: "Practice",
			value: "Independent"
		}, {
			label: "Languages",
			value: "Japanese, English"
		}],
		credits: [{
			role: "Represents",
			title: "Liora Chen",
			year: "2020–",
			kind: "performers",
			id: "liora-chen"
		}, {
			role: "Represents",
			title: "Sienna Park",
			year: "2024–",
			kind: "performers",
			id: "sienna-park"
		}],
		related: [{
			kind: "performers",
			id: "liora-chen"
		}, {
			kind: "companies",
			id: "helix-house"
		}],
		source: "index"
	},
	{
		id: "isla-vane",
		kind: "performers",
		name: "Isla Vane",
		subtitle: "Performer · director",
		aka: ["I. Vane"],
		summary: "Helix House contract 2020–2024. Palisade Best New Star, 2020. Now directing for Nightjar and releasing independently on Vellum.",
		body: "Isla Vane first credited in 2019 and signed with Helix House the following year. Four Palisade nominations followed, including a Best New Star win. After her contract lapsed she moved into direction on Low Light and keeps a direct-to-fan studio. Represented by Mara Ellison. All credits are of a working adult; first year of professional work is 2019.",
		tags: [
			"performer",
			"director",
			"los-angeles",
			"helix"
		],
		region: "Los Angeles",
		status: "Independent",
		facts: [
			{
				label: "First credited",
				value: "2019"
			},
			{
				label: "Contract",
				value: "Helix House, 2020–2024"
			},
			{
				label: "Representation",
				value: "Mara Ellison, Redwood"
			},
			{
				label: "Awards",
				value: "Palisade Best New Star, 2020"
			}
		],
		credits: [
			{
				role: "Lead",
				title: "Glass Harbor",
				year: "2020–24",
				kind: "productions",
				id: "glass-harbor"
			},
			{
				role: "Lead",
				title: "Wintering",
				year: "2022",
				kind: "productions",
				id: "wintering"
			},
			{
				role: "Director",
				title: "Low Light",
				year: "2025",
				kind: "productions",
				id: "low-light"
			},
			{
				role: "Lead",
				title: "A Room in Silverlake",
				year: "2023",
				kind: "productions",
				id: "silverlake"
			}
		],
		related: [
			{
				kind: "agents",
				id: "mara-ellison"
			},
			{
				kind: "companies",
				id: "helix-house"
			},
			{
				kind: "companies",
				id: "nightjar-films"
			},
			{
				kind: "productions",
				id: "low-light"
			}
		],
		socials: [
			{
				platform: "Instagram",
				handle: "@islavane"
			},
			{
				platform: "X",
				handle: "@islavane"
			},
			{
				platform: "Vellum",
				handle: "isla"
			}
		],
		source: "index"
	},
	{
		id: "roman-calder",
		kind: "performers",
		name: "Roman Calder",
		subtitle: "Performer",
		summary: "Valley veteran. Northstar and Helix regular; Palisade Best Supporting, 2023. Brother of Bo Calder.",
		tags: [
			"performer",
			"los-angeles",
			"veteran"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [
			{
				label: "First credited",
				value: "2014"
			},
			{
				label: "Representation",
				value: "Mara Ellison, Redwood"
			},
			{
				label: "Awards",
				value: "Palisade Best Supporting, 2023"
			}
		],
		credits: [
			{
				role: "Lead",
				title: "The Night Ledger",
				year: "2021",
				kind: "productions",
				id: "the-night-ledger"
			},
			{
				role: "Supporting",
				title: "Glass Harbor",
				year: "2021–24",
				kind: "productions",
				id: "glass-harbor"
			},
			{
				role: "Lead",
				title: "Eastern Standard",
				year: "2024",
				kind: "productions",
				id: "eastern-standard"
			}
		],
		related: [
			{
				kind: "performers",
				id: "bo-calder",
				label: "Sibling"
			},
			{
				kind: "agents",
				id: "mara-ellison"
			},
			{
				kind: "companies",
				id: "northstar-pictures"
			}
		],
		socials: [{
			platform: "X",
			handle: "@romancalder"
		}],
		source: "index"
	},
	{
		id: "juniper-hale",
		kind: "performers",
		name: "Juniper Hale",
		subtitle: "Performer",
		summary: "Helix contract talent. Breakthrough in A Room in Silverlake; Palisade nominee, 2024.",
		tags: [
			"performer",
			"helix",
			"contract"
		],
		region: "Los Angeles",
		status: "Contract",
		facts: [
			{
				label: "First credited",
				value: "2021"
			},
			{
				label: "Contract",
				value: "Helix House, 2022–"
			},
			{
				label: "Representation",
				value: "Mara Ellison, Redwood"
			}
		],
		credits: [
			{
				role: "Lead",
				title: "A Room in Silverlake",
				year: "2023",
				kind: "productions",
				id: "silverlake"
			},
			{
				role: "Lead",
				title: "Glass Harbor",
				year: "2023–",
				kind: "productions",
				id: "glass-harbor"
			},
			{
				role: "Supporting",
				title: "Wintering",
				year: "2022",
				kind: "productions",
				id: "wintering"
			}
		],
		related: [
			{
				kind: "agents",
				id: "mara-ellison"
			},
			{
				kind: "companies",
				id: "helix-house"
			},
			{
				kind: "performers",
				id: "isla-vane"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@juniperhale"
		}, {
			platform: "Vellum",
			handle: "juniper"
		}],
		source: "index"
	},
	{
		id: "mateo-ruiz",
		kind: "performers",
		name: "Mateo Ruiz",
		subtitle: "Performer · stills",
		summary: "Performer and stills photographer. Credits at Helix and Pine & Vale; campaigns for Copperline.",
		tags: ["performer", "photographer"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2018"
		}, {
			label: "Also",
			value: "Stills & campaigns"
		}],
		credits: [{
			role: "Lead",
			title: "Salt & Copper",
			year: "2023",
			kind: "productions",
			id: "salt-and-copper"
		}, {
			role: "Supporting",
			title: "Glass Harbor",
			year: "2022",
			kind: "productions",
			id: "glass-harbor"
		}],
		related: [{
			kind: "companies",
			id: "pine-vale"
		}, {
			kind: "companies",
			id: "copperline-pr"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@mateoruizstill"
		}],
		source: "index"
	},
	{
		id: "sable-quinn",
		kind: "performers",
		name: "Sable Quinn",
		subtitle: "Performer",
		summary: "Northstar exclusive 2019–2023. Known for long-form features; now splitting time between direction and Vellum.",
		tags: [
			"performer",
			"northstar",
			"features"
		],
		region: "Los Angeles",
		status: "Independent",
		facts: [{
			label: "First credited",
			value: "2016"
		}, {
			label: "Exclusive",
			value: "Northstar, 2019–2023"
		}],
		credits: [{
			role: "Lead",
			title: "The Night Ledger",
			year: "2021",
			kind: "productions",
			id: "the-night-ledger"
		}, {
			role: "Lead",
			title: "Eastern Standard",
			year: "2024",
			kind: "productions",
			id: "eastern-standard"
		}],
		related: [{
			kind: "companies",
			id: "northstar-pictures"
		}, {
			kind: "performers",
			id: "roman-calder"
		}],
		socials: [{
			platform: "X",
			handle: "@sablequinn"
		}, {
			platform: "Vellum",
			handle: "sable"
		}],
		source: "index"
	},
	{
		id: "theo-marsh",
		kind: "performers",
		name: "Theo Marsh",
		subtitle: "Performer",
		summary: "Helix and Nightjar. Palisade ensemble nominee with the Glass Harbor company, 2024.",
		tags: ["performer", "helix"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2020"
		}, {
			label: "Representation",
			value: "Redwood Talent"
		}],
		credits: [{
			role: "Ensemble",
			title: "Glass Harbor",
			year: "2021–",
			kind: "productions",
			id: "glass-harbor"
		}, {
			role: "Supporting",
			title: "Low Light",
			year: "2025",
			kind: "productions",
			id: "low-light"
		}],
		related: [{
			kind: "companies",
			id: "helix-house"
		}, {
			kind: "productions",
			id: "glass-harbor"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@theomarsh"
		}],
		source: "index"
	},
	{
		id: "liora-chen",
		kind: "performers",
		name: "Liora Chen",
		subtitle: "Performer",
		summary: "Bilingual talent booked between Los Angeles and Tokyo. Helix guest lead; Afterlight English-language days.",
		tags: [
			"performer",
			"tokyo",
			"los-angeles"
		],
		region: "Tokyo / Los Angeles",
		status: "Active",
		facts: [
			{
				label: "First credited",
				value: "2020"
			},
			{
				label: "Representation",
				value: "Haruki Mori"
			},
			{
				label: "Languages",
				value: "English, Japanese"
			}
		],
		credits: [{
			role: "Guest lead",
			title: "Glass Harbor",
			year: "2024",
			kind: "productions",
			id: "glass-harbor"
		}, {
			role: "Lead",
			title: "Corridor",
			year: "2025",
			kind: "productions",
			id: "corridor"
		}],
		related: [
			{
				kind: "agents",
				id: "haruki-mori"
			},
			{
				kind: "companies",
				id: "helix-house"
			},
			{
				kind: "companies",
				id: "afterlight-media"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@liorachen"
		}],
		source: "index"
	},
	{
		id: "cassian-wolfe",
		kind: "performers",
		name: "Cassian Wolfe",
		subtitle: "Performer",
		summary: "Helix contract, 2018–. Palisade Best Lead, 2022. Frequent pairing with Isla Vane and Juniper Hale.",
		tags: [
			"performer",
			"helix",
			"contract"
		],
		region: "Los Angeles",
		status: "Contract",
		facts: [
			{
				label: "First credited",
				value: "2017"
			},
			{
				label: "Contract",
				value: "Helix House, 2018–"
			},
			{
				label: "Representation",
				value: "Mara Ellison, Redwood"
			},
			{
				label: "Awards",
				value: "Palisade Best Lead, 2022"
			}
		],
		credits: [
			{
				role: "Lead",
				title: "Glass Harbor",
				year: "2018–",
				kind: "productions",
				id: "glass-harbor"
			},
			{
				role: "Lead",
				title: "Wintering",
				year: "2022",
				kind: "productions",
				id: "wintering"
			},
			{
				role: "Lead",
				title: "A Room in Silverlake",
				year: "2023",
				kind: "productions",
				id: "silverlake"
			}
		],
		related: [
			{
				kind: "agents",
				id: "mara-ellison"
			},
			{
				kind: "companies",
				id: "helix-house"
			},
			{
				kind: "performers",
				id: "isla-vane"
			}
		],
		socials: [{
			platform: "X",
			handle: "@cassianwolfe"
		}, {
			platform: "Instagram",
			handle: "@cassianwolfe"
		}],
		source: "index"
	},
	{
		id: "noa-pell",
		kind: "performers",
		name: "Noa Pell",
		subtitle: "Creator · performer",
		summary: "Direct-to-fan first. Vellum top-tier; selective studio days through Devon Reyes. Speaks on platform terms at Ledger Week.",
		tags: [
			"creator",
			"direct-to-fan",
			"vellum"
		],
		region: "Austin",
		status: "Independent",
		facts: [
			{
				label: "First credited",
				value: "2021"
			},
			{
				label: "Platform",
				value: "Vellum"
			},
			{
				label: "Representation",
				value: "Devon Reyes, Redwood"
			}
		],
		credits: [{
			role: "Creator",
			title: "Vellum studio",
			year: "2021–",
			kind: "companies",
			id: "vellum-digital"
		}, {
			role: "Guest",
			title: "Second Unit",
			year: "2025",
			kind: "productions",
			id: "second-unit"
		}],
		related: [
			{
				kind: "agents",
				id: "devon-reyes"
			},
			{
				kind: "companies",
				id: "vellum-digital"
			},
			{
				kind: "events",
				id: "ledger-week-2026"
			}
		],
		socials: [{
			platform: "Vellum",
			handle: "noa"
		}, {
			platform: "X",
			handle: "@noapell"
		}],
		source: "index"
	},
	{
		id: "evander-crowe",
		kind: "performers",
		name: "Evander Crowe",
		subtitle: "Director · performer",
		summary: "Director of The Night Ledger and Eastern Standard. Occasional on-camera credit. Nightjar partner.",
		tags: [
			"director",
			"performer",
			"northstar"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2012"
		}, {
			label: "Primary",
			value: "Direction"
		}],
		credits: [
			{
				role: "Director",
				title: "The Night Ledger",
				year: "2021",
				kind: "productions",
				id: "the-night-ledger"
			},
			{
				role: "Director",
				title: "Eastern Standard",
				year: "2024",
				kind: "productions",
				id: "eastern-standard"
			},
			{
				role: "Director",
				title: "The Palisade Brief",
				year: "2025",
				kind: "productions",
				id: "palisade-brief"
			}
		],
		related: [{
			kind: "companies",
			id: "northstar-pictures"
		}, {
			kind: "companies",
			id: "nightjar-films"
		}],
		socials: [{
			platform: "X",
			handle: "@evandercrowe"
		}],
		source: "index"
	},
	{
		id: "wren-solis",
		kind: "performers",
		name: "Wren Solis",
		subtitle: "Director · performer",
		summary: "Performer-director. Nightjar partner; directed Second Unit. Managed by Nina Braswell.",
		tags: [
			"director",
			"performer",
			"nightjar"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2015"
		}, {
			label: "Management",
			value: "Nina Braswell"
		}],
		credits: [
			{
				role: "Director",
				title: "Second Unit",
				year: "2025",
				kind: "productions",
				id: "second-unit"
			},
			{
				role: "Lead",
				title: "Low Light",
				year: "2025",
				kind: "productions",
				id: "low-light"
			},
			{
				role: "Supporting",
				title: "The Night Ledger",
				year: "2021",
				kind: "productions",
				id: "the-night-ledger"
			}
		],
		related: [
			{
				kind: "agents",
				id: "nina-braswell"
			},
			{
				kind: "companies",
				id: "nightjar-films"
			},
			{
				kind: "performers",
				id: "isla-vane"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@wrensolis"
		}, {
			platform: "X",
			handle: "@wrensolis"
		}],
		source: "index"
	},
	{
		id: "dax-harlan",
		kind: "performers",
		name: "Dax Harlan",
		subtitle: "Performer",
		summary: "Northstar and Helix supporting player. Palisade crafts nominee (ensemble), 2024.",
		tags: ["performer", "supporting"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2019"
		}],
		credits: [{
			role: "Supporting",
			title: "Eastern Standard",
			year: "2024",
			kind: "productions",
			id: "eastern-standard"
		}, {
			role: "Ensemble",
			title: "Glass Harbor",
			year: "2022–",
			kind: "productions",
			id: "glass-harbor"
		}],
		related: [{
			kind: "companies",
			id: "northstar-pictures"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@daxharlan"
		}],
		source: "index"
	},
	{
		id: "amara-voss",
		kind: "performers",
		name: "Amara Voss",
		subtitle: "Performer",
		summary: "Pine & Vale contract, Vancouver. Lead of Salt & Copper. Occasional Los Angeles days.",
		tags: [
			"performer",
			"vancouver",
			"pine-vale"
		],
		region: "Vancouver",
		status: "Contract",
		facts: [{
			label: "First credited",
			value: "2020"
		}, {
			label: "Contract",
			value: "Pine & Vale, 2021–"
		}],
		credits: [{
			role: "Lead",
			title: "Salt & Copper",
			year: "2023",
			kind: "productions",
			id: "salt-and-copper"
		}, {
			role: "Guest",
			title: "Glass Harbor",
			year: "2024",
			kind: "productions",
			id: "glass-harbor"
		}],
		related: [{
			kind: "companies",
			id: "pine-vale"
		}, {
			kind: "performers",
			id: "maren-dahl"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@amaravoss"
		}],
		source: "index"
	},
	{
		id: "nico-bell",
		kind: "performers",
		name: "Nico Bell",
		subtitle: "Performer",
		summary: "Helix and Cobalt. Live-ticketed shows plus studio days; talks age-assurance at Counsel Day.",
		tags: [
			"performer",
			"live",
			"cobalt"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2018"
		}, {
			label: "Live",
			value: "Cobalt"
		}],
		credits: [{
			role: "Host",
			title: "Cobalt nights",
			year: "2019–",
			kind: "companies",
			id: "cobalt-interactive"
		}, {
			role: "Supporting",
			title: "A Room in Silverlake",
			year: "2023",
			kind: "productions",
			id: "silverlake"
		}],
		related: [{
			kind: "companies",
			id: "cobalt-interactive"
		}, {
			kind: "events",
			id: "counsel-day-2026"
		}],
		socials: [{
			platform: "Cobalt",
			handle: "nicobell"
		}, {
			platform: "X",
			handle: "@nicobell"
		}],
		source: "index"
	},
	{
		id: "percy-lane",
		kind: "performers",
		name: "Persephone Lane",
		subtitle: "Performer",
		aka: ["Percy Lane"],
		summary: "Trans performer-director. Nightjar and independent Vellum. Managed by Nina Braswell. Palisade Breakthrough, 2023.",
		tags: [
			"performer",
			"director",
			"trans"
		],
		region: "Los Angeles",
		status: "Independent",
		facts: [
			{
				label: "First credited",
				value: "2020"
			},
			{
				label: "Management",
				value: "Nina Braswell"
			},
			{
				label: "Awards",
				value: "Palisade Breakthrough, 2023"
			}
		],
		credits: [{
			role: "Lead",
			title: "Second Unit",
			year: "2025",
			kind: "productions",
			id: "second-unit"
		}, {
			role: "Lead",
			title: "Low Light",
			year: "2025",
			kind: "productions",
			id: "low-light"
		}],
		related: [
			{
				kind: "agents",
				id: "nina-braswell"
			},
			{
				kind: "companies",
				id: "nightjar-films"
			},
			{
				kind: "performers",
				id: "wren-solis"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@percylane"
		}, {
			platform: "Vellum",
			handle: "percy"
		}],
		source: "index"
	},
	{
		id: "kade-morin",
		kind: "performers",
		name: "Kade Morin",
		subtitle: "Performer · live",
		summary: "Cobalt headliner who crossed into Helix guest days. Direct-to-fan on Vellum.",
		tags: [
			"performer",
			"live",
			"cobalt"
		],
		region: "Miami",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2019"
		}, {
			label: "Live",
			value: "Cobalt"
		}],
		credits: [{
			role: "Headliner",
			title: "Cobalt",
			year: "2019–",
			kind: "companies",
			id: "cobalt-interactive"
		}, {
			role: "Guest",
			title: "Glass Harbor",
			year: "2023",
			kind: "productions",
			id: "glass-harbor"
		}],
		related: [{
			kind: "companies",
			id: "cobalt-interactive"
		}, {
			kind: "companies",
			id: "vellum-digital"
		}],
		socials: [{
			platform: "Cobalt",
			handle: "kade"
		}, {
			platform: "Vellum",
			handle: "kade"
		}],
		source: "index"
	},
	{
		id: "yara-okonkwo",
		kind: "performers",
		name: "Yara Okonkwo",
		subtitle: "Performer",
		summary: "Northstar lead. Eastern Standard opposite Roman Calder. Palisade Best Lead nominee, 2025.",
		tags: [
			"performer",
			"northstar",
			"features"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2018"
		}, {
			label: "Awards",
			value: "Palisade Best Lead nominee, 2025"
		}],
		credits: [{
			role: "Lead",
			title: "Eastern Standard",
			year: "2024",
			kind: "productions",
			id: "eastern-standard"
		}, {
			role: "Lead",
			title: "The Palisade Brief",
			year: "2025",
			kind: "productions",
			id: "palisade-brief"
		}],
		related: [{
			kind: "companies",
			id: "northstar-pictures"
		}, {
			kind: "performers",
			id: "roman-calder"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@yaraokonkwo"
		}, {
			platform: "X",
			handle: "@yaraokonkwo"
		}],
		source: "index"
	},
	{
		id: "ellis-hart",
		kind: "performers",
		name: "Ellis Hart",
		subtitle: "Performer",
		summary: "Non-binary performer. Nightjar and Vellum. Palisade ensemble, 2025.",
		tags: ["performer", "nightjar"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2022"
		}, {
			label: "Management",
			value: "Nina Braswell"
		}],
		credits: [{
			role: "Ensemble",
			title: "Second Unit",
			year: "2025",
			kind: "productions",
			id: "second-unit"
		}, {
			role: "Supporting",
			title: "Low Light",
			year: "2025",
			kind: "productions",
			id: "low-light"
		}],
		related: [{
			kind: "agents",
			id: "nina-braswell"
		}, {
			kind: "companies",
			id: "nightjar-films"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@ellishart"
		}, {
			platform: "Vellum",
			handle: "ellis"
		}],
		source: "index"
	},
	{
		id: "maren-dahl",
		kind: "performers",
		name: "Maren Dahl",
		subtitle: "Performer · director",
		summary: "Pine & Vale partner in Vancouver. Directed Salt & Copper; stills background.",
		tags: [
			"performer",
			"director",
			"vancouver"
		],
		region: "Vancouver",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2016"
		}, {
			label: "House",
			value: "Pine & Vale"
		}],
		credits: [{
			role: "Director / lead",
			title: "Salt & Copper",
			year: "2023",
			kind: "productions",
			id: "salt-and-copper"
		}],
		related: [{
			kind: "companies",
			id: "pine-vale"
		}, {
			kind: "performers",
			id: "amara-voss"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@marendahl"
		}],
		source: "index"
	},
	{
		id: "felix-arden",
		kind: "performers",
		name: "Felix Arden",
		subtitle: "Performer",
		summary: "Afterlight contract, Berlin. English- and German-language credits. Venus Berlin regular.",
		tags: [
			"performer",
			"berlin",
			"afterlight"
		],
		region: "Berlin",
		status: "Contract",
		facts: [{
			label: "First credited",
			value: "2021"
		}, {
			label: "Representation",
			value: "Sabine Köhler"
		}],
		credits: [{
			role: "Lead",
			title: "Corridor",
			year: "2025",
			kind: "productions",
			id: "corridor"
		}],
		related: [
			{
				kind: "agents",
				id: "sabine-kohler"
			},
			{
				kind: "companies",
				id: "afterlight-media"
			},
			{
				kind: "events",
				id: "venus-berlin-2026"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@felixarden"
		}],
		source: "index"
	},
	{
		id: "sienna-park",
		kind: "performers",
		name: "Sienna Park",
		subtitle: "Performer",
		summary: "Pine & Vale and Helix guest. Split representation: Devon Reyes (D2F) and Haruki Mori (Pacific studio days).",
		tags: [
			"performer",
			"vancouver",
			"los-angeles"
		],
		region: "Vancouver",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2020"
		}, {
			label: "Representation",
			value: "Reyes / Mori"
		}],
		credits: [{
			role: "Supporting",
			title: "Salt & Copper",
			year: "2023",
			kind: "productions",
			id: "salt-and-copper"
		}, {
			role: "Guest",
			title: "Wintering",
			year: "2022",
			kind: "productions",
			id: "wintering"
		}],
		related: [
			{
				kind: "agents",
				id: "devon-reyes"
			},
			{
				kind: "agents",
				id: "haruki-mori"
			},
			{
				kind: "companies",
				id: "pine-vale"
			}
		],
		socials: [{
			platform: "Vellum",
			handle: "sienna"
		}, {
			platform: "Instagram",
			handle: "@siennapark"
		}],
		source: "index"
	},
	{
		id: "omar-leclerc",
		kind: "performers",
		name: "Omar Leclerc",
		subtitle: "Performer",
		summary: "Afterlight lead. French-English bilingual. Corridor opposite Liora Chen and Tamsin Rowe.",
		tags: [
			"performer",
			"berlin",
			"paris"
		],
		region: "Berlin / Paris",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2017"
		}, {
			label: "Representation",
			value: "Sabine Köhler"
		}],
		credits: [{
			role: "Lead",
			title: "Corridor",
			year: "2025",
			kind: "productions",
			id: "corridor"
		}],
		related: [
			{
				kind: "agents",
				id: "sabine-kohler"
			},
			{
				kind: "companies",
				id: "afterlight-media"
			},
			{
				kind: "performers",
				id: "tamsin-rowe"
			}
		],
		socials: [{
			platform: "Instagram",
			handle: "@omarleclerc"
		}],
		source: "index"
	},
	{
		id: "tamsin-rowe",
		kind: "performers",
		name: "Tamsin Rowe",
		subtitle: "Performer · producer",
		summary: "Afterlight producer-performer. UK-born, Berlin-based. Advises on Online Safety Act storefront copy.",
		tags: [
			"performer",
			"producer",
			"berlin",
			"uk"
		],
		region: "Berlin",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2015"
		}, {
			label: "Representation",
			value: "Sabine Köhler"
		}],
		credits: [{
			role: "Producer / lead",
			title: "Corridor",
			year: "2025",
			kind: "productions",
			id: "corridor"
		}],
		related: [
			{
				kind: "agents",
				id: "sabine-kohler"
			},
			{
				kind: "companies",
				id: "afterlight-media"
			},
			{
				kind: "law",
				id: "uk-online-safety"
			}
		],
		socials: [{
			platform: "X",
			handle: "@tamsinrowe"
		}, {
			platform: "Instagram",
			handle: "@tamsinrowe"
		}],
		source: "index"
	},
	{
		id: "bo-calder",
		kind: "performers",
		name: "Bo Calder",
		subtitle: "Performer",
		summary: "Younger Calder. Helix guest and Vellum. First credited 2022.",
		tags: ["performer", "helix"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2022"
		}, {
			label: "Family",
			value: "Sibling of Roman Calder"
		}],
		credits: [{
			role: "Guest",
			title: "Glass Harbor",
			year: "2023",
			kind: "productions",
			id: "glass-harbor"
		}, {
			role: "Supporting",
			title: "A Room in Silverlake",
			year: "2023",
			kind: "productions",
			id: "silverlake"
		}],
		related: [{
			kind: "performers",
			id: "roman-calder",
			label: "Sibling"
		}, {
			kind: "companies",
			id: "helix-house"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@bocalder"
		}, {
			platform: "Vellum",
			handle: "bo"
		}],
		source: "index"
	},
	{
		id: "rivka-stein",
		kind: "performers",
		name: "Rivka Stein",
		subtitle: "Performer · writer",
		summary: "Wrote The Palisade Brief for Northstar; occasional on-camera. Craft-side Palisade nominee, 2025.",
		tags: [
			"writer",
			"performer",
			"northstar"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2017"
		}, {
			label: "Primary",
			value: "Writing"
		}],
		credits: [{
			role: "Writer",
			title: "The Palisade Brief",
			year: "2025",
			kind: "productions",
			id: "palisade-brief"
		}, {
			role: "Writer",
			title: "Eastern Standard",
			year: "2024",
			kind: "productions",
			id: "eastern-standard"
		}],
		related: [{
			kind: "companies",
			id: "northstar-pictures"
		}, {
			kind: "performers",
			id: "evander-crowe"
		}],
		socials: [{
			platform: "X",
			handle: "@rivkastein"
		}],
		source: "index"
	},
	{
		id: "gideon-vale",
		kind: "performers",
		name: "Gideon Vale",
		subtitle: "Performer",
		summary: "Nightjar ensemble. Supporting in Low Light and Second Unit.",
		tags: ["performer", "nightjar"],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2021"
		}],
		credits: [{
			role: "Supporting",
			title: "Low Light",
			year: "2025",
			kind: "productions",
			id: "low-light"
		}, {
			role: "Ensemble",
			title: "Second Unit",
			year: "2025",
			kind: "productions",
			id: "second-unit"
		}],
		related: [{
			kind: "companies",
			id: "nightjar-films"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@gideonvale"
		}],
		source: "index"
	},
	{
		id: "aisha-nasser",
		kind: "performers",
		name: "Aisha Nasser",
		subtitle: "Creator · performer",
		summary: "Vellum-native creator. Devon Reyes client. Speaks on card-network rules and 2257 for solo producers.",
		tags: [
			"creator",
			"direct-to-fan",
			"vellum"
		],
		region: "Chicago",
		status: "Independent",
		facts: [{
			label: "First credited",
			value: "2022"
		}, {
			label: "Representation",
			value: "Devon Reyes, Redwood"
		}],
		credits: [{
			role: "Creator",
			title: "Vellum studio",
			year: "2022–",
			kind: "companies",
			id: "vellum-digital"
		}],
		related: [
			{
				kind: "agents",
				id: "devon-reyes"
			},
			{
				kind: "companies",
				id: "vellum-digital"
			},
			{
				kind: "law",
				id: "usc-2257"
			},
			{
				kind: "law",
				id: "card-networks"
			}
		],
		socials: [{
			platform: "Vellum",
			handle: "aisha"
		}, {
			platform: "X",
			handle: "@aishanasser"
		}],
		source: "index"
	},
	{
		id: "cole-brennan",
		kind: "performers",
		name: "Cole Brennan",
		subtitle: "Performer",
		summary: "Helix supporting and Northstar features. Palisade ensemble, 2024.",
		tags: [
			"performer",
			"helix",
			"northstar"
		],
		region: "Los Angeles",
		status: "Active",
		facts: [{
			label: "First credited",
			value: "2018"
		}],
		credits: [
			{
				role: "Supporting",
				title: "Wintering",
				year: "2022",
				kind: "productions",
				id: "wintering"
			},
			{
				role: "Supporting",
				title: "The Night Ledger",
				year: "2021",
				kind: "productions",
				id: "the-night-ledger"
			},
			{
				role: "Ensemble",
				title: "Glass Harbor",
				year: "2020–",
				kind: "productions",
				id: "glass-harbor"
			}
		],
		related: [{
			kind: "companies",
			id: "helix-house"
		}, {
			kind: "companies",
			id: "northstar-pictures"
		}],
		socials: [{
			platform: "Instagram",
			handle: "@colebrennan"
		}],
		source: "index"
	},
	{
		id: "glass-harbor",
		kind: "productions",
		name: "Glass Harbor",
		subtitle: "Series · Helix House",
		summary: "Helix House flagship series, 2018–. Rotating company, director-led episodes, Palisade ensemble winner 2024.",
		body: "Glass Harbor is the standing series against which Helix House contracts are measured. Episodes are credited to individual directors; Jonah Peck casts a rotating company. The 2024 Palisade ensemble award went to the Harbor company.",
		tags: [
			"series",
			"helix",
			"flagship"
		],
		region: "Los Angeles",
		status: "Ongoing",
		facts: [
			{
				label: "Studio",
				value: "Helix House"
			},
			{
				label: "Years",
				value: "2018–"
			},
			{
				label: "Casting",
				value: "Jonah Peck, Meridian"
			},
			{
				label: "Awards",
				value: "Palisade Ensemble, 2024"
			}
		],
		credits: [
			{
				role: "Studio",
				title: "Helix House",
				year: "2018–",
				kind: "companies",
				id: "helix-house"
			},
			{
				role: "Casting",
				title: "Jonah Peck",
				year: "2018–",
				kind: "agents",
				id: "jonah-peck"
			},
			{
				role: "Lead",
				title: "Cassian Wolfe",
				year: "2018–",
				kind: "performers",
				id: "cassian-wolfe"
			},
			{
				role: "Lead",
				title: "Isla Vane",
				year: "2020–24",
				kind: "performers",
				id: "isla-vane"
			},
			{
				role: "Lead",
				title: "Juniper Hale",
				year: "2023–",
				kind: "performers",
				id: "juniper-hale"
			}
		],
		related: [
			{
				kind: "companies",
				id: "helix-house"
			},
			{
				kind: "performers",
				id: "cassian-wolfe"
			},
			{
				kind: "performers",
				id: "isla-vane"
			}
		],
		source: "index"
	},
	{
		id: "wintering",
		kind: "productions",
		name: "Wintering",
		subtitle: "Feature · Helix House",
		summary: "2022 Helix feature. Isla Vane and Cassian Wolfe. Palisade Best Feature nominee.",
		tags: ["feature", "helix"],
		region: "Los Angeles",
		status: "Released",
		facts: [
			{
				label: "Studio",
				value: "Helix House"
			},
			{
				label: "Year",
				value: "2022"
			},
			{
				label: "Distribution",
				value: "Eastbound"
			}
		],
		credits: [
			{
				role: "Lead",
				title: "Isla Vane",
				year: "2022",
				kind: "performers",
				id: "isla-vane"
			},
			{
				role: "Lead",
				title: "Cassian Wolfe",
				year: "2022",
				kind: "performers",
				id: "cassian-wolfe"
			},
			{
				role: "Supporting",
				title: "Juniper Hale",
				year: "2022",
				kind: "performers",
				id: "juniper-hale"
			},
			{
				role: "Supporting",
				title: "Cole Brennan",
				year: "2022",
				kind: "performers",
				id: "cole-brennan"
			}
		],
		related: [{
			kind: "companies",
			id: "helix-house"
		}, {
			kind: "companies",
			id: "eastbound"
		}],
		source: "index"
	},
	{
		id: "silverlake",
		kind: "productions",
		name: "A Room in Silverlake",
		subtitle: "Feature · Helix House",
		summary: "2023 feature that made Juniper Hale. Location-heavy, stills by Mateo Ruiz.",
		tags: ["feature", "helix"],
		region: "Los Angeles",
		status: "Released",
		facts: [{
			label: "Studio",
			value: "Helix House"
		}, {
			label: "Year",
			value: "2023"
		}],
		credits: [
			{
				role: "Lead",
				title: "Juniper Hale",
				year: "2023",
				kind: "performers",
				id: "juniper-hale"
			},
			{
				role: "Lead",
				title: "Isla Vane",
				year: "2023",
				kind: "performers",
				id: "isla-vane"
			},
			{
				role: "Lead",
				title: "Cassian Wolfe",
				year: "2023",
				kind: "performers",
				id: "cassian-wolfe"
			},
			{
				role: "Supporting",
				title: "Nico Bell",
				year: "2023",
				kind: "performers",
				id: "nico-bell"
			}
		],
		related: [{
			kind: "companies",
			id: "helix-house"
		}],
		source: "index"
	},
	{
		id: "the-night-ledger",
		kind: "productions",
		name: "The Night Ledger",
		subtitle: "Feature · Northstar",
		summary: "2021 Northstar feature directed by Evander Crowe. Palisade Best Feature, 2022.",
		tags: [
			"feature",
			"northstar",
			"award"
		],
		region: "Los Angeles",
		status: "Released",
		facts: [
			{
				label: "Studio",
				value: "Northstar Pictures"
			},
			{
				label: "Year",
				value: "2021"
			},
			{
				label: "Director",
				value: "Evander Crowe"
			},
			{
				label: "Awards",
				value: "Palisade Best Feature, 2022"
			}
		],
		credits: [
			{
				role: "Director",
				title: "Evander Crowe",
				year: "2021",
				kind: "performers",
				id: "evander-crowe"
			},
			{
				role: "Lead",
				title: "Sable Quinn",
				year: "2021",
				kind: "performers",
				id: "sable-quinn"
			},
			{
				role: "Lead",
				title: "Roman Calder",
				year: "2021",
				kind: "performers",
				id: "roman-calder"
			},
			{
				role: "Supporting",
				title: "Wren Solis",
				year: "2021",
				kind: "performers",
				id: "wren-solis"
			}
		],
		related: [{
			kind: "companies",
			id: "northstar-pictures"
		}, {
			kind: "performers",
			id: "evander-crowe"
		}],
		source: "index"
	},
	{
		id: "eastern-standard",
		kind: "productions",
		name: "Eastern Standard",
		subtitle: "Feature · Northstar",
		summary: "2024 Crowe/Stein collaboration. Yara Okonkwo and Roman Calder. Palisade Best Lead nominee (Okonkwo), 2025.",
		tags: ["feature", "northstar"],
		region: "Los Angeles",
		status: "Released",
		facts: [
			{
				label: "Studio",
				value: "Northstar Pictures"
			},
			{
				label: "Year",
				value: "2024"
			},
			{
				label: "Director",
				value: "Evander Crowe"
			},
			{
				label: "Writer",
				value: "Rivka Stein"
			}
		],
		credits: [
			{
				role: "Director",
				title: "Evander Crowe",
				year: "2024",
				kind: "performers",
				id: "evander-crowe"
			},
			{
				role: "Writer",
				title: "Rivka Stein",
				year: "2024",
				kind: "performers",
				id: "rivka-stein"
			},
			{
				role: "Lead",
				title: "Yara Okonkwo",
				year: "2024",
				kind: "performers",
				id: "yara-okonkwo"
			},
			{
				role: "Lead",
				title: "Roman Calder",
				year: "2024",
				kind: "performers",
				id: "roman-calder"
			}
		],
		related: [{
			kind: "companies",
			id: "northstar-pictures"
		}],
		source: "index"
	},
	{
		id: "palisade-brief",
		kind: "productions",
		name: "The Palisade Brief",
		subtitle: "Feature · Northstar",
		summary: "2025 Northstar title written by Rivka Stein. A feature about a counsel's office — meta, on purpose.",
		tags: ["feature", "northstar"],
		region: "Los Angeles",
		status: "Released",
		facts: [{
			label: "Studio",
			value: "Northstar Pictures"
		}, {
			label: "Year",
			value: "2025"
		}],
		credits: [
			{
				role: "Director",
				title: "Evander Crowe",
				year: "2025",
				kind: "performers",
				id: "evander-crowe"
			},
			{
				role: "Writer",
				title: "Rivka Stein",
				year: "2025",
				kind: "performers",
				id: "rivka-stein"
			},
			{
				role: "Lead",
				title: "Yara Okonkwo",
				year: "2025",
				kind: "performers",
				id: "yara-okonkwo"
			}
		],
		related: [{
			kind: "companies",
			id: "northstar-pictures"
		}, {
			kind: "companies",
			id: "palisade-institute"
		}],
		source: "index"
	},
	{
		id: "low-light",
		kind: "productions",
		name: "Low Light",
		subtitle: "Feature · Nightjar",
		summary: "Isla Vane's directing debut, 2025. Wren Solis and Percy Lane. Nightjar imprint.",
		tags: [
			"feature",
			"nightjar",
			"directing-debut"
		],
		region: "Los Angeles",
		status: "Released",
		facts: [
			{
				label: "Studio",
				value: "Nightjar Films"
			},
			{
				label: "Year",
				value: "2025"
			},
			{
				label: "Director",
				value: "Isla Vane"
			}
		],
		credits: [
			{
				role: "Director",
				title: "Isla Vane",
				year: "2025",
				kind: "performers",
				id: "isla-vane"
			},
			{
				role: "Lead",
				title: "Wren Solis",
				year: "2025",
				kind: "performers",
				id: "wren-solis"
			},
			{
				role: "Lead",
				title: "Persephone Lane",
				year: "2025",
				kind: "performers",
				id: "percy-lane"
			},
			{
				role: "Supporting",
				title: "Ellis Hart",
				year: "2025",
				kind: "performers",
				id: "ellis-hart"
			}
		],
		related: [{
			kind: "companies",
			id: "nightjar-films"
		}, {
			kind: "performers",
			id: "isla-vane"
		}],
		source: "index"
	},
	{
		id: "second-unit",
		kind: "productions",
		name: "Second Unit",
		subtitle: "Feature · Nightjar",
		summary: "Wren Solis directs. Percy Lane, Ellis Hart, Noa Pell guest. 2025.",
		tags: ["feature", "nightjar"],
		region: "Los Angeles",
		status: "Released",
		facts: [
			{
				label: "Studio",
				value: "Nightjar Films"
			},
			{
				label: "Year",
				value: "2025"
			},
			{
				label: "Director",
				value: "Wren Solis"
			}
		],
		credits: [
			{
				role: "Director",
				title: "Wren Solis",
				year: "2025",
				kind: "performers",
				id: "wren-solis"
			},
			{
				role: "Lead",
				title: "Persephone Lane",
				year: "2025",
				kind: "performers",
				id: "percy-lane"
			},
			{
				role: "Ensemble",
				title: "Ellis Hart",
				year: "2025",
				kind: "performers",
				id: "ellis-hart"
			},
			{
				role: "Guest",
				title: "Noa Pell",
				year: "2025",
				kind: "performers",
				id: "noa-pell"
			}
		],
		related: [{
			kind: "companies",
			id: "nightjar-films"
		}],
		source: "index"
	},
	{
		id: "corridor",
		kind: "productions",
		name: "Corridor",
		subtitle: "Feature · Afterlight",
		summary: "2025 Berlin feature produced by Tamsin Rowe. English-language, shot for EU and North American sales.",
		tags: [
			"feature",
			"afterlight",
			"berlin"
		],
		region: "Berlin",
		status: "Released",
		facts: [
			{
				label: "Studio",
				value: "Afterlight Media"
			},
			{
				label: "Year",
				value: "2025"
			},
			{
				label: "Producer",
				value: "Tamsin Rowe"
			},
			{
				label: "Sales",
				value: "Eastbound (English)"
			}
		],
		credits: [
			{
				role: "Producer / lead",
				title: "Tamsin Rowe",
				year: "2025",
				kind: "performers",
				id: "tamsin-rowe"
			},
			{
				role: "Lead",
				title: "Omar Leclerc",
				year: "2025",
				kind: "performers",
				id: "omar-leclerc"
			},
			{
				role: "Lead",
				title: "Liora Chen",
				year: "2025",
				kind: "performers",
				id: "liora-chen"
			},
			{
				role: "Lead",
				title: "Felix Arden",
				year: "2025",
				kind: "performers",
				id: "felix-arden"
			}
		],
		related: [
			{
				kind: "companies",
				id: "afterlight-media"
			},
			{
				kind: "companies",
				id: "eastbound"
			},
			{
				kind: "events",
				id: "venus-berlin-2026"
			}
		],
		source: "index"
	},
	{
		id: "salt-and-copper",
		kind: "productions",
		name: "Salt & Copper",
		subtitle: "Feature · Pine & Vale",
		summary: "Maren Dahl directs in Vancouver, 2023. Amara Voss and Mateo Ruiz. Stills-led campaign.",
		tags: [
			"feature",
			"pine-vale",
			"vancouver"
		],
		region: "Vancouver",
		status: "Released",
		facts: [
			{
				label: "Studio",
				value: "Pine & Vale"
			},
			{
				label: "Year",
				value: "2023"
			},
			{
				label: "Director",
				value: "Maren Dahl"
			}
		],
		credits: [
			{
				role: "Director / lead",
				title: "Maren Dahl",
				year: "2023",
				kind: "performers",
				id: "maren-dahl"
			},
			{
				role: "Lead",
				title: "Amara Voss",
				year: "2023",
				kind: "performers",
				id: "amara-voss"
			},
			{
				role: "Lead",
				title: "Mateo Ruiz",
				year: "2023",
				kind: "performers",
				id: "mateo-ruiz"
			},
			{
				role: "Supporting",
				title: "Sienna Park",
				year: "2023",
				kind: "performers",
				id: "sienna-park"
			}
		],
		related: [{
			kind: "companies",
			id: "pine-vale"
		}],
		source: "index"
	}
];
var desk = [
	{
		id: "xbiz-2026",
		kind: "events",
		name: "XBIZ 2026",
		subtitle: "Trade show · Hollywood",
		summary: "North American flagship adult-industry trade show. Studios, platforms, talent, and buyers. 12–15 January 2026, Hollywood.",
		body: "XBIZ is the principal West Coast trade gathering: meetings, product, and the XBIZ Awards. The 2026 edition ran 12–15 January in Hollywood. fleshsesh indexes it as a public calendar record.",
		tags: [
			"trade-show",
			"awards",
			"hollywood",
			"public"
		],
		region: "Hollywood, California",
		status: "Past",
		venue: "Hollywood, California",
		dateStart: "2026-01-12",
		dateEnd: "2026-01-15",
		facts: [
			{
				label: "When",
				value: "12–15 January 2026"
			},
			{
				label: "Where",
				value: "Hollywood, California"
			},
			{
				label: "Type",
				value: "Trade show & awards"
			}
		],
		related: [
			{
				kind: "companies",
				id: "copperline-pr"
			},
			{
				kind: "companies",
				id: "fsc"
			},
			{
				kind: "events",
				id: "avn-expo-2026"
			}
		],
		socials: [{
			platform: "Site",
			handle: "xbiz.com"
		}],
		source: "public"
	},
	{
		id: "avn-expo-2026",
		kind: "events",
		name: "AVN Expo 2026",
		subtitle: "Expo · Las Vegas",
		summary: "Largest U.S. adult expo. Floor, seminars, and the AVN Awards. 21–24 January 2026, Virgin Hotels Las Vegas.",
		body: "The AVN Expo (Adult Entertainment Expo) concentrates studios, pleasure brands, talent, and press in Las Vegas each January. The 2026 show ran 21–24 January at Virgin Hotels Las Vegas. Awards night sits inside the same week.",
		tags: [
			"expo",
			"awards",
			"las-vegas",
			"public"
		],
		region: "Las Vegas",
		status: "Past",
		venue: "Virgin Hotels Las Vegas",
		dateStart: "2026-01-21",
		dateEnd: "2026-01-24",
		facts: [
			{
				label: "When",
				value: "21–24 January 2026"
			},
			{
				label: "Where",
				value: "Virgin Hotels Las Vegas"
			},
			{
				label: "Type",
				value: "Expo & awards"
			}
		],
		related: [
			{
				kind: "events",
				id: "palisade-honors-2026"
			},
			{
				kind: "companies",
				id: "eastbound"
			},
			{
				kind: "companies",
				id: "fsc"
			}
		],
		socials: [{
			platform: "Site",
			handle: "avn.com"
		}],
		source: "public"
	},
	{
		id: "venus-berlin-2026",
		kind: "events",
		name: "Venus Berlin 2026",
		subtitle: "Trade fair · Berlin",
		summary: "Europe's largest adult products and multimedia fair. 22–25 October 2026, Messe Berlin.",
		body: "Venus Berlin, held since the mid-1990s at the Messegelände, is the European trade and consumer fair for adult products, platforms, and performance. The 2026 edition is 22–25 October. Afterlight Media and Sabine Köhler's book typically work the floor.",
		tags: [
			"trade-fair",
			"berlin",
			"europe",
			"public",
			"upcoming"
		],
		region: "Berlin",
		status: "Upcoming",
		venue: "Messe Berlin",
		dateStart: "2026-10-22",
		dateEnd: "2026-10-25",
		facts: [
			{
				label: "When",
				value: "22–25 October 2026"
			},
			{
				label: "Where",
				value: "Messe Berlin"
			},
			{
				label: "Type",
				value: "Trade fair"
			}
		],
		related: [
			{
				kind: "companies",
				id: "afterlight-media"
			},
			{
				kind: "agents",
				id: "sabine-kohler"
			},
			{
				kind: "productions",
				id: "corridor"
			}
		],
		socials: [{
			platform: "Site",
			handle: "venus-berlin.com"
		}],
		source: "public"
	},
	{
		id: "palisade-honors-2026",
		kind: "events",
		name: "Palisade Honors 2026",
		subtitle: "Awards · Las Vegas",
		summary: "Palisade Institute's annual craft ballot and ceremony, held during Las Vegas expo week.",
		tags: ["awards", "las-vegas"],
		region: "Las Vegas",
		status: "Past",
		venue: "Las Vegas",
		dateStart: "2026-01-23",
		facts: [{
			label: "When",
			value: "23 January 2026"
		}, {
			label: "Body",
			value: "Palisade Institute"
		}],
		related: [
			{
				kind: "companies",
				id: "palisade-institute"
			},
			{
				kind: "events",
				id: "avn-expo-2026"
			},
			{
				kind: "productions",
				id: "glass-harbor"
			}
		],
		source: "index"
	},
	{
		id: "nightjar-forum-2026",
		kind: "events",
		name: "Nightjar Forum 2026",
		subtitle: "Creator & director forum",
		summary: "Small Los Angeles forum for performer-directors, stills, and independent slates. 12–14 November 2026.",
		tags: [
			"forum",
			"directors",
			"los-angeles",
			"upcoming"
		],
		region: "Los Angeles",
		status: "Upcoming",
		venue: "Los Angeles",
		dateStart: "2026-11-12",
		dateEnd: "2026-11-14",
		facts: [{
			label: "When",
			value: "12–14 November 2026"
		}, {
			label: "Host",
			value: "Nightjar Films"
		}],
		related: [
			{
				kind: "companies",
				id: "nightjar-films"
			},
			{
				kind: "performers",
				id: "wren-solis"
			},
			{
				kind: "performers",
				id: "isla-vane"
			}
		],
		source: "index"
	},
	{
		id: "counsel-day-2026",
		kind: "events",
		name: "Counsel Day 2026",
		subtitle: "Legal briefing",
		summary: "Annual CLE-style briefing from Counsel Group: 2257, state age-verification maps, TAKE IT DOWN, and card-network rules. 18 September 2026, Los Angeles.",
		tags: [
			"legal",
			"compliance",
			"los-angeles",
			"upcoming"
		],
		region: "Los Angeles",
		status: "Upcoming",
		venue: "Los Angeles",
		dateStart: "2026-09-18",
		facts: [{
			label: "When",
			value: "18 September 2026"
		}, {
			label: "Host",
			value: "Counsel Group"
		}],
		related: [
			{
				kind: "companies",
				id: "counsel-group"
			},
			{
				kind: "law",
				id: "usc-2257"
			},
			{
				kind: "law",
				id: "fsc-v-paxton"
			},
			{
				kind: "law",
				id: "take-it-down"
			},
			{
				kind: "performers",
				id: "nico-bell"
			}
		],
		source: "index"
	},
	{
		id: "ledger-week-2026",
		kind: "events",
		name: "Ledger Week 2026",
		subtitle: "Creator convening",
		summary: "Direct-to-fan and platform week. Panels on 2257 for solo producers, payments, and notice-and-removal. March 2026, Phoenix.",
		tags: [
			"creators",
			"platforms",
			"phoenix"
		],
		region: "Phoenix",
		status: "Past",
		venue: "Phoenix, Arizona",
		dateStart: "2026-03-04",
		dateEnd: "2026-03-07",
		facts: [{
			label: "When",
			value: "4–7 March 2026"
		}, {
			label: "Where",
			value: "Phoenix"
		}],
		related: [
			{
				kind: "performers",
				id: "noa-pell"
			},
			{
				kind: "companies",
				id: "vellum-digital"
			},
			{
				kind: "law",
				id: "usc-2257"
			}
		],
		source: "index"
	},
	{
		id: "usc-2257",
		kind: "law",
		name: "18 U.S.C. § 2257",
		subtitle: "Record-keeping requirements",
		citation: "18 U.S.C. § 2257",
		jurisdiction: "United States (federal)",
		summary: "Federal criminal statute requiring producers of actual sexually explicit visual depictions to examine picture identification, keep indexed records, and affix a custodian statement to every copy — including every webpage.",
		body: "Section 2257 is the backbone of adult-industry compliance in the United States. Anyone who produces visual depictions of actual sexually explicit conduct must, before production, examine a government-issued picture identification document for every performer, record the legal name and date of birth, cross-index every alias and stage name, and keep those records available for inspection. A statement naming the Custodian of Records and a physical address must appear on every copy, including every page of a website on which the matter appears.\n\nPrimary producers (the people who actually shoot) and secondary producers (those who duplicate, manage content, or publish) both have duties; platforms such as Vellum typically take a secondary-producer posture while creators remain primary producers of their own work. Failure is a federal felony — up to five years for a first offense.\n\nThis is a summary of public law, not legal advice. Producers should retain qualified counsel and read 28 C.F.R. Part 75 alongside the statute.",
		tags: [
			"federal",
			"2257",
			"records",
			"criminal",
			"producers"
		],
		status: "In force",
		facts: [
			{
				label: "Citation",
				value: "18 U.S.C. § 2257"
			},
			{
				label: "Enacted posture",
				value: "Post-1990 depictions"
			},
			{
				label: "Penalty",
				value: "Felony; up to 5 years (first)"
			},
			{
				label: "Companion",
				value: "28 C.F.R. Part 75"
			}
		],
		related: [
			{
				kind: "law",
				id: "usc-2257a"
			},
			{
				kind: "law",
				id: "cfr-28-75"
			},
			{
				kind: "companies",
				id: "helix-house"
			},
			{
				kind: "companies",
				id: "vellum-digital"
			},
			{
				kind: "companies",
				id: "counsel-group"
			}
		],
		source: "public"
	},
	{
		id: "usc-2257a",
		kind: "law",
		name: "18 U.S.C. § 2257A",
		subtitle: "Simulated depictions",
		citation: "18 U.S.C. § 2257A",
		jurisdiction: "United States (federal)",
		summary: "Extends 2257-style record-keeping to simulated sexually explicit conduct and to lascivious exhibition, with a certification exemption for some mainstream producers.",
		body: "Section 2257A covers visual depictions of simulated sexually explicit conduct and certain lascivious exhibition. Producers must keep performer records similar to § 2257 unless they qualify for a certification exemption used mainly by mainstream film and television that already complies with other child-protection regimes.\n\nAdult producers generally should not assume they qualify for that exemption. Counsel Group's desk treats 2257 and 2257A as one program with two statutory hooks.\n\nNot legal advice.",
		tags: [
			"federal",
			"2257a",
			"simulated",
			"records"
		],
		status: "In force",
		facts: [{
			label: "Citation",
			value: "18 U.S.C. § 2257A"
		}, {
			label: "Covers",
			value: "Simulated conduct; lascivious exhibition"
		}],
		related: [{
			kind: "law",
			id: "usc-2257"
		}, {
			kind: "law",
			id: "cfr-28-75"
		}],
		source: "public"
	},
	{
		id: "cfr-28-75",
		kind: "law",
		name: "28 C.F.R. Part 75",
		subtitle: "Attorney General regulations",
		citation: "28 C.F.R. §§ 75.1–75.9",
		jurisdiction: "United States (federal)",
		summary: "The regulations that make 2257 operational: what a record must contain, how it is indexed, where it is kept, how long, and how it is inspected.",
		body: "Part 75 is the operational manual for §§ 2257 and 2257A. It specifies picture-identification copies, alphabetical indexing by legal name with cross-references for aliases and titles, retention (generally seven years from creation or last amendment, and five years after a producer leaves the business — whichever runs longer), and inspection during ordinary business hours.\n\nA 2257 program that tracks the statute but ignores Part 75 is incomplete. Custodians, filenames, and URL indexes live here.\n\nNot legal advice.",
		tags: [
			"federal",
			"regulation",
			"2257",
			"retention"
		],
		status: "In force",
		facts: [{
			label: "Citation",
			value: "28 C.F.R. Part 75"
		}, {
			label: "Retention",
			value: "7 years / 5 years after exit"
		}],
		related: [{
			kind: "law",
			id: "usc-2257"
		}, {
			kind: "law",
			id: "usc-2257a"
		}],
		source: "public"
	},
	{
		id: "fosta-sesta",
		kind: "law",
		name: "FOSTA-SESTA",
		subtitle: "Platform liability carve-out",
		citation: "Allow States and Victims to Fight Online Sex Trafficking Act, Pub. L. 115–164",
		jurisdiction: "United States (federal)",
		summary: "2018 statute that carved sex-trafficking claims out of Section 230 immunity and created federal civil and criminal exposure for platforms that promote or facilitate prostitution.",
		body: "FOSTA-SESTA, signed in 2018, narrowed 47 U.S.C. § 230 so that platforms can be held responsible for certain sex-trafficking and prostitution-related activity. It did not outlaw adult content, but it changed how hosts, classifieds, and social products moderate sexual services and escort advertising.\n\nThe practical effect on the trade has been a chill in advertising channels, more aggressive terms of service, and a migration of independent work onto platforms that can show a compliance story. It sits beside, and is often confused with, 18 U.S.C. § 1591.\n\nNot legal advice.",
		tags: [
			"federal",
			"platforms",
			"section-230",
			"trafficking"
		],
		status: "In force",
		facts: [
			{
				label: "Enacted",
				value: "2018"
			},
			{
				label: "Public law",
				value: "Pub. L. 115–164"
			},
			{
				label: "Hooks",
				value: "§ 230 carve-out; 18 U.S.C. § 2421A"
			}
		],
		related: [
			{
				kind: "law",
				id: "section-230"
			},
			{
				kind: "law",
				id: "usc-1591"
			},
			{
				kind: "companies",
				id: "aurelia-network"
			},
			{
				kind: "companies",
				id: "fsc"
			}
		],
		source: "public"
	},
	{
		id: "section-230",
		kind: "law",
		name: "47 U.S.C. § 230",
		subtitle: "Platform immunity",
		citation: "47 U.S.C. § 230",
		jurisdiction: "United States (federal)",
		summary: "Communications Decency Act provision that generally immunizes interactive computer services from liability for third-party speech, with statutory exceptions including federal criminal law and FOSTA's trafficking carve-out.",
		body: "Section 230 is why user-generated platforms can host speech without being treated as the publisher of every post. Adult platforms rely on it for comments, profiles, and uploaded media — subject to federal criminal law (including 2257's own duties where they apply) and the FOSTA-SESTA exceptions.\n\nIt is not a license to ignore record-keeping, age-verification statutes, or the TAKE IT DOWN Act's notice-and-removal duties, which are separate regimes.\n\nNot legal advice.",
		tags: [
			"federal",
			"platforms",
			"immunity",
			"cda"
		],
		status: "In force",
		facts: [{
			label: "Citation",
			value: "47 U.S.C. § 230"
		}, {
			label: "Enacted",
			value: "1996"
		}],
		related: [
			{
				kind: "law",
				id: "fosta-sesta"
			},
			{
				kind: "law",
				id: "take-it-down"
			},
			{
				kind: "law",
				id: "dmca-512"
			}
		],
		source: "public"
	},
	{
		id: "miller-v-california",
		kind: "law",
		name: "Miller v. California",
		subtitle: "Obscenity test",
		citation: "413 U.S. 15 (1973)",
		jurisdiction: "United States (Supreme Court)",
		summary: "The three-part test that decides whether material is legally obscene — and therefore unprotected by the First Amendment.",
		body: "Miller asks whether the average person, applying contemporary community standards, would find that the work, taken as a whole, appeals to the prurient interest; whether it depicts sexual conduct in a patently offensive way as defined by state law; and whether it lacks serious literary, artistic, political, or scientific value.\n\nMost commercially distributed adult material is designed to sit on the protected side of Miller. The test still governs criminal obscenity prosecutions and is the backdrop against which later cases (Ashcroft, Paxton) reason about what states may do to keep material from minors.\n\nNot legal advice.",
		tags: [
			"case",
			"obscenity",
			"first-amendment",
			"supreme-court"
		],
		status: "Leading case",
		facts: [{
			label: "Citation",
			value: "413 U.S. 15 (1973)"
		}, {
			label: "Court",
			value: "U.S. Supreme Court"
		}],
		related: [{
			kind: "law",
			id: "ashcroft-fsc"
		}, {
			kind: "law",
			id: "fsc-v-paxton"
		}],
		source: "public"
	},
	{
		id: "ashcroft-fsc",
		kind: "law",
		name: "Ashcroft v. Free Speech Coalition",
		subtitle: "Virtual depictions",
		citation: "535 U.S. 234 (2002)",
		jurisdiction: "United States (Supreme Court)",
		summary: "Struck down parts of the CPPA that banned sexually explicit images that appeared to depict minors but were produced without real children — including adult actors and purely virtual images.",
		body: "The Court held that the First Amendment does not permit Congress to ban protected adult speech merely because it might be mistaken for illegal child pornography. The government may prohibit images of actual children; it may not, on that record, prohibit speech that only appears to involve them.\n\nThe decision is why adult producers can depict characters who are written as adults (and are performed by adults), and why later age-verification fights are framed as burdens on adults' access rather than as a ban on the speech itself.\n\nNot legal advice.",
		tags: [
			"case",
			"first-amendment",
			"supreme-court",
			"cppa"
		],
		status: "Leading case",
		facts: [{
			label: "Citation",
			value: "535 U.S. 234 (2002)"
		}, {
			label: "Plaintiff",
			value: "Free Speech Coalition"
		}],
		related: [
			{
				kind: "law",
				id: "miller-v-california"
			},
			{
				kind: "law",
				id: "fsc-v-paxton"
			},
			{
				kind: "companies",
				id: "fsc"
			}
		],
		source: "public"
	},
	{
		id: "fsc-v-paxton",
		kind: "law",
		name: "Free Speech Coalition v. Paxton",
		subtitle: "Age verification upheld",
		citation: "605 U.S. ___ (2025)",
		jurisdiction: "United States (Supreme Court)",
		summary: "June 27, 2025. The Court held 6–3 that Texas H.B. 1181's commercial age-verification requirement for sites with a substantial amount of material that is obscene to minors survives intermediate scrutiny.",
		body: "Texas H.B. 1181 requires certain commercial sites that publish sexually explicit material obscene to minors to verify that visitors are 18 or older. The Fifth Circuit had applied rational-basis review. The Supreme Court, in an opinion by Justice Thomas, held that the law only incidentally burdens adults' protected speech, is subject to intermediate scrutiny, and survives that review. Adults, the Court said, have no First Amendment right to access such speech without first submitting proof of age.\n\nJustice Kagan dissented, joined by Justices Sotomayor and Jackson. The decision effectively opened the door to similar statutes nationwide and is the reason many aggregators geo-fence or age-gate whole U.S. states. It sits in tension with older cases that applied strict scrutiny to similar burdens (including a 2004 decision the majority declined to follow).\n\nNot legal advice. Read the opinion; state statutes differ in coverage threshold, acceptable methods, and penalties.",
		tags: [
			"case",
			"age-verification",
			"texas",
			"supreme-court",
			"first-amendment"
		],
		status: "Decided 27 June 2025",
		facts: [
			{
				label: "Decided",
				value: "27 June 2025"
			},
			{
				label: "Vote",
				value: "6–3"
			},
			{
				label: "Author",
				value: "Thomas, J."
			},
			{
				label: "Docket",
				value: "23-1122"
			},
			{
				label: "Statute",
				value: "Texas H.B. 1181"
			}
		],
		related: [
			{
				kind: "law",
				id: "texas-hb-1181"
			},
			{
				kind: "law",
				id: "state-av-laws"
			},
			{
				kind: "law",
				id: "ashcroft-fsc"
			},
			{
				kind: "companies",
				id: "fsc"
			},
			{
				kind: "companies",
				id: "aurelia-network"
			}
		],
		source: "public"
	},
	{
		id: "texas-hb-1181",
		kind: "law",
		name: "Texas H.B. 1181",
		subtitle: "Commercial age verification",
		citation: "Tex. Civ. Prac. & Rem. Code ch. 129B",
		jurisdiction: "Texas",
		summary: "Requires covered commercial websites that publish a substantial portion of material harmful to minors to use reasonable age-verification methods. Civil penalties and injunctions. Upheld in FSC v. Paxton.",
		body: "H.B. 1181 is the statute the Supreme Court reviewed in 2025. Coverage is keyed to a commercial site's publication of sexually explicit material that is obscene to minors, typically at a one-third threshold. Acceptable methods include government ID and commercial age-verification systems. Knowing violations expose covered entities to injunctions and civil penalties.\n\nAfter Paxton, analog statutes in other states are harder to preliminarily enjoin on First Amendment grounds. Implementation details — which vendors, what data retention, what to do with VPN traffic — remain a compliance practice, not a constitutional given.\n\nNot legal advice.",
		tags: [
			"texas",
			"age-verification",
			"civil",
			"platforms"
		],
		status: "In force; upheld 2025",
		facts: [
			{
				label: "Jurisdiction",
				value: "Texas"
			},
			{
				label: "Enacted",
				value: "2023"
			},
			{
				label: "Review",
				value: "Upheld, FSC v. Paxton"
			}
		],
		related: [{
			kind: "law",
			id: "fsc-v-paxton"
		}, {
			kind: "law",
			id: "state-av-laws"
		}],
		source: "public"
	},
	{
		id: "state-av-laws",
		kind: "law",
		name: "State age-verification statutes",
		subtitle: "The post-Paxton map",
		jurisdiction: "U.S. states",
		summary: "A growing set of state laws requiring commercial adult sites to verify age. After FSC v. Paxton (2025), similar statutes are on firmer constitutional ground. Coverage, methods, and penalties still vary.",
		body: "Louisiana's 2023 Act 440 was an early model; Texas, Utah, Virginia, Mississippi, and others followed with their own coverage thresholds and vendor rules. Some states require a registered-agent or reporting duty; some impose civil liability to individuals; some are criminal.\n\nPaxton did not write a national statute. A site that geo-fences Texas is not thereby compliant in every other state. Counsel Day 2026 is built around this map. Aggregators (Aurelia) and live platforms (Cobalt) have been the first to implement hard gates or withdrawals.\n\nNot legal advice. Check current bill text; this desk does not host a live legislative tracker.",
		tags: [
			"states",
			"age-verification",
			"platforms",
			"compliance"
		],
		status: "Patchwork; expanding",
		facts: [{
			label: "Trigger case",
			value: "FSC v. Paxton (2025)"
		}, {
			label: "Early model",
			value: "Louisiana Act 440 (2023)"
		}],
		related: [
			{
				kind: "law",
				id: "fsc-v-paxton"
			},
			{
				kind: "law",
				id: "texas-hb-1181"
			},
			{
				kind: "companies",
				id: "cobalt-interactive"
			},
			{
				kind: "events",
				id: "counsel-day-2026"
			}
		],
		source: "public"
	},
	{
		id: "measure-b",
		kind: "law",
		name: "L.A. County Measure B",
		subtitle: "Safer-sex ordinance",
		citation: "Los Angeles County Safer Sex in the Adult Film Industry Act",
		jurisdiction: "Los Angeles County, California",
		summary: "2012 voter-approved ordinance requiring condom use in adult films shot in Los Angeles County and a public-health permit for producers.",
		body: "Measure B is a county public-health ordinance, not a federal speech statute. It pushed a substantial share of production out of Los Angeles County in the 2010s. California's statewide Proposition 60 (2016), which would have expanded similar rules, failed.\n\nStudios still shooting in the county treat permitting and on-set protocols as a production cost. Houses in this index list a mix of county and out-of-county stages.\n\nNot legal advice.",
		tags: [
			"california",
			"los-angeles",
			"public-health",
			"production"
		],
		status: "In force (county)",
		facts: [{
			label: "Approved",
			value: "2012"
		}, {
			label: "Jurisdiction",
			value: "Los Angeles County"
		}],
		related: [{
			kind: "companies",
			id: "helix-house"
		}, {
			kind: "companies",
			id: "northstar-pictures"
		}],
		source: "public"
	},
	{
		id: "ab5-classification",
		kind: "law",
		name: "California A.B. 5",
		subtitle: "Worker classification",
		citation: "Cal. Lab. Code § 2775 et seq. (A.B. 5, 2019)",
		jurisdiction: "California",
		summary: "Codifies the ABC test for employee versus independent contractor. Adult performers, crew, and some creators working in California have to be classified under it unless an exemption applies.",
		body: "A.B. 5 and the Dynamex ABC test make it harder to treat on-set labor as a roster of independent contractors. Subsequent legislation carved exemptions for some professions; adult performance is not a clean statutory carve-out, so California producers often mix payroll companies, loan-outs, and W-2 days.\n\nDirect-to-fan creators shooting alone in California face a different question than a Helix call sheet. Misclassification risk is a labor issue, not a 2257 issue — they stack.\n\nNot legal advice.",
		tags: [
			"california",
			"labor",
			"classification",
			"ab5"
		],
		status: "In force",
		facts: [{
			label: "Enacted",
			value: "2019"
		}, {
			label: "Test",
			value: "ABC / Dynamex"
		}],
		related: [{
			kind: "law",
			id: "work-for-hire"
		}, {
			kind: "companies",
			id: "helix-house"
		}],
		source: "public"
	},
	{
		id: "uk-online-safety",
		kind: "law",
		name: "UK Online Safety Act 2023",
		subtitle: "Age assurance, duties of care",
		citation: "Online Safety Act 2023 (UK)",
		jurisdiction: "United Kingdom",
		summary: "Imposes duties of care on user-to-user and search services, including highly effective age assurance for pornography. Ofcom is the regulator.",
		body: "The Online Safety Act requires services that publish or user-generate pornography to prevent children from encountering it, using highly effective age assurance. Ofcom's codes and the Part 5 duties on pornographic content have driven UK age-gating, withdrawals, and VPN workarounds similar to the U.S. state map — on a national scale.\n\nAfterlight's UK-facing storefront and Tamsin Rowe's producer notes treat OSA as a product requirement, not a terms footnote.\n\nNot legal advice. Ofcom guidance changes.",
		tags: [
			"united-kingdom",
			"ofcom",
			"age-assurance",
			"platforms"
		],
		status: "In force",
		facts: [{
			label: "Enacted",
			value: "2023"
		}, {
			label: "Regulator",
			value: "Ofcom"
		}],
		related: [
			{
				kind: "law",
				id: "eu-dsa"
			},
			{
				kind: "performers",
				id: "tamsin-rowe"
			},
			{
				kind: "companies",
				id: "afterlight-media"
			}
		],
		source: "public"
	},
	{
		id: "eu-dsa",
		kind: "law",
		name: "EU Digital Services Act",
		subtitle: "Platform due diligence",
		citation: "Regulation (EU) 2022/2065",
		jurisdiction: "European Union",
		summary: "EU-wide rules for intermediary services: notice-and-action, transparency, risk assessment for very large platforms, and protection of minors — including age-assurance expectations for adult content.",
		body: "The DSA is a regulation, directly applicable. Hosting services must provide notice-and-action for illegal content; very large platforms carry additional risk-assessment and audit duties. Combined with member-state criminal law and the forthcoming / adjacent age-assurance standards, it is the European compliance ceiling for Aurelia-style aggregators and Afterlight's own storefront.\n\nIllegal content under the DSA is defined by other law (including CSAM, which has no place in this industry and is not indexed here).\n\nNot legal advice.",
		tags: [
			"european-union",
			"platforms",
			"dsa",
			"age-assurance"
		],
		status: "In force",
		facts: [{
			label: "Citation",
			value: "Reg. (EU) 2022/2065"
		}, {
			label: "Applies",
			value: "EU intermediary services"
		}],
		related: [
			{
				kind: "law",
				id: "uk-online-safety"
			},
			{
				kind: "companies",
				id: "afterlight-media"
			},
			{
				kind: "companies",
				id: "aurelia-network"
			}
		],
		source: "public"
	},
	{
		id: "take-it-down",
		kind: "law",
		name: "TAKE IT DOWN Act",
		subtitle: "NCII and deepfakes",
		citation: "Pub. L. 119–12 (2025)",
		jurisdiction: "United States (federal)",
		summary: "Criminalizes knowing publication (or threats) of nonconsensual intimate images, including AI digital forgeries, and requires covered platforms to remove reported depictions and identical copies within 48 hours. FTC enforcement of the platform duty began 19 May 2026.",
		body: "The Tools to Address Known Exploitation by Immobilizing Technological Deepfakes on Websites and Networks Act was signed 19 May 2025. It has two engines: a criminal prohibition on knowingly publishing, or threatening to publish, nonconsensual intimate visual depictions of an identifiable person — authentic or AI-generated — and a platform notice-and-removal duty.\n\nCovered platforms must publish a process, then remove the identified depiction and make reasonable efforts to strip known identical copies as soon as possible, not later than 48 hours after a valid request. The FTC treats failures as rule violations; its portal opened when the platform provisions took effect on 19 May 2026.\n\nThis is distinct from 2257 (which is about age and identity of performers who consented to production) and from FOSTA (trafficking). Talent managers such as Nina Braswell now treat TAKE IT DOWN notices as a standard representation task.\n\nNot legal advice.",
		tags: [
			"federal",
			"ncii",
			"deepfakes",
			"platforms",
			"ftc"
		],
		status: "In force; FTC duty live 19 May 2026",
		facts: [
			{
				label: "Public law",
				value: "Pub. L. 119–12"
			},
			{
				label: "Signed",
				value: "19 May 2025"
			},
			{
				label: "Platform duty",
				value: "48 hours; FTC from 19 May 2026"
			}
		],
		related: [
			{
				kind: "law",
				id: "section-230"
			},
			{
				kind: "law",
				id: "dmca-512"
			},
			{
				kind: "companies",
				id: "vellum-digital"
			},
			{
				kind: "agents",
				id: "nina-braswell"
			}
		],
		source: "public"
	},
	{
		id: "card-networks",
		kind: "law",
		name: "Card-network integrity rules",
		subtitle: "Mastercard AN 5196 · Visa VIRP",
		jurisdiction: "Payment networks (global)",
		summary: "Private-network rules, not statutes. In 2025–2026 they became a de facto production standard: documented performer consent, 2257-quality records, and brand-protection reviews as a condition of taking cards.",
		body: "Mastercard's adult-content announcement (AN 5196) and Visa's Integrity Risk Program sit outside the U.S. Code but decide whether a studio or creator can get paid. Networks have asked acquirers for evidence of age, consent, and — in practice — signed releases that federal 2257 never required.\n\nA producer can be 2257-clean and still lose card processing. Direct-to-fan talent (Aisha Nasser, Noa Pell) feel this first. Counsel Day treats network rules as a third rail beside statute and state AV law.\n\nNot legal advice; network bulletins change without notice.",
		tags: [
			"payments",
			"mastercard",
			"visa",
			"consent",
			"private-rules"
		],
		status: "In force (network)",
		facts: [{
			label: "Nature",
			value: "Private network rules"
		}, {
			label: "Pressure",
			value: "Acquirers & platforms"
		}],
		related: [
			{
				kind: "law",
				id: "usc-2257"
			},
			{
				kind: "companies",
				id: "vellum-digital"
			},
			{
				kind: "performers",
				id: "aisha-nasser"
			}
		],
		source: "public"
	},
	{
		id: "usc-1591",
		kind: "law",
		name: "18 U.S.C. § 1591",
		subtitle: "Sex trafficking",
		citation: "18 U.S.C. § 1591",
		jurisdiction: "United States (federal)",
		summary: "Federal sex-trafficking statute. Adult production of consensual work by adults is not trafficking; platforms and producers still train to this line because FOSTA made the civil shadow longer.",
		body: "Section 1591 criminalizes sex trafficking of children and of adults by force, fraud, or coercion. Consensual adult production, correctly documented, is a different activity. The industry indexes 1591 because FOSTA-SESTA created civil exposure for platforms that host or promote violations, and because reputable houses treat recruitment, housing, and immigration of talent as a compliance problem, not a vibe.\n\nfleshsesh does not provide investigative how-to. If you need to report trafficking, use law enforcement and the National Human Trafficking Hotline (1-888-373-7888).\n\nNot legal advice.",
		tags: [
			"federal",
			"criminal",
			"trafficking"
		],
		status: "In force",
		facts: [{
			label: "Citation",
			value: "18 U.S.C. § 1591"
		}, {
			label: "Hotline",
			value: "1-888-373-7888"
		}],
		related: [
			{
				kind: "law",
				id: "fosta-sesta"
			},
			{
				kind: "companies",
				id: "fsc"
			},
			{
				kind: "companies",
				id: "asacp"
			}
		],
		source: "public"
	},
	{
		id: "right-of-publicity",
		kind: "law",
		name: "Right of publicity",
		subtitle: "Name, image, likeness",
		jurisdiction: "U.S. states (common law & statute)",
		summary: "State-law right to control commercial use of one's identity. Performer contracts, clips used in trailers, and deepfakes all run through it — alongside copyright and TAKE IT DOWN.",
		body: "California, New York, and others recognize a right of publicity. Adult performers license name, image, and likeness in performing agreements; problems arise with scrapes, compilation tubes, lookalike marketing, and unauthorized AI. TAKE IT DOWN is a federal removal tool for intimate imagery; publicity is the civil claim for commercial identity.\n\nNot legal advice. Choice of law matters.",
		tags: [
			"state",
			"publicity",
			"nil",
			"contracts"
		],
		status: "Varies by state",
		facts: [{
			label: "Nature",
			value: "State law"
		}, {
			label: "Neighbors",
			value: "Copyright, TAKE IT DOWN"
		}],
		related: [{
			kind: "law",
			id: "take-it-down"
		}, {
			kind: "law",
			id: "work-for-hire"
		}],
		source: "public"
	},
	{
		id: "dmca-512",
		kind: "law",
		name: "DMCA § 512",
		subtitle: "Notice-and-takedown",
		citation: "17 U.S.C. § 512",
		jurisdiction: "United States (federal)",
		summary: "Safe harbor for online service providers that expeditiously remove allegedly infringing material after a valid copyright notice. Standard path for stolen scenes and scraped Vellum posts.",
		body: "Section 512 is copyright procedure, not 2257 and not TAKE IT DOWN. A studio or creator sends a notice identifying the work, the infringing URL, and a statement under penalty of perjury; a qualifying host that removes expeditiously keeps the safe harbor.\n\nAurelia Network lists a DMCA agent. TAKE IT DOWN now sits beside 512 for nonconsensual intimate imagery that may or may not be a copyright of the victim.\n\nNot legal advice.",
		tags: [
			"federal",
			"copyright",
			"dmca",
			"platforms"
		],
		status: "In force",
		facts: [{
			label: "Citation",
			value: "17 U.S.C. § 512"
		}, {
			label: "Hook",
			value: "Registered DMCA agent"
		}],
		related: [
			{
				kind: "law",
				id: "take-it-down"
			},
			{
				kind: "law",
				id: "section-230"
			},
			{
				kind: "companies",
				id: "aurelia-network"
			}
		],
		source: "public"
	},
	{
		id: "work-for-hire",
		kind: "law",
		name: "Work made for hire & performer deals",
		subtitle: "Copyright and contracts",
		citation: "17 U.S.C. § 101; state contract law",
		jurisdiction: "United States",
		summary: "Who owns the master, the stills, the stage name, and the platform upload. Default copyright rules plus the four-page performer agreement that actually runs the set.",
		body: "U.S. copyright vests in the author unless a work is made for hire (employee in the scope of employment, or a specially commissioned work in a statutory category with a signed agreement) or is assigned. Adult sets often rely on performer agreements that assign copyright, license publicity, and confirm 2257 cooperation and STI protocols.\n\nCalifornia classification (A.B. 5) can cut against a clean work-for-hire employee story. Direct-to-fan talent who shoot themselves usually own the copyright unless they signed it away to a platform — most platforms take a license, not an assignment.\n\nNot legal advice. Do not shoot without a signed deal and a 2257 file.",
		tags: [
			"copyright",
			"contracts",
			"performers"
		],
		status: "Background law",
		facts: [{
			label: "Copyright",
			value: "17 U.S.C. § 101"
		}, {
			label: "Labor overlay",
			value: "A.B. 5 in California"
		}],
		related: [
			{
				kind: "law",
				id: "ab5-classification"
			},
			{
				kind: "law",
				id: "right-of-publicity"
			},
			{
				kind: "law",
				id: "usc-2257"
			}
		],
		source: "public"
	}
];
var entities = [...industry, ...desk];
var byId = /* @__PURE__ */ new Map();
for (const e of entities) {
	byId.set(`${e.kind}:${e.id}`, e);
	byId.set(e.id, e);
}
function isKind(value) {
	return KINDS.includes(value);
}
function getEntity(kind, id) {
	return byId.get(`${kind}:${id}`);
}
function getById(id) {
	return byId.get(id);
}
function listKind(kind) {
	if (kind === "social") return [];
	return entities.filter((e) => e.kind === kind);
}
function counts() {
	const out = {
		performers: 0,
		productions: 0,
		companies: 0,
		agents: 0,
		events: 0,
		social: 0,
		law: 0
	};
	for (const e of entities) out[e.kind] += 1;
	out.social = socialDirectory().length;
	return out;
}
function socialDirectory() {
	const rows = [];
	for (const e of entities) for (const s of e.socials ?? []) rows.push({
		platform: s.platform,
		handle: s.handle,
		href: s.href,
		entity: e
	});
	rows.sort((a, b) => a.platform.localeCompare(b.platform) || a.handle.localeCompare(b.handle));
	return rows;
}
function tokenize(q) {
	return q.toLowerCase().split(/[^a-z0-9§+]+/i).map((t) => t.trim()).filter((t) => t.length > 0);
}
function haystack(e) {
	return [
		e.name,
		e.subtitle,
		...e.aka ?? [],
		e.summary,
		e.body ?? "",
		e.tags.join(" "),
		e.region ?? "",
		e.status ?? "",
		e.citation ?? "",
		e.jurisdiction ?? "",
		e.venue ?? "",
		...(e.facts ?? []).map((f) => `${f.label} ${f.value}`),
		...(e.credits ?? []).map((c) => `${c.role} ${c.title}`),
		...(e.socials ?? []).map((s) => `${s.platform} ${s.handle}`)
	].join(" ").toLowerCase();
}
function search(q, kind) {
	const tokens = tokenize(q);
	const pool = kind && kind !== "all" ? kind === "social" ? [] : listKind(kind) : entities;
	if (tokens.length === 0) return pool.map((entity) => ({
		entity,
		score: 1
	}));
	const hits = [];
	for (const entity of pool) {
		const name = entity.name.toLowerCase();
		const aka = (entity.aka ?? []).map((a) => a.toLowerCase());
		const blob = haystack(entity);
		let score = 0;
		let miss = false;
		for (const t of tokens) if (name === t) score += 80;
		else if (name.startsWith(t)) score += 48;
		else if (name.includes(t)) score += 32;
		else if (aka.some((a) => a === t || a.includes(t))) score += 28;
		else if (entity.citation?.toLowerCase().includes(t)) score += 40;
		else if (entity.tags.some((tag) => tag.includes(t))) score += 16;
		else if (blob.includes(t)) score += 8;
		else {
			miss = true;
			break;
		}
		if (!miss) hits.push({
			entity,
			score
		});
	}
	hits.sort((a, b) => b.score - a.score || a.entity.name.localeCompare(b.entity.name));
	return hits;
}
function relatedOf(entity) {
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	for (const r of entity.related) {
		const hit = getEntity(r.kind, r.id);
		if (hit && !seen.has(`${hit.kind}:${hit.id}`)) {
			seen.add(`${hit.kind}:${hit.id}`);
			out.push(hit);
		}
	}
	return out;
}
function resolveCredit(c) {
	if (!c.kind || !c.id) return void 0;
	return getEntity(c.kind, c.id);
}
entities.length;
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-3x6f2zop.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-accent/90 rounded-sm",
			secondary: "bg-raised text-fg hover:bg-raised/80 rounded-sm shadow-[var(--shadow-border)]",
			outline: "bg-transparent text-fg rounded-sm shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "bg-transparent text-fg hover:bg-raised rounded-sm",
			link: "text-accent underline-offset-4 hover:underline rounded-none"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-6",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		ref,
		...props
	});
});
Button.displayName = "Button";
function Wordmark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("font-display leading-none tracking-tight text-fg", className),
		children: ["flesh", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: "search"
		})]
	});
}
var KEY$1 = "fleshsesh.age";
var LEGACY_KEYS$1 = [
	"fleshsearch.age",
	"flesh.age",
	"canon.age"
];
function read$1() {
	if (typeof window === "undefined") return false;
	try {
		return window.localStorage.getItem(KEY$1) === "1" || LEGACY_KEYS$1.some((k) => window.localStorage.getItem(k) === "1");
	} catch {
		return false;
	}
}
var useAgeGate = create((set) => ({
	ok: false,
	enter: () => {
		try {
			window.localStorage.setItem(KEY$1, "1");
		} catch {}
		set({ ok: true });
	},
	leave: () => {
		try {
			window.localStorage.removeItem(KEY$1);
		} catch {}
		set({ ok: false });
	}
}));
function hydrateAgeGate() {
	useAgeGate.setState({ ok: read$1() });
}
var KEY = "fleshsesh.saved";
var LEGACY_KEYS = [
	"fleshsearch.saved",
	"flesh.saved",
	"canon.saved"
];
function read() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(KEY) ?? LEGACY_KEYS.map((k) => window.localStorage.getItem(k)).find(Boolean);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function write(items) {
	try {
		window.localStorage.setItem(KEY, JSON.stringify(items));
	} catch {}
}
function keyOf(r) {
	return `${r.kind}:${r.id}`;
}
var useSaved = create((set, get) => ({
	items: [],
	has: (ref) => get().items.some((i) => keyOf(i) === keyOf(ref)),
	toggle: (ref) => {
		const k = keyOf(ref);
		const items = get().items.some((i) => keyOf(i) === k) ? get().items.filter((i) => keyOf(i) !== k) : [ref, ...get().items];
		write(items);
		set({ items });
	}
}));
function hydrateSaved() {
	useSaved.setState({ items: read() });
}
function isLiveId(id) {
	return /^Q[1-9]\d{0,12}$/.test(id);
}
function AgeGate({ children }) {
	const ok = useAgeGate((s) => s.ok);
	const enter = useAgeGate((s) => s.enter);
	(0, import_react.useEffect)(() => {
		hydrateAgeGate();
		hydrateSaved();
	}, []);
	if (!ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col items-center justify-center px-6 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "grain pointer-events-none absolute inset-0 opacity-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto w-full max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
					children: "fleshsesh · 18+"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, { className: "block text-5xl sm:text-7xl" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-md text-base leading-relaxed text-muted",
					children: "An industry index of adult entertainment professionals, productions, companies, representation, events, public socials, and the law. Every talent record is of a working adult. No explicit media is hosted."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-subtle",
					children: "You must be 18 or older to continue."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						onClick: enter,
						className: "min-h-12",
						children: "I am 18 or older"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "outline",
						className: "min-h-12",
						onClick: () => {
							window.location.href = "https://www.google.com";
						},
						children: "Leave"
					})]
				})
			]
		})]
	});
	return children;
}
function SearchBox({ initial = "", size = "lg", autoFocus = false, kind = "all", placeholder = "Search talent, titles, houses, counsel…" }) {
	const navigate = useNavigate();
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if (e.key === "/" && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) {
				e.preventDefault();
				ref.current?.focus();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	function onSubmit(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		const q = String(fd.get("q") ?? "").trim();
		navigate({
			to: "/search",
			search: {
				q,
				kind
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "relative w-full",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: cn("pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-subtle", size === "lg" ? "size-5" : "size-4"),
				strokeWidth: 1.75
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref,
				name: "q",
				defaultValue: initial,
				autoFocus,
				autoComplete: "off",
				placeholder,
				"aria-label": "Search the index",
				className: cn("w-full bg-raised text-fg shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] placeholder:text-subtle focus-visible:outline-none focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:ring-2 focus-visible:ring-ring", size === "lg" ? "h-14 rounded-lg pl-12 pr-16 font-display text-xl" : "h-11 rounded-md pl-11 pr-14 text-sm")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
				className: "pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 rounded-sm px-1.5 py-0.5 font-mono text-[10px] text-subtle shadow-[var(--shadow-border)] sm:inline",
				children: "/"
			})
		]
	});
}
function Shell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const saved = useSaved((s) => s.items.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "grain pointer-events-none absolute inset-0 opacity-30" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 border-b border-border bg-bg/90 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center gap-4 px-4 py-3 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "shrink-0",
							"aria-label": "fleshsesh home",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, { className: "text-2xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 hidden text-[10px] uppercase tracking-[0.18em] text-subtle sm:block",
								children: "fleshsesh"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden min-w-0 flex-1 md:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBox, { size: "sm" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/saved",
							className: "relative ml-auto inline-flex size-11 items-center justify-center rounded-sm text-muted hover:bg-raised hover:text-fg",
							"aria-label": "Saved records",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
								className: "size-5",
								strokeWidth: 1.75
							}), saved > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-1.5 top-1.5 size-1.5 rounded-full bg-accent" })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 pb-2 sm:px-6",
					"aria-label": "Index sections",
					children: KINDS.map((kind) => {
						const active = pathname === `/${kind}` || pathname.startsWith(`/${kind}/`);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/$kind",
							params: { kind },
							className: cn("shrink-0 rounded-full px-3 py-2 text-sm transition-colors duration-[var(--motion-quick)]", active ? "bg-raised text-fg shadow-[var(--shadow-border)]" : "text-muted hover:text-fg"),
							children: KIND_META[kind].label
						}, kind);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto w-full max-w-6xl px-4 py-3 md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBox, { size: "sm" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "relative mx-auto w-full max-w-6xl px-4 pb-16 pt-4 sm:px-6 sm:pt-8",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "relative border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 text-sm text-subtle sm:flex-row sm:items-center sm:justify-between sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "fleshsesh indexes working adults (21+ on the live desk). Public industry databases via Wikidata. Not legal advice. No explicit media." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/sources",
							className: "text-muted hover:text-fg",
							children: "Databases"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							className: "text-muted hover:text-fg",
							children: "About the index"
						})]
					})]
				})
			})
		]
	});
}
/** Tool / product name — titles, copy, meta. */
var APP_NAME = "fleshsesh";
var styles_default = "/assets/styles-B9Vu4tAP.css";
var Route$8 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "fleshsesh is an adult-industry index: performers, productions, companies, agents, events, socials, and the law."
			},
			{
				name: "theme-color",
				content: "#0b0b0c"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;1,400&family=IBM+Plex+Mono:wght@400;500&family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400&display=swap"
			}
		]
	}),
	notFoundComponent: NotFound,
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgeGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl tracking-tight",
				children: "Not in the index"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-muted",
				children: "No record at this path."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-6 inline-block text-sm text-muted hover:text-fg",
				children: "Return home"
			})
		]
	});
}
var $$splitComponentImporter$7 = () => import("./routes-CW2nt7SO.mjs");
var Route$7 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./about-BBbnV4mD.mjs");
var Route$6 = createFileRoute("/about")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./saved-C3Kze8GZ.mjs");
var Route$5 = createFileRoute("/saved")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./search-CDV7mxDh.mjs");
var Route$4 = createFileRoute("/search")({
	validateSearch: (s) => ({
		q: typeof s.q === "string" ? s.q : "",
		kind: typeof s.kind === "string" ? s.kind : "all"
	}),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./sources-CpL_VilQ.mjs");
var Route$3 = createFileRoute("/sources")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitNotFoundComponentImporter$2 = () => import("../_kind-LtqDez1b.mjs");
var $$splitComponentImporter$2 = () => import("../_kind-Cqze7EuI.mjs");
var Route$2 = createFileRoute("/$kind/")({
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$2, "notFoundComponent"),
	beforeLoad: ({ params }) => {
		if (!isKind(params.kind)) throw notFound();
	}
});
var $$splitNotFoundComponentImporter$1 = () => import("../_id-qujZ4p24.mjs");
var $$splitComponentImporter$1 = () => import("../_id-L5rd8GTj.mjs");
var Route$1 = createFileRoute("/$kind/$id")({
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$1, "notFoundComponent"),
	beforeLoad: ({ params }) => {
		if (!isKind(params.kind)) throw notFound();
		if (!getEntity(params.kind, params.id)) throw notFound();
	}
});
var $$splitNotFoundComponentImporter = () => import("../_qid-IHuSEyym.mjs");
var $$splitComponentImporter = () => import("../_qid-1Do_qQUm.mjs");
var Route = createFileRoute("/live/$qid")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	beforeLoad: ({ params }) => {
		if (!/^Q[1-9]\d{0,12}$/.test(params.qid)) throw notFound();
	}
});
var IndexRoute = Route$7.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$8
});
var AboutRoute = Route$6.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$8
});
var SavedRoute = Route$5.update({
	id: "/saved",
	path: "/saved",
	getParentRoute: () => Route$8
});
var SearchRoute = Route$4.update({
	id: "/search",
	path: "/search",
	getParentRoute: () => Route$8
});
var SourcesRoute = Route$3.update({
	id: "/sources",
	path: "/sources",
	getParentRoute: () => Route$8
});
var KindIndexRoute = Route$2.update({
	id: "/$kind/",
	path: "/$kind/",
	getParentRoute: () => Route$8
});
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	SavedRoute,
	SearchRoute,
	SourcesRoute,
	KindIdRoute: Route$1.update({
		id: "/$kind/$id",
		path: "/$kind/$id",
		getParentRoute: () => Route$8
	}),
	LiveQidRoute: Route.update({
		id: "/live/$qid",
		path: "/live/$qid",
		getParentRoute: () => Route$8
	}),
	KindIndexRoute
};
var routeTree = Route$8._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { search as _, Route$4 as a, KIND_META as b, useSaved as c, getById as d, getEntity as f, resolveCredit as g, relatedOf as h, Route$2 as i, Button as l, listKind as m, Route as n, SearchBox as o, isKind as p, Route$1 as r, isLiveId as s, router_exports as t, counts as u, socialDirectory as v, cn as x, KINDS as y };
