import { v as Link, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { b as KIND_META, d as getById, m as listKind, o as SearchBox, u as counts, x as cn, y as KINDS } from "./router-3x6f2zop.mjs";
import { t as KIND_ICON } from "./kind-mark-BDWQJV1X.mjs";
import { t as EntityCard } from "./entity-card-GzSLAuZM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CW2nt7SO.js
var import_jsx_runtime = require_jsx_runtime();
var LIVE_EXAMPLES = [
	{
		q: "Riley Reid",
		kind: "performers",
		label: "Riley Reid"
	},
	{
		q: "Little Caprice",
		kind: "performers",
		label: "Little Caprice"
	},
	{
		q: "Evil Angel",
		kind: "companies",
		label: "Evil Angel"
	},
	{
		q: "Deep Throat",
		kind: "productions",
		label: "Deep Throat"
	},
	{
		q: "2257",
		kind: "law",
		label: "18 U.S.C. § 2257"
	}
];
function Home() {
	const c = counts();
	const spotlight = [
		getById("isla-vane"),
		getById("glass-harbor"),
		getById("fsc-v-paxton"),
		getById("helix-house")
	].filter(Boolean);
	const upcoming = listKind("events").filter((e) => e.status === "Upcoming");
	const watch = [
		getById("fsc-v-paxton"),
		getById("take-it-down"),
		getById("usc-2257"),
		getById("state-av-laws")
	].filter(Boolean);
	const today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", {
		weekday: "long",
		day: "numeric",
		month: "long",
		year: "numeric"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden rounded-xl bg-surface px-5 py-10 shadow-[var(--shadow-border)] sm:px-10 sm:py-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
						children: [
							"Vol. 01 · ",
							today,
							" · 18+"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 max-w-3xl font-display text-4xl leading-[1.1] tracking-tight text-fg sm:text-6xl",
						children: "The adult industry, indexed."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-base leading-relaxed text-muted sm:text-lg",
						children: "Search IAFD, AFDB, AVN, XXXBios, EGAFD, and BGAFD via Wikidata — plus the desk, calendar, and the statutes that govern the work."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 max-w-2xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchBox, { autoFocus: true })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 flex flex-wrap gap-x-3 gap-y-1 text-sm text-subtle",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "uppercase tracking-[0.14em]",
							children: "Try"
						}), LIVE_EXAMPLES.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/search",
							search: {
								q: ex.q,
								kind: ex.kind
							},
							className: "text-muted hover:text-fg",
							children: ex.label
						}) }, ex.q))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-8 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7",
						children: KINDS.map((kind) => {
							const Icon = KIND_ICON[kind];
							const live = kind === "performers" || kind === "productions" || kind === "companies";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/$kind",
								params: { kind },
								className: "flex min-h-16 flex-col justify-between rounded-md bg-raised px-3 py-2.5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] hover:shadow-[var(--shadow-border-hover)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5 text-[11px] uppercase tracking-[0.14em] text-subtle",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-3.5",
										strokeWidth: 1.75
									}), KIND_META[kind].label]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-baseline justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-lg tabular-nums text-fg",
										children: c[kind]
									}), live && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase tracking-[0.12em] text-subtle",
										children: "+ live"
									})]
								})]
							}) }, kind);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				kicker: "Spotlight",
				title: "On the desk",
				to: "/search",
				action: "Open the index"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 grid gap-3 sm:grid-cols-2",
				children: spotlight.map((e) => e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityCard, { entity: e }, e.id) : null)
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
					kicker: "Calendar",
					title: "Upcoming",
					to: "/events",
					action: "All events"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 divide-y divide-border",
					children: upcoming.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/$kind/$id",
						params: {
							kind: "events",
							id: e.id
						},
						className: "flex items-start gap-4 py-4 hover:text-accent",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateBlock, { iso: e.dateStart }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl leading-snug",
								children: e.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									e.venue ?? e.region,
									" · ",
									e.subtitle
								]
							})]
						})]
					}) }, e.id))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
					kicker: "Desk",
					title: "Legal watch",
					to: "/law",
					action: "Law library"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-2",
					children: watch.map((e) => e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/$kind/$id",
						params: {
							kind: "law",
							id: e.id
						},
						className: cn("block rounded-lg bg-surface px-4 py-3 shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] hover:shadow-[var(--shadow-border-hover)]"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg leading-snug",
							children: e.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 line-clamp-2 text-sm text-muted",
							children: e.summary
						})]
					}) }, e.id) : null)
				})] })]
			})
		]
	});
}
function SectionHead({ kicker, title, to, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] font-medium uppercase tracking-[0.22em] text-subtle",
			children: kicker
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-1 font-display text-3xl tracking-tight",
			children: title
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			...to === "/search" ? {
				to: "/search",
				search: {
					q: "",
					kind: "all"
				}
			} : to === "/events" ? {
				to: "/$kind",
				params: { kind: "events" }
			} : {
				to: "/$kind",
				params: { kind: "law" }
			},
			className: "inline-flex items-center gap-1 text-sm text-muted hover:text-fg",
			children: [action, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
		})]
	});
}
function DateBlock({ iso }) {
	if (!iso) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-12" });
	const d = /* @__PURE__ */ new Date(iso + "T12:00:00");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex size-14 shrink-0 flex-col items-center justify-center rounded-md bg-raised shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[10px] uppercase tracking-[0.14em] text-subtle",
			children: d.toLocaleDateString("en-GB", { month: "short" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-lg tabular-nums leading-none",
			children: d.getDate()
		})]
	});
}
//#endregion
export { Home as component };
