//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-PKtqkKV9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/saved",
			"/search",
			"/sources",
			"/$kind/$id",
			"/live/$qid",
			"/$kind/"
		],
		preloads: [
			"/assets/index-HD-sM55v.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/link-Cvg6Lx4U.js",
			"/assets/types-LG4szLPN.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-HD-sM55v.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-0iwykcsI.js",
			"/assets/kind-mark-G6ruQPb1.js",
			"/assets/entity-card-BqWVCJqL.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DBNcoYlg.js"]
	},
	"/saved": {
		filePath: "/workspace/src/routes/saved.tsx",
		children: void 0,
		preloads: [
			"/assets/saved-D5l_gP1G.js",
			"/assets/kind-mark-G6ruQPb1.js",
			"/assets/entity-card-BqWVCJqL.js"
		]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-BHu0KUdn.js",
			"/assets/queries-DNmfb4mn.js",
			"/assets/kind-mark-G6ruQPb1.js",
			"/assets/entity-card-BqWVCJqL.js",
			"/assets/sources-BAZJV2T3.js"
		]
	},
	"/sources": {
		filePath: "/workspace/src/routes/sources.tsx",
		children: void 0,
		preloads: ["/assets/sources-D7x5qrZa.js", "/assets/sources-BAZJV2T3.js"]
	},
	"/$kind/$id": {
		filePath: "/workspace/src/routes/$kind/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-Byh0Fdfl.js",
			"/assets/_id-CZC3m1Rq.js",
			"/assets/badge-CXpZrksg.js",
			"/assets/kind-mark-G6ruQPb1.js",
			"/assets/entity-card-BqWVCJqL.js"
		]
	},
	"/live/$qid": {
		filePath: "/workspace/src/routes/live/$qid.tsx",
		children: void 0,
		preloads: [
			"/assets/_qid-B8R6TV5j.js",
			"/assets/_qid-BJezv7xS.js",
			"/assets/queries-DNmfb4mn.js",
			"/assets/badge-CXpZrksg.js",
			"/assets/kind-mark-G6ruQPb1.js"
		]
	},
	"/$kind/": {
		filePath: "/workspace/src/routes/$kind/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_kind-BbFcM3dy.js",
			"/assets/_kind-W5kx6KqC.js",
			"/assets/kind-mark-G6ruQPb1.js",
			"/assets/entity-card-BqWVCJqL.js",
			"/assets/sources-BAZJV2T3.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
