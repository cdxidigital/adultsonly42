import { useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useEffect, useRef, type FormEvent } from "react";
import { cn } from "@/lib/utils";

export function SearchBox({
  initial = "",
  size = "lg",
  autoFocus = false,
  kind = "all",
  placeholder = "Search talent, titles, houses, counsel…",
}: {
  initial?: string;
  size?: "lg" | "sm";
  autoFocus?: boolean;
  kind?: string;
  placeholder?: string;
}) {
  const navigate = useNavigate();
  const ref = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "/" && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) {
        e.preventDefault();
        ref.current?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const q = String(fd.get("q") ?? "").trim();
    void navigate({ to: "/search", search: { q, kind } });
  }

  return (
    <form onSubmit={onSubmit} className="relative w-full">
      <Search
        className={cn(
          "pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-subtle",
          size === "lg" ? "size-5" : "size-4",
        )}
        strokeWidth={1.75}
      />
      <input
        ref={ref}
        name="q"
        defaultValue={initial}
        autoFocus={autoFocus}
        autoComplete="off"
        placeholder={placeholder}
        aria-label="Search the index"
        className={cn(
          "w-full bg-raised text-fg shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] placeholder:text-subtle focus-visible:outline-none focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:ring-2 focus-visible:ring-ring",
          size === "lg"
            ? "h-14 rounded-lg pl-12 pr-16 font-display text-xl"
            : "h-11 rounded-md pl-11 pr-14 text-sm",
        )}
      />
      <kbd className="pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 rounded-sm px-1.5 py-0.5 font-mono text-[10px] text-subtle shadow-[var(--shadow-border)] sm:inline">
        /
      </kbd>
    </form>
  );
}
