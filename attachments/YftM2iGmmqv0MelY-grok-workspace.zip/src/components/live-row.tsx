import { Link } from "@tanstack/react-router";
import { Portrait } from "@/components/portrait";
import { KIND_ICON } from "@/components/kind-mark";
import { KIND_META } from "@/lib/catalog/types";
import { Highlight } from "@/components/entity-card";
import type { LiveHit } from "@/lib/live/types";

export function LiveRow({ hit, q }: { hit: LiveHit; q?: string }) {
  const Icon = KIND_ICON[hit.kind];
  return (
    <Link
      to="/live/$qid"
      params={{ qid: hit.qid }}
      className="group flex items-start gap-3 rounded-lg px-2 py-3 transition-colors duration-[var(--motion-quick)] hover:bg-raised"
    >
      <Portrait id={hit.qid} name={hit.name} kind={hit.kind} className="size-12 shrink-0" />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
          <span className="font-display text-lg leading-snug text-fg group-hover:text-accent">
            <Highlight text={hit.name} q={q} />
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] font-medium uppercase tracking-[0.14em] text-subtle">
            <Icon className="size-3" />
            {KIND_META[hit.kind].singular}
          </span>
        </div>
        <p className="mt-1 line-clamp-2 text-sm text-muted">{hit.summary}</p>
        {hit.databases.length > 0 && (
          <p className="mt-1.5 text-[11px] uppercase tracking-[0.12em] text-subtle">
            {hit.databases
              .map((d) => d.name)
              .filter((n, i, a) => a.indexOf(n) === i)
              .join(" · ")}
          </p>
        )}
      </div>
    </Link>
  );
}
