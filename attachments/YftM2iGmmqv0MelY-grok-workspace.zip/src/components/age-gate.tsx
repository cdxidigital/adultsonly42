import { useEffect, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Wordmark } from "@/components/wordmark";
import { hydrateAgeGate, useAgeGate } from "@/lib/age-gate";
import { hydrateSaved } from "@/lib/saved";

export function AgeGate({ children }: { children: ReactNode }) {
  const ok = useAgeGate((s) => s.ok);
  const enter = useAgeGate((s) => s.enter);

  useEffect(() => {
    hydrateAgeGate();
    hydrateSaved();
  }, []);

  if (!ok) {
    return (
      <div className="relative flex min-h-dvh flex-col items-center justify-center px-6 py-16">
        <div className="grain pointer-events-none absolute inset-0 opacity-40" />
        <div className="relative mx-auto w-full max-w-lg">
          <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
            fleshsesh · 18+
          </p>
          <h1 className="mt-4">
            <Wordmark className="block text-5xl sm:text-7xl" />
          </h1>
          <p className="mt-6 max-w-md text-base leading-relaxed text-muted">
            An industry index of adult entertainment professionals, productions,
            companies, representation, events, public socials, and the law. Every
            talent record is of a working adult. No explicit media is hosted.
          </p>
          <p className="mt-4 text-sm text-subtle">
            You must be 18 or older to continue.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" onClick={enter} className="min-h-12">
              I am 18 or older
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="min-h-12"
              onClick={() => {
                window.location.href = "https://www.google.com";
              }}
            >
              Leave
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return children;
}
