import { cn } from "@/lib/utils";

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("font-display leading-none tracking-tight text-fg", className)}>
      flesh<span className="text-muted">search</span>
    </span>
  );
}
