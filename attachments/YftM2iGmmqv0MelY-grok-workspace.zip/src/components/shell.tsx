import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Bookmark } from "lucide-react";
import { KINDS, KIND_META } from "@/lib/catalog/types";
import { SearchBox } from "@/components/search-box";
import { Wordmark } from "@/components/wordmark";
import { useSaved } from "@/lib/saved";
import { cn } from "@/lib/utils";

export function Shell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const saved = useSaved((s) => s.items.length);

  return (
    <div className="relative min-h-dvh bg-bg text-fg">
      <div className="grain pointer-events-none absolute inset-0 opacity-30" />
      <header className="sticky top-0 z-30 border-b border-border bg-bg/90 backdrop-blur-sm">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3 sm:px-6">
          <Link to="/" className="shrink-0" aria-label="fleshsesh home">
            <Wordmark className="text-2xl" />
            <span className="mt-0.5 hidden text-[10px] uppercase tracking-[0.18em] text-subtle sm:block">
              fleshsesh
            </span>
          </Link>
          <div className="hidden min-w-0 flex-1 md:block">
            <SearchBox size="sm" />
          </div>
          <Link
            to="/saved"
            className="relative ml-auto inline-flex size-11 items-center justify-center rounded-sm text-muted hover:bg-raised hover:text-fg"
            aria-label="Saved records"
          >
            <Bookmark className="size-5" strokeWidth={1.75} />
            {saved > 0 && (
              <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-accent" />
            )}
          </Link>
        </div>
        <nav
          className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 pb-2 sm:px-6"
          aria-label="Index sections"
        >
          {KINDS.map((kind) => {
            const active = pathname === `/${kind}` || pathname.startsWith(`/${kind}/`);
            return (
              <Link
                key={kind}
                to="/$kind"
                params={{ kind }}
                className={cn(
                  "shrink-0 rounded-full px-3 py-2 text-sm transition-colors duration-[var(--motion-quick)]",
                  active
                    ? "bg-raised text-fg shadow-[var(--shadow-border)]"
                    : "text-muted hover:text-fg",
                )}
              >
                {KIND_META[kind].label}
              </Link>
            );
          })}
        </nav>
      </header>
      <div className="relative mx-auto w-full max-w-6xl px-4 py-3 md:hidden">
        <SearchBox size="sm" />
      </div>
      <main className="relative mx-auto w-full max-w-6xl px-4 pb-16 pt-4 sm:px-6 sm:pt-8">
        {children}
      </main>
      <footer className="relative border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 text-sm text-subtle sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>
            fleshsesh indexes working adults (21+ on the live desk). Public
            industry databases via Wikidata. Not legal advice. No explicit media.
          </p>
          <div className="flex gap-4">
            <Link to="/sources" className="text-muted hover:text-fg">
              Databases
            </Link>
            <Link to="/about" className="text-muted hover:text-fg">
              About the index
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
