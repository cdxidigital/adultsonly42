/** Tool / product name — titles, copy, meta. */
export const APP_NAME = "fleshsesh";
/** Visual brand wordmark. */
export const BRAND = "fleshsearch";
