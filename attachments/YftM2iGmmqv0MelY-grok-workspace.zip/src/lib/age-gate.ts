import { create } from "zustand";

const KEY = "fleshsesh.age";
const LEGACY_KEYS = ["fleshsearch.age", "flesh.age", "canon.age"];

type AgeState = {
  ok: boolean;
  enter: () => void;
  leave: () => void;
};

function read(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return (
      window.localStorage.getItem(KEY) === "1" ||
      LEGACY_KEYS.some((k) => window.localStorage.getItem(k) === "1")
    );
  } catch {
    return false;
  }
}

export const useAgeGate = create<AgeState>((set) => ({
  ok: false,
  enter: () => {
    try {
      window.localStorage.setItem(KEY, "1");
    } catch {
      /* ignore quota */
    }
    set({ ok: true });
  },
  leave: () => {
    try {
      window.localStorage.removeItem(KEY);
    } catch {
      /* ignore */
    }
    set({ ok: false });
  },
}));

export function hydrateAgeGate() {
  useAgeGate.setState({ ok: read() });
}
