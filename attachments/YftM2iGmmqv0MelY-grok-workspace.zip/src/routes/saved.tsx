import { createFileRoute, Link } from "@tanstack/react-router";
import { EntityCard } from "@/components/entity-card";
import { Portrait } from "@/components/portrait";
import { getEntity } from "@/lib/catalog";
import { isLiveId, useSaved } from "@/lib/saved";

export const Route = createFileRoute("/saved")({ component: SavedPage });

function SavedPage() {
  const items = useSaved((s) => s.items);
  const local = items
    .map((r) => ({ ref: r, entity: getEntity(r.kind, r.id) }))
    .filter((x) => x.entity);
  const live = items.filter((r) => !getEntity(r.kind, r.id) && isLiveId(r.id));

  return (
    <div>
      <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
        This device
      </p>
      <h1 className="mt-2 font-display text-4xl tracking-tight">Saved</h1>
      {local.length === 0 && live.length === 0 ? (
        <p className="mt-8 max-w-md text-muted">
          Nothing pinned yet. Open a record and save it — the list stays in this
          browser.
        </p>
      ) : (
        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          {local.map(({ entity }) =>
            entity ? <EntityCard key={`${entity.kind}:${entity.id}`} entity={entity} /> : null,
          )}
          {live.map((r) => (
            <Link
              key={`live:${r.id}`}
              to="/live/$qid"
              params={{ qid: r.id }}
              className="flex items-center gap-3 rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]"
            >
              <Portrait
                id={r.id}
                name={r.name ?? r.id}
                kind={r.kind}
                className="size-14 shrink-0"
              />
              <div className="min-w-0">
                <p className="text-[11px] uppercase tracking-[0.14em] text-subtle">
                  Live index
                </p>
                <p className="font-display text-lg">{r.name ?? r.id}</p>
              </div>
            </Link>
          ))}
        </div>
      )}
      <p className="mt-8 text-sm">
        <Link to="/" className="text-muted hover:text-fg">
          Back to the index
        </Link>
      </p>
    </div>
  );
}
