import { useEffect, useState } from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Bookmark, BookmarkCheck, ExternalLink } from "lucide-react";
import { Portrait } from "@/components/portrait";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { KIND_META } from "@/lib/catalog/types";
import { KIND_ICON } from "@/components/kind-mark";
import { getLiveRecord } from "@/lib/live/queries";
import type { LiveHit } from "@/lib/live/types";
import { useSaved } from "@/lib/saved";

export const Route = createFileRoute("/live/$qid")({
  component: LiveRecordPage,
  notFoundComponent: () => (
    <div className="py-8">
      <h1 className="font-display text-3xl">Not in the live index</h1>
      <Link to="/" className="mt-4 inline-block text-sm text-muted hover:text-fg">
        Return home
      </Link>
    </div>
  ),
  beforeLoad: ({ params }) => {
    if (!/^Q[1-9]\d{0,12}$/.test(params.qid)) throw notFound();
  },
});

function LiveRecordPage() {
  const { qid } = Route.useParams();
  const [hit, setHit] = useState<LiveHit | null | undefined>(undefined);
  const saved = useSaved((s) =>
    hit ? s.has({ kind: hit.kind, id: hit.qid }) : false,
  );
  const toggle = useSaved((s) => s.toggle);

  useEffect(() => {
    let alive = true;
    setHit(undefined);
    void getLiveRecord({ data: { qid } }).then((row) => {
      if (alive) setHit(row);
    });
    return () => {
      alive = false;
    };
  }, [qid]);

  if (hit === undefined) {
    return (
      <p className="py-12 text-muted">Looking up the live industry databases…</p>
    );
  }
  if (!hit) {
    return (
      <div className="py-8">
        <h1 className="font-display text-3xl">Not in the live index</h1>
        <p className="mt-3 max-w-md text-muted">
          No adult-industry database record matched this identifier, or the
          performer did not pass the 21+ birth-year filter.
        </p>
      </div>
    );
  }

  const Icon = KIND_ICON[hit.kind];
  const saveRef = { kind: hit.kind, id: hit.qid, name: hit.name };

  return (
    <article>
      <p className="flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
        <Icon className="size-3.5" />
        <Link to="/$kind" params={{ kind: hit.kind }} className="hover:text-fg">
          {KIND_META[hit.kind].singular}
        </Link>
        <span>· Live databases</span>
      </p>

      <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,1fr)_16rem]">
        <div>
          <div className="flex items-start gap-4">
            <Portrait
              id={hit.qid}
              name={hit.name}
              kind={hit.kind}
              className="hidden h-36 w-[6.8rem] shrink-0 sm:block"
            />
            <div className="min-w-0 flex-1">
              <h1 className="font-display text-4xl leading-[1.1] tracking-tight sm:text-5xl">
                {hit.name}
              </h1>
              <div className="mt-4 flex flex-wrap gap-2">
                <Badge>Live index</Badge>
                {hit.region && <Badge variant="outline">{hit.region}</Badge>}
              </div>
              <Button
                variant={saved ? "secondary" : "outline"}
                className="mt-4 min-h-11 lg:hidden"
                onClick={() => toggle(saveRef)}
              >
                {saved ? <BookmarkCheck className="size-4" /> : <Bookmark className="size-4" />}
                {saved ? "Saved" : "Save record"}
              </Button>
            </div>
          </div>

          <p className="mt-8 max-w-2xl text-base leading-relaxed text-fg">{hit.summary}</p>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted">
            Metadata is drawn from Wikidata identifiers for IAFD, Adult Film
            Database, AVN, XXXBios, EGAFD, BGAFD, and EuroBabeIndex.
            fleshsesh does not host explicit media, scene descriptions, or
            photographs. Birth dates are used only to enforce a 21+ filter and
            are not published. Outbound links open the source database.
          </p>

          <section className="mt-10">
            <h2 className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
              Industry databases
            </h2>
            <ul className="mt-3 divide-y divide-border">
              {hit.databases.map((d) => (
                <li key={d.name + d.href}>
                  <a
                    href={d.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex min-h-11 items-center justify-between gap-3 py-2.5 text-sm hover:text-accent"
                  >
                    <span>{d.name}</span>
                    <ExternalLink className="size-3.5 shrink-0 text-subtle" />
                  </a>
                </li>
              ))}
              {hit.wikipedia && (
                <li>
                  <a
                    href={hit.wikipedia}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex min-h-11 items-center justify-between gap-3 py-2.5 text-sm hover:text-accent"
                  >
                    <span>Wikipedia</span>
                    <ExternalLink className="size-3.5 shrink-0 text-subtle" />
                  </a>
                </li>
              )}
            </ul>
          </section>
        </div>

        <aside className="space-y-4 lg:pt-2">
          <Button
            variant={saved ? "secondary" : "outline"}
            className="hidden min-h-11 w-full lg:inline-flex"
            onClick={() => toggle(saveRef)}
          >
            {saved ? <BookmarkCheck className="size-4" /> : <Bookmark className="size-4" />}
            {saved ? "Saved" : "Save record"}
          </Button>
          <dl className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
            <div className="border-b border-border py-2.5">
              <dt className="text-[11px] uppercase tracking-[0.14em] text-subtle">
                Wikidata
              </dt>
              <dd className="mt-1 font-mono text-sm">{hit.qid}</dd>
            </div>
            <div className="py-2.5">
              <dt className="text-[11px] uppercase tracking-[0.14em] text-subtle">
                Sources
              </dt>
              <dd className="mt-1 text-sm">
                {hit.databases.map((d) => d.name).filter((n, i, a) => a.indexOf(n) === i).join(", ") ||
                  "Wikidata"}
              </dd>
            </div>
          </dl>
        </aside>
      </div>
    </article>
  );
}
