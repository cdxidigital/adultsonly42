import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { SearchBox } from "@/components/search-box";
import { EntityRow } from "@/components/entity-card";
import { LiveRow } from "@/components/live-row";
import { KINDS, KIND_META, isKind, search, socialDirectory } from "@/lib/catalog";
import { searchLiveIndex } from "@/lib/live/queries";
import type { LiveHit } from "@/lib/live/types";
import { LIVE_SOURCE_LINE } from "@/lib/live/sources";
import { cn } from "@/lib/utils";

type SearchParams = { q: string; kind: string };

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>): SearchParams => ({
    q: typeof s.q === "string" ? s.q : "",
    kind: typeof s.kind === "string" ? s.kind : "all",
  }),
  component: SearchPage,
});

function SearchPage() {
  const { q, kind } = Route.useSearch();
  const hits =
    kind === "social"
      ? []
      : search(q, kind === "all" || !isKind(kind) ? "all" : kind);
  const socialHits =
    kind === "all" || kind === "social"
      ? socialDirectory().filter((row) => {
          if (!q.trim()) return kind === "social";
          const blob = `${row.platform} ${row.handle} ${row.entity.name}`.toLowerCase();
          return q
            .toLowerCase()
            .split(/\s+/)
            .every((t) => blob.includes(t));
        })
      : [];

  const [live, setLive] = useState<LiveHit[]>([]);
  const [liveState, setLiveState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [liveError, setLiveError] = useState<string | null>(null);

  useEffect(() => {
    const query = q.trim();
    const skipLive =
      query.length < 2 ||
      kind === "social" ||
      kind === "agents" ||
      kind === "events" ||
      kind === "law";
    if (skipLive) {
      setLive([]);
      setLiveState("idle");
      setLiveError(null);
      return;
    }
    let alive = true;
    setLiveState("loading");
    void searchLiveIndex({ data: { q: query, kind } }).then((res) => {
      if (!alive) return;
      setLive(res.hits);
      setLiveError(res.error ?? null);
      setLiveState(res.error ? "error" : "done");
    });
    return () => {
      alive = false;
    };
  }, [q, kind]);

  const liveKinds = kind === "all" || kind === "performers" || kind === "productions" || kind === "companies";

  return (
    <div>
      <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
        Index
      </p>
      <h1 className="mt-2 font-display text-4xl tracking-tight">Search</h1>
      <div className="mt-6 max-w-2xl">
        <SearchBox key={`${kind}:${q}`} initial={q} autoFocus kind={kind} />
      </div>
      <div className="mt-5 flex flex-wrap gap-1.5">
        <FilterChip label="All" kind="all" current={kind} q={q} />
        {KINDS.map((k) => (
          <FilterChip key={k} label={KIND_META[k].label} kind={k} current={kind} q={q} />
        ))}
      </div>
      <p className="mt-6 text-sm text-muted">
        {kind === "social"
          ? `${socialHits.length} public handle${socialHits.length === 1 ? "" : "s"}`
          : `${hits.length} desk record${hits.length === 1 ? "" : "s"}`}
        {liveKinds && q.trim().length >= 2
          ? ` · ${liveState === "loading" ? "querying live databases" : `${live.length} live`}`
          : ""}
        {q.trim() ? ` for “${q}”` : ""}
      </p>

      {hits.length > 0 && (
        <section className="mt-6">
          <h2 className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
            Desk
          </h2>
          <div className="mt-2 divide-y divide-border">
            {hits.map((h) => (
              <EntityRow key={`${h.entity.kind}:${h.entity.id}`} entity={h.entity} q={q} />
            ))}
          </div>
        </section>
      )}

      {(kind === "social" || (kind === "all" && socialHits.length > 0 && q.trim())) && (
        <div className="mt-3 divide-y divide-border">
          {socialHits.map((row) => (
            <Link
              key={`${row.entity.id}-${row.platform}-${row.handle}`}
              to="/$kind/$id"
              params={{ kind: row.entity.kind, id: row.entity.id }}
              className="flex items-center gap-3 py-3 hover:text-accent"
            >
              <span className="w-24 shrink-0 text-[11px] uppercase tracking-[0.14em] text-subtle">
                {row.platform}
              </span>
              <span className="font-mono text-sm">{row.handle}</span>
              <span className="text-sm text-muted">{row.entity.name}</span>
            </Link>
          ))}
        </div>
      )}

      {liveKinds && q.trim().length >= 2 && (
        <section className="mt-10">
          <h2 className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
            Live databases · {LIVE_SOURCE_LINE}
          </h2>
          {liveState === "loading" && (
            <p className="mt-4 text-sm text-muted">Querying Wikidata…</p>
          )}
          {liveState === "error" && (
            <p className="mt-4 text-sm text-muted">
              Live index unavailable{liveError ? ` (${liveError})` : ""}. Desk records above
              still search.
            </p>
          )}
          {live.length > 0 && (
            <div className="mt-2 divide-y divide-border">
              {live.map((hit) => (
                <LiveRow key={hit.qid} hit={hit} q={q} />
              ))}
            </div>
          )}
          {liveState === "done" && live.length === 0 && (
            <p className="mt-4 max-w-md text-sm text-muted">
              No live database match. Try a performer, title, or studio name. Performers
              need a Wikidata birth year of 21+.
            </p>
          )}
        </section>
      )}

      {hits.length === 0 && socialHits.length === 0 && live.length === 0 && liveState !== "loading" && (
        <p className="mt-10 max-w-md text-muted">
          {q.trim()
            ? "Nothing matched the desk. Live results appear below when a public industry database has a record."
            : "Type a name, title, statute, or city. Two characters open the live industry databases."}
        </p>
      )}
    </div>
  );
}

function FilterChip({
  label,
  kind,
  current,
  q,
}: {
  label: string;
  kind: string;
  current: string;
  q: string;
}) {
  const active = current === kind;
  return (
    <Link
      to="/search"
      search={{ q, kind }}
      className={cn(
        "rounded-full px-3 py-2 text-sm transition-colors duration-[var(--motion-quick)]",
        active
          ? "bg-accent text-accent-fg"
          : "text-muted shadow-[var(--shadow-border)] hover:text-fg",
      )}
    >
      {label}
    </Link>
  );
}
