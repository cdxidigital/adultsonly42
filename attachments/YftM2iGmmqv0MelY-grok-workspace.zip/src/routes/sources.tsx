import { createFileRoute, Link } from "@tanstack/react-router";
import { LIVE_DATABASES } from "@/lib/live/sources";

export const Route = createFileRoute("/sources")({ component: SourcesPage });

function SourcesPage() {
  return (
    <article className="mx-auto max-w-2xl">
      <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
        Live index
      </p>
      <h1 className="mt-2 font-display text-4xl tracking-tight">Databases</h1>
      <p className="mt-4 text-base leading-relaxed text-muted">
        Search queries Wikidata for records that carry identifiers from the
        public online industry databases below. Tube sites and clip storefronts
        are not indexed. No explicit media is stored or displayed. Performer
        records require a Wikidata birth year of 21 or older.
      </p>
      <ul className="mt-10 divide-y divide-border">
        {LIVE_DATABASES.map((s) => (
          <li key={s.name} className="py-5">
            <p className="font-display text-2xl leading-snug">{s.name}</p>
            <p className="mt-1 text-sm text-subtle">{s.full}</p>
            <p className="mt-2 text-sm leading-relaxed text-muted">{s.what}</p>
          </li>
        ))}
      </ul>
      <p className="mt-10 text-sm">
        <Link to="/search" search={{ q: "", kind: "all" }} className="text-muted hover:text-fg">
          Open search
        </Link>
      </p>
    </article>
  );
}
