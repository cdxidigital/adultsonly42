import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { SearchBox } from "@/components/search-box";
import { EntityCard } from "@/components/entity-card";
import { KIND_ICON } from "@/components/kind-mark";
import { KINDS, KIND_META, counts, getById, listKind } from "@/lib/catalog";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const LIVE_EXAMPLES = [
  { q: "Riley Reid", kind: "performers", label: "Riley Reid" },
  { q: "Little Caprice", kind: "performers", label: "Little Caprice" },
  { q: "Evil Angel", kind: "companies", label: "Evil Angel" },
  { q: "Deep Throat", kind: "productions", label: "Deep Throat" },
  { q: "2257", kind: "law", label: "18 U.S.C. § 2257" },
] as const;

function Home() {
  const c = counts();
  const spotlight = [
    getById("isla-vane"),
    getById("glass-harbor"),
    getById("fsc-v-paxton"),
    getById("helix-house"),
  ].filter(Boolean);
  const upcoming = listKind("events").filter((e) => e.status === "Upcoming");
  const watch = [
    getById("fsc-v-paxton"),
    getById("take-it-down"),
    getById("usc-2257"),
    getById("state-av-laws"),
  ].filter(Boolean);

  const today = new Date().toLocaleDateString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="space-y-14">
      <section className="relative overflow-hidden rounded-xl bg-surface px-5 py-10 shadow-[var(--shadow-border)] sm:px-10 sm:py-14">
        <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
          Vol. 01 · {today} · 18+
        </p>
        <h1 className="mt-5 max-w-3xl font-display text-4xl leading-[1.1] tracking-tight text-fg sm:text-6xl">
          The adult industry, indexed.
        </h1>
        <p className="mt-4 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
          Search IAFD, AFDB, AVN, XXXBios, EGAFD, and BGAFD via Wikidata — plus
          the desk, calendar, and the statutes that govern the work.
        </p>
        <div className="mt-8 max-w-2xl">
          <SearchBox autoFocus />
        </div>
        <ul className="mt-4 flex flex-wrap gap-x-3 gap-y-1 text-sm text-subtle">
          <li className="uppercase tracking-[0.14em]">Try</li>
          {LIVE_EXAMPLES.map((ex) => (
            <li key={ex.q}>
              <Link
                to="/search"
                search={{ q: ex.q, kind: ex.kind }}
                className="text-muted hover:text-fg"
              >
                {ex.label}
              </Link>
            </li>
          ))}
        </ul>
        <ul className="mt-8 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">
          {KINDS.map((kind) => {
            const Icon = KIND_ICON[kind];
            const live = kind === "performers" || kind === "productions" || kind === "companies";
            return (
              <li key={kind}>
                <Link
                  to="/$kind"
                  params={{ kind }}
                  className="flex min-h-16 flex-col justify-between rounded-md bg-raised px-3 py-2.5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] hover:shadow-[var(--shadow-border-hover)]"
                >
                  <span className="flex items-center gap-1.5 text-[11px] uppercase tracking-[0.14em] text-subtle">
                    <Icon className="size-3.5" strokeWidth={1.75} />
                    {KIND_META[kind].label}
                  </span>
                  <span className="flex items-baseline justify-between gap-2">
                    <span className="font-mono text-lg tabular-nums text-fg">{c[kind]}</span>
                    {live && (
                      <span className="text-[10px] uppercase tracking-[0.12em] text-subtle">
                        + live
                      </span>
                    )}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </section>

      <section>
        <SectionHead
          kicker="Spotlight"
          title="On the desk"
          to="/search"
          action="Open the index"
        />
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          {spotlight.map((e) => (e ? <EntityCard key={e.id} entity={e} /> : null))}
        </div>
      </section>

      <div className="grid gap-10 lg:grid-cols-2">
        <section>
          <SectionHead
            kicker="Calendar"
            title="Upcoming"
            to="/events"
            action="All events"
          />
          <ul className="mt-5 divide-y divide-border">
            {upcoming.map((e) => (
              <li key={e.id}>
                <Link
                  to="/$kind/$id"
                  params={{ kind: "events", id: e.id }}
                  className="flex items-start gap-4 py-4 hover:text-accent"
                >
                  <DateBlock iso={e.dateStart} />
                  <div className="min-w-0">
                    <p className="font-display text-xl leading-snug">{e.name}</p>
                    <p className="mt-1 text-sm text-muted">
                      {e.venue ?? e.region} · {e.subtitle}
                    </p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <section>
          <SectionHead kicker="Desk" title="Legal watch" to="/law" action="Law library" />
          <ul className="mt-5 space-y-2">
            {watch.map((e) =>
              e ? (
                <li key={e.id}>
                  <Link
                    to="/$kind/$id"
                    params={{ kind: "law", id: e.id }}
                    className={cn(
                      "block rounded-lg bg-surface px-4 py-3 shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] hover:shadow-[var(--shadow-border-hover)]",
                    )}
                  >
                    <p className="font-display text-lg leading-snug">{e.name}</p>
                    <p className="mt-1 line-clamp-2 text-sm text-muted">{e.summary}</p>
                  </Link>
                </li>
              ) : null,
            )}
          </ul>
        </section>
      </div>
    </div>
  );
}

function SectionHead({
  kicker,
  title,
  to,
  action,
}: {
  kicker: string;
  title: string;
  to: "/search" | "/events" | "/law";
  action: string;
}) {
  const linkProps =
    to === "/search"
      ? ({ to: "/search", search: { q: "", kind: "all" } } as const)
      : to === "/events"
        ? ({ to: "/$kind", params: { kind: "events" } } as const)
        : ({ to: "/$kind", params: { kind: "law" } } as const);

  return (
    <div className="flex items-end justify-between gap-4">
      <div>
        <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
          {kicker}
        </p>
        <h2 className="mt-1 font-display text-3xl tracking-tight">{title}</h2>
      </div>
      <Link
        {...linkProps}
        className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg"
      >
        {action}
        <ArrowUpRight className="size-4" />
      </Link>
    </div>
  );
}

function DateBlock({ iso }: { iso?: string }) {
  if (!iso) return <div className="size-12" />;
  const d = new Date(iso + "T12:00:00");
  return (
    <div className="flex size-14 shrink-0 flex-col items-center justify-center rounded-md bg-raised shadow-[var(--shadow-border)]">
      <span className="text-[10px] uppercase tracking-[0.14em] text-subtle">
        {d.toLocaleDateString("en-GB", { month: "short" })}
      </span>
      <span className="font-mono text-lg tabular-nums leading-none">{d.getDate()}</span>
    </div>
  );
}
