import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Bookmark, BookmarkCheck } from "lucide-react";
import { Portrait } from "@/components/portrait";
import { EntityCard } from "@/components/entity-card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { KIND_META, getEntity, isKind, relatedOf, resolveCredit } from "@/lib/catalog";
import { useSaved } from "@/lib/saved";
import { KIND_ICON } from "@/components/kind-mark";

export const Route = createFileRoute("/$kind/$id")({
  component: EntityPage,
  notFoundComponent: () => (
    <div className="py-8">
      <h1 className="font-display text-3xl">Not in the index</h1>
      <p className="mt-2 text-muted">That record was not found.</p>
      <Link to="/" className="mt-4 inline-block text-sm text-muted hover:text-fg">
        Return home
      </Link>
    </div>
  ),
  beforeLoad: ({ params }) => {
    if (!isKind(params.kind)) throw notFound();
    const entity = getEntity(params.kind, params.id);
    if (!entity) throw notFound();
  },
});

function EntityPage() {
  const { kind, id } = Route.useParams();
  if (!isKind(kind)) return null;
  const entity = getEntity(kind, id);
  if (!entity) return null;

  const Icon = KIND_ICON[entity.kind];
  const related = relatedOf(entity);
  const saved = useSaved((s) => s.has({ kind: entity.kind, id: entity.id }));
  const toggle = useSaved((s) => s.toggle);

  return (
    <article>
      <p className="flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
        <Icon className="size-3.5" />
        <Link to="/$kind" params={{ kind: entity.kind }} className="hover:text-fg">
          {KIND_META[entity.kind].singular}
        </Link>
        {entity.source === "public" && <span>· Public record</span>}
      </p>

      <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,1fr)_16rem]">
        <div>
          <div className="flex items-start gap-4">
            <Portrait
              id={entity.id}
              name={entity.name}
              kind={entity.kind}
              className="hidden h-36 w-[6.8rem] shrink-0 sm:block"
            />
            <div className="min-w-0 flex-1">
              <h1 className="font-display text-4xl leading-[1.1] tracking-tight sm:text-5xl">
                {entity.name}
              </h1>
              {entity.subtitle && (
                <p className="mt-2 text-lg text-muted">{entity.subtitle}</p>
              )}
              {entity.aka && entity.aka.length > 0 && (
                <p className="mt-1 text-sm text-subtle">Also {entity.aka.join(", ")}</p>
              )}
              <div className="mt-4 flex flex-wrap gap-2">
                {entity.status && <Badge>{entity.status}</Badge>}
                {entity.region && <Badge variant="outline">{entity.region}</Badge>}
                {entity.jurisdiction && (
                  <Badge variant="outline">{entity.jurisdiction}</Badge>
                )}
              </div>
              <Button
                variant={saved ? "secondary" : "outline"}
                className="mt-4 min-h-11 lg:hidden"
                onClick={() => toggle({ kind: entity.kind, id: entity.id })}
              >
                {saved ? (
                  <BookmarkCheck className="size-4" />
                ) : (
                  <Bookmark className="size-4" />
                )}
                {saved ? "Saved" : "Save record"}
              </Button>
            </div>
          </div>

          <p className="mt-8 max-w-2xl text-base leading-relaxed text-fg">
            {entity.summary}
          </p>
          {entity.body &&
            entity.body.split("\n\n").map((para) => (
              <p
                key={para.slice(0, 40)}
                className="mt-4 max-w-2xl text-base leading-relaxed text-muted"
              >
                {para}
              </p>
            ))}

          {entity.credits && entity.credits.length > 0 && (
            <section className="mt-10">
              <h2 className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
                Credits
              </h2>
              <table className="mt-3 w-full text-left text-sm">
                <tbody>
                  {entity.credits.map((c, i) => {
                    const target = resolveCredit(c);
                    return (
                      <tr key={i} className="border-b border-border">
                        <td className="py-2.5 pr-4 text-subtle">{c.role}</td>
                        <td className="py-2.5 pr-4">
                          {target ? (
                            <Link
                              to="/$kind/$id"
                              params={{ kind: target.kind, id: target.id }}
                              className="hover:text-accent"
                            >
                              {c.title}
                            </Link>
                          ) : (
                            c.title
                          )}
                        </td>
                        <td className="py-2.5 font-mono tabular-nums text-muted">
                          {c.year}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </section>
          )}

          {entity.socials && entity.socials.length > 0 && (
            <section className="mt-10">
              <h2 className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
                Public socials
              </h2>
              <ul className="mt-3 space-y-1">
                {entity.socials.map((s) => (
                  <li key={`${s.platform}-${s.handle}`} className="flex gap-3 text-sm">
                    <span className="w-24 text-subtle">{s.platform}</span>
                    <span className="font-mono">{s.handle}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {related.length > 0 && (
            <section className="mt-10">
              <h2 className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
                Related
              </h2>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {related.map((r) => (
                  <EntityCard key={`${r.kind}:${r.id}`} entity={r} compact />
                ))}
              </div>
            </section>
          )}
        </div>

        <aside className="space-y-4 lg:pt-2">
          <Button
            variant={saved ? "secondary" : "outline"}
            className="hidden min-h-11 w-full lg:inline-flex"
            onClick={() => toggle({ kind: entity.kind, id: entity.id })}
          >
            {saved ? (
              <BookmarkCheck className="size-4" />
            ) : (
              <Bookmark className="size-4" />
            )}
            {saved ? "Saved" : "Save record"}
          </Button>
          <dl className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
            {entity.citation && <Fact label="Citation" value={entity.citation} />}
            {entity.venue && <Fact label="Venue" value={entity.venue} />}
            {entity.dateStart && (
              <Fact
                label="Dates"
                value={
                  entity.dateEnd
                    ? `${entity.dateStart} – ${entity.dateEnd}`
                    : entity.dateStart
                }
              />
            )}
            {entity.facts.map((f) => (
              <Fact key={f.label} label={f.label} value={f.value} />
            ))}
          </dl>
          {entity.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {entity.tags.map((t) => (
                <Link
                  key={t}
                  to="/search"
                  search={{ q: t, kind: "all" }}
                  className="rounded-full px-2.5 py-1 text-xs text-muted shadow-[var(--shadow-border)] hover:text-fg"
                >
                  {t}
                </Link>
              ))}
            </div>
          )}
        </aside>
      </div>
    </article>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="border-b border-border py-2.5 last:border-0">
      <dt className="text-[11px] uppercase tracking-[0.14em] text-subtle">{label}</dt>
      <dd className="mt-1 text-sm text-fg">{value}</dd>
    </div>
  );
}
