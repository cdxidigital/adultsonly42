import type { ReactNode } from "react";
import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { EntityCard } from "@/components/entity-card";
import { SearchBox } from "@/components/search-box";
import { KIND_META, isKind, listKind, socialDirectory, type Kind } from "@/lib/catalog";
import { KIND_ICON } from "@/components/kind-mark";
import { LIVE_SOURCE_LINE } from "@/lib/live/sources";

const LIVE_KINDS = new Set<Kind>(["performers", "productions", "companies"]);

const LIVE_PLACEHOLDER: Record<"performers" | "productions" | "companies", string> = {
  performers: "Search a performer in the live databases…",
  productions: "Search a title in the live databases…",
  companies: "Search a studio or distributor…",
};

export const Route = createFileRoute("/$kind/")({
  component: BrowseKind,
  notFoundComponent: () => (
    <div className="py-8">
      <h1 className="font-display text-3xl">Unknown desk</h1>
      <p className="mt-2 text-muted">That section is not in the index.</p>
    </div>
  ),
  beforeLoad: ({ params }) => {
    if (!isKind(params.kind)) throw notFound();
  },
});

function BrowseKind() {
  const { kind } = Route.useParams();
  if (!isKind(kind)) return null;
  const meta = KIND_META[kind];
  const Icon = KIND_ICON[kind];

  if (kind === "social") {
    const rows = socialDirectory();
    return (
      <div>
        <Header
          icon={<Icon className="size-4" />}
          kicker="Directory"
          title={meta.label}
          blurb={meta.blurb}
        />
        <div className="mt-8 overflow-x-auto">
          <table className="w-full min-w-[32rem] text-left text-sm">
            <thead className="text-[11px] uppercase tracking-[0.14em] text-subtle">
              <tr className="border-b border-border">
                <th className="py-2 pr-4 font-medium">Platform</th>
                <th className="py-2 pr-4 font-medium">Handle</th>
                <th className="py-2 font-medium">Record</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr
                  key={`${row.entity.kind}-${row.entity.id}-${row.platform}-${row.handle}`}
                  className="border-b border-border/80"
                >
                  <td className="py-3 pr-4 text-muted">{row.platform}</td>
                  <td className="py-3 pr-4 font-mono">{row.handle}</td>
                  <td className="py-3">
                    <Link
                      to="/$kind/$id"
                      params={{ kind: row.entity.kind, id: row.entity.id }}
                      className="hover:text-accent"
                    >
                      {row.entity.name}
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  const list = listKind(kind);
  const upcoming = kind === "events" ? list.filter((e) => e.status === "Upcoming") : [];
  const rest = kind === "events" ? list.filter((e) => e.status !== "Upcoming") : list;

  return (
    <div>
      <Header
        icon={<Icon className="size-4" />}
        kicker="Browse"
        title={meta.label}
        blurb={meta.blurb}
        count={list.length}
      />
      {LIVE_KINDS.has(kind) && (
        <LiveDeskBanner kind={kind as "performers" | "productions" | "companies"} />
      )}
      {upcoming.length > 0 && (
        <div className="mt-8">
          <h2 className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
            Upcoming
          </h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {upcoming.map((e) => (
              <EntityCard key={e.id} entity={e} />
            ))}
          </div>
        </div>
      )}
      <div className={upcoming.length ? "mt-10" : "mt-8"}>
        {upcoming.length > 0 && (
          <h2 className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
            Archive
          </h2>
        )}
        {LIVE_KINDS.has(kind) && (
          <h2 className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
            Desk roster
          </h2>
        )}
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {rest.map((e) => (
            <EntityCard key={e.id} entity={e} />
          ))}
        </div>
      </div>
    </div>
  );
}

function LiveDeskBanner({
  kind,
}: {
  kind: "performers" | "productions" | "companies";
}) {
  const noun =
    kind === "performers" ? "performers" : kind === "productions" ? "titles" : "studios";
  return (
    <div className="mt-8 rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
      <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
        Live databases
      </p>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
        Search a name to query the public industry databases for {noun}. The
        roster below is the demonstration desk. Performers need a Wikidata birth
        year of 21+.
      </p>
      <p className="mt-2 text-[11px] uppercase tracking-[0.14em] text-subtle">
        {LIVE_SOURCE_LINE}
      </p>
      <div className="mt-4 max-w-xl">
        <SearchBox size="sm" kind={kind} placeholder={LIVE_PLACEHOLDER[kind]} />
      </div>
      <p className="mt-3 text-sm">
        <Link to="/sources" className="text-muted hover:text-fg">
          How the index is sourced
        </Link>
      </p>
    </div>
  );
}

function Header({
  icon,
  kicker,
  title,
  blurb,
  count,
}: {
  icon: ReactNode;
  kicker: string;
  title: string;
  blurb: string;
  count?: number;
}) {
  return (
    <div>
      <p className="flex items-center gap-2 text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
        {icon}
        {kicker}
        {typeof count === "number" && (
          <span className="font-mono tabular-nums text-muted">{count}</span>
        )}
      </p>
      <h1 className="mt-2 font-display text-4xl tracking-tight">{title}</h1>
      <p className="mt-3 max-w-xl text-muted">{blurb}</p>
    </div>
  );
}
