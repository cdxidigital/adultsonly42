import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({ component: About });

function About() {
  return (
    <article className="mx-auto max-w-2xl">
      <p className="text-[11px] font-medium uppercase tracking-[0.22em] text-subtle">
        Methodology
      </p>
      <h1 className="mt-2 font-display text-4xl tracking-tight">About the index</h1>
      <div className="mt-8 space-y-5 text-base leading-relaxed text-muted">
        <p>
          fleshsesh is a search engine for the adult entertainment trade:
          performers, productions, companies, agents, events, public socials, and
          the law. It is built as a professional register, not a tube.
        </p>
        <p>
          The live index queries Wikidata for records that carry identifiers from
          IAFD, Adult Film Database, AVN, XXXBios, EGAFD, BGAFD, and
          EuroBabeIndex. Tube platforms and clip storefronts are not indexed. No
          explicit media, scene descriptions, or photographs are hosted.
          Performer rows require a Wikidata birth year of 21 or older; the date
          itself is not displayed.
        </p>
        <p>
          A smaller demonstration roster (talent, titles, houses, representation)
          sits on the desk for browsing when you are not searching a live name.
          The law desk and parts of the calendar are public record. Summaries are
          orientation, not legal advice.
        </p>
        <p>
          Saved records live only on this device. There are no accounts. Report
          trafficking to law enforcement or the U.S. National Human Trafficking
          Hotline, 1-888-373-7888.
        </p>
        <p>
          <Link to="/sources" className="text-fg hover:text-accent">
            Databases we index
          </Link>
        </p>
      </div>
    </article>
  );
}
