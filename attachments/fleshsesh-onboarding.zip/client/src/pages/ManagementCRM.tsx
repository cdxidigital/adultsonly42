import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { buildManagementCsv, type ManagementCsvRow } from "@/lib/managementCsv";
import { trpc } from "@/lib/trpc";
import { Activity, ArrowLeft, ArrowUpRight, BellRing, CalendarDays, CheckCircle2, ChevronRight, Clock3, Download, FileImage, MapPin, MessageSquareText, Search, ShieldCheck, UserRoundCheck, UsersRound } from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation, useRoute } from "wouter";

const statusOptions = [
  { value: "all", label: "All profiles" },
  { value: "pending_review", label: "Pending review" },
  { value: "in_review", label: "In review" },
  { value: "profile_ready", label: "Profile ready" },
  { value: "changes_requested", label: "Update requested" },
] as const;

type Status = Exclude<(typeof statusOptions)[number]["value"], "all">;

const statusMeta: Record<Status, { label: string; tone: string }> = {
  pending_review: { label: "Pending review", tone: "pending" },
  in_review: { label: "In review", tone: "review" },
  profile_ready: { label: "Profile ready", tone: "ready" },
  changes_requested: { label: "Update requested", tone: "changes" },
};

function formatDate(value: Date | string) {
  return new Date(value).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

function statusDetails(status: string) {
  return statusMeta[status as Status] ?? { label: status.replaceAll("_", " "), tone: "pending" };
}

function downloadManagementCsv(rows: ManagementCsvRow[]) {
  if (!rows.length) return;
  const blob = new Blob([buildManagementCsv(rows)], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `fleshsesh-review-queue-${new Date().toISOString().slice(0, 10)}.csv`;
  anchor.click();
  URL.revokeObjectURL(url);
}

function ManagementGate({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (user?.role !== "admin") {
    return (
      <DashboardLayout>
        <section className="crm-access-state">
          <div className="crm-access-mark"><ShieldCheck size={25} /></div>
          <p className="dashboard-kicker">management access</p>
          <h1>This room is<br /><em>for the review desk.</em></h1>
          <p>Management CRM access is restricted to authorised fleshsesh administrators.</p>
        </section>
      </DashboardLayout>
    );
  }
  return <>{children}</>;
}

export function ManagementCRM() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<(typeof statusOptions)[number]["value"]>("all");
  const [, setLocation] = useLocation();
  const listInput = useMemo(() => ({ status, search }), [status, search]);
  const list = trpc.profile.managementList.useQuery(listInput, { enabled: user?.role === "admin", refetchOnWindowFocus: false });
  const profiles = list.data ?? [];

  return (
    <ManagementGate>
      <DashboardLayout>
        <section className="crm-shell">
          <header className="crm-header">
            <div>
              <p className="dashboard-kicker">fleshsesh / management</p>
              <h1>Review the<br /><em>right people.</em></h1>
              <p className="crm-header-copy">A calm view of every profile entering the fleshsesh review desk.</p>
            </div>
            <div className="crm-header-stamp"><UsersRound size={18} /><span><strong>{profiles.length}</strong><small>visible profiles</small></span></div>
          </header>

          <div className="crm-toolbar">
            <label className="crm-search"><Search size={16} /><span className="sr-only">Search profiles</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search name, location or email" /></label>
            <div className="crm-toolbar-actions">
              <button type="button" className="crm-export-button" disabled={!profiles.length} onClick={() => downloadManagementCsv(profiles)}><Download size={14} /> Export CSV</button>
              <div className="crm-filter-group" aria-label="Filter by review status">
                {statusOptions.map((option) => <button key={option.value} type="button" className={status === option.value ? "is-active" : ""} onClick={() => setStatus(option.value)}>{option.label}</button>)}
              </div>
            </div>
          </div>

          {list.isLoading ? <div className="crm-state"><span className="crm-loader" /> Loading the review desk</div> : list.error ? <div className="crm-state crm-state-error"><p className="dashboard-kicker">review desk unavailable</p><strong>We could not load the profile queue.</strong><button type="button" onClick={() => list.refetch()}>Try again</button></div> : profiles.length === 0 ? <div className="crm-empty"><UsersRound size={24} /><p className="dashboard-kicker">no matching profiles</p><h2>The queue is<br /><em>quiet for now.</em></h2><p>New talent submissions will appear here when they enter the fleshsesh review queue.</p></div> : <div className="crm-list" aria-label="Talent profile queue">{profiles.map(({ profile, user: profileUser }) => {
            const meta = statusDetails(profile.reviewStatus);
            return <button type="button" className="crm-list-row" key={profile.id} onClick={() => setLocation(`/management/${profile.id}`)}>
              <span className="crm-avatar">{profile.displayName.slice(0, 1).toUpperCase()}</span>
              <span className="crm-row-identity"><strong>{profile.displayName}</strong><small>{profile.profileType} · {profileUser?.email ?? "No email"}</small></span>
              <span className="crm-row-location"><MapPin size={14} /> {profile.location}</span>
              <span className={`status-pill ${meta.tone}`}><Clock3 size={13} /> {meta.label}</span>
              <span className="crm-row-date"><small>Submitted</small>{formatDate(profile.submittedAt)}</span>
              <ChevronRight className="crm-row-chevron" size={18} />
            </button>;
          })}</div>}

          <footer className="crm-footer-note"><ShieldCheck size={15} /><span>Profiles are private review material. Keep exports and conversations inside the authorised management team.</span></footer>
        </section>
      </DashboardLayout>
    </ManagementGate>
  );
}

export function ManagementProfile() {
  const { user } = useAuth();
  const [, params] = useRoute<{ profileId: string }>("/management/:profileId");
  const [, setLocation] = useLocation();
  const profileId = Number(params?.profileId);
  const detail = trpc.profile.managementDetail.useQuery({ profileId }, { enabled: user?.role === "admin" && Number.isInteger(profileId) && profileId > 0, refetchOnWindowFocus: false });
  const reviewers = trpc.profile.managementReviewers.useQuery(undefined, { enabled: user?.role === "admin", refetchOnWindowFocus: false });
  const updateStatus = trpc.profile.updateStatus.useMutation({ onSuccess: () => detail.refetch() });
  const assignReviewer = trpc.profile.assignReviewer.useMutation({ onSuccess: () => detail.refetch() });
  const addInternalNote = trpc.profile.addInternalNote.useMutation({ onSuccess: () => { setInternalNote(""); detail.refetch(); } });
  const [selectedStatus, setSelectedStatus] = useState<Status>("in_review");
  const [title, setTitle] = useState("Profile review started");
  const [message, setMessage] = useState("A fleshsesh reviewer has opened this profile and is assessing the next step.");
  const [internalNote, setInternalNote] = useState("");
  const selectedMeta = statusDetails(selectedStatus);

  if (user?.role !== "admin") return <ManagementGate><div /></ManagementGate>;

  return (
    <DashboardLayout>
      <section className="crm-shell crm-detail-shell">
        <button type="button" className="crm-back-link" onClick={() => setLocation("/management")}><ArrowLeft size={15} /> Back to review queue</button>
        {detail.isLoading ? <div className="crm-state"><span className="crm-loader" /> Loading profile dossier</div> : detail.error ? <div className="crm-state crm-state-error"><p className="dashboard-kicker">profile unavailable</p><strong>We could not load this dossier.</strong><button type="button" onClick={() => detail.refetch()}>Try again</button></div> : !detail.data ? <div className="crm-empty"><UsersRound size={24} /><h2>Profile not<br /><em>found.</em></h2><button type="button" className="dashboard-primary-button" onClick={() => setLocation("/management")}>Return to queue</button></div> : <>
          <header className="crm-detail-header">
            <div className="crm-profile-heading">{detail.data.profile.primaryPortraitUrl && <img className="crm-profile-portrait" src={detail.data.profile.primaryPortraitUrl} alt={`${detail.data.profile.displayName} portrait`} />}<div><p className="dashboard-kicker">profile dossier / {String(detail.data.profile.id).padStart(2, "0")}</p><h1>{detail.data.profile.displayName}<br /><em>{detail.data.profile.profileType}</em></h1><p className="crm-header-copy">{detail.data.user?.email ?? "No account email recorded"} · {detail.data.profile.location}</p></div></div>
            <span className={`status-pill ${statusDetails(detail.data.profile.reviewStatus).tone}`}><Clock3 size={13} /> {statusDetails(detail.data.profile.reviewStatus).label}</span>
          </header>

          <div className="crm-detail-grid">
            <section className="crm-dossier-card crm-dossier-overview"><div className="crm-card-label"><UsersRound size={14} /> Profile overview</div><div className="crm-detail-facts"><div><small>Practice</small><strong>{detail.data.profile.practiceRole || "Not specified"}</strong></div><div><small>Energy</small><strong>{detail.data.profile.energy || "Not specified"}</strong></div><div><small>Location</small><strong>{detail.data.profile.location}</strong></div><div><small>Availability</small><strong>{detail.data.profile.availability || "Not specified"}</strong></div><div><small>Focus areas</small><strong>{JSON.parse(detail.data.profile.focusAreas ?? "[]").join(" · ") || "Not specified"}</strong></div><div><small>Intent areas</small><strong>{JSON.parse(detail.data.profile.intentAreas ?? "[]").join(" · ") || "Not specified"}</strong></div><div><small>Visibility</small><strong>{detail.data.profile.visibility}</strong></div><div><small>Record version</small><strong>v{detail.data.profile.profileVersion}</strong></div></div><div className="crm-measurements"><small>Measurements</small><div>{[["Height", detail.data.profile.height], ["Chest / bust", detail.data.profile.chestOrBust], ["Waist", detail.data.profile.waist], ["Hips", detail.data.profile.hips], ["Shoe", detail.data.profile.shoeSize]].map(([label, value]) => <span key={label}><b>{label}</b>{value || "—"}</span>)}</div></div></section>

            <section className="crm-dossier-card crm-review-card"><div className="crm-card-label"><CheckCircle2 size={14} /> Member-visible review update</div><p className="crm-card-copy">This message is published to the member timeline and triggers a management notification event. Use the private note panel for internal commentary.</p><div className="crm-status-selects">{(Object.keys(statusMeta) as Status[]).map((option) => <button type="button" key={option} className={selectedStatus === option ? "is-active" : ""} onClick={() => setSelectedStatus(option)}><span className={`status-dot ${statusMeta[option].tone}`} />{statusMeta[option].label}</button>)}</div><label className="crm-field"><span>Update title</span><input value={title} onChange={(event) => setTitle(event.target.value)} /></label><label className="crm-field"><span>Message</span><textarea value={message} onChange={(event) => setMessage(event.target.value)} /></label><button type="button" className="dashboard-primary-button crm-update-button" disabled={updateStatus.isPending || !title.trim() || !message.trim()} onClick={() => updateStatus.mutate({ profileId: detail.data!.profile.id, status: selectedStatus, title, message })}>{updateStatus.isPending ? "Saving update" : "Publish member update"}<ArrowUpRight size={16} /></button>{updateStatus.error && <p className="submission-error" role="alert">{updateStatus.error.message}</p>}</section>

            <section className="crm-dossier-card crm-assignment-card"><div className="crm-card-label"><UserRoundCheck size={14} /> Review owner</div><p className="crm-card-copy">Assign one management reviewer to keep the next action and handover visible.</p><label className="crm-field"><span>Assigned reviewer</span><select value={detail.data.profile.assignedReviewerId ?? ""} onChange={(event) => assignReviewer.mutate({ profileId: detail.data!.profile.id, reviewerId: event.target.value ? Number(event.target.value) : null })} disabled={assignReviewer.isPending}><option value="">Unassigned</option>{(reviewers.data ?? []).map((reviewer) => <option key={reviewer.id} value={reviewer.id}>{reviewer.name || reviewer.email || `Reviewer ${reviewer.id}`}</option>)}</select></label><p className="crm-assignment-state">{assignReviewer.isPending ? "Updating owner…" : detail.data.profile.assignedReviewerId ? "Review owner assigned." : "No review owner yet."}</p></section>

            <section className="crm-dossier-card crm-internal-notes-card"><div className="crm-card-label"><MessageSquareText size={14} /> Private management notes</div><p className="crm-card-copy">These notes remain in the management dossier and are never added to the member timeline.</p><label className="crm-field"><span>Internal note</span><textarea value={internalNote} onChange={(event) => setInternalNote(event.target.value)} placeholder="Capture casting context, follow-up or a private handover note." /></label><button type="button" className="dashboard-primary-button crm-update-button" disabled={addInternalNote.isPending || internalNote.trim().length < 2} onClick={() => addInternalNote.mutate({ profileId: detail.data!.profile.id, note: internalNote })}>{addInternalNote.isPending ? "Saving note" : "Save private note"}<ArrowUpRight size={16} /></button><ol className="crm-private-note-list">{detail.data.internalNotes.length ? detail.data.internalNotes.map((note) => <li key={note.id}><p>{note.note}</p><small>{formatDate(note.createdAt)} · internal only</small></li>) : <li className="crm-empty-inline">No private notes yet.</li>}</ol></section>

            <section className="crm-dossier-card crm-lookbook-review"><div className="crm-card-label"><FileImage size={14} /> Look book <span>{detail.data.assets.length} / 4</span></div>{detail.data.assets.length ? <div className="crm-lookbook-grid">{detail.data.assets.map((asset, index) => <figure key={asset.id}><img src={asset.imageUrl} alt={`${detail.data!.profile.displayName} look book image ${index + 1}`} style={{ objectPosition: asset.cropPosition }} /><figcaption>{String(index + 1).padStart(2, "0")}</figcaption></figure>)}</div> : <div className="crm-lookbook-empty"><FileImage size={20} /> No visual selects submitted.</div>}</section>

            <section className="crm-dossier-card crm-history-card"><div className="crm-card-label"><CalendarDays size={14} /> Review history</div><ol className="crm-history-list">{detail.data.updates.map((update) => <li key={update.id}><span className={`status-dot ${statusDetails(update.status).tone}`} /><div><strong>{update.title}</strong><p>{update.message}</p><small>{formatDate(update.createdAt)} · {statusDetails(update.status).label}</small></div></li>)}</ol></section>

            <section className="crm-dossier-card crm-audit-card"><div className="crm-card-label"><Activity size={14} /> Record activity</div><ol className="crm-private-note-list">{detail.data.auditEvents.length ? detail.data.auditEvents.map((event) => <li key={event.id}><p>{event.eventType.replaceAll("_", " ")}</p><small>{formatDate(event.createdAt)} · actor {event.actorUserId ?? "system"}</small></li>) : <li className="crm-empty-inline">No recorded activity yet.</li>}</ol></section>

            <section className="crm-dossier-card crm-delivery-card"><div className="crm-card-label"><BellRing size={14} /> Management notification delivery</div><p className="crm-card-copy">Delivery events record whether the management inbox notification was accepted by the configured mail provider.</p><ol className="crm-private-note-list">{detail.data.deliveryEvents.length ? detail.data.deliveryEvents.map((event) => <li key={event.id}><p>{event.subject}</p><small>{formatDate(event.createdAt)} · {event.deliveryStatus}{event.errorDetail ? ` · ${event.errorDetail}` : ""}</small></li>) : <li className="crm-empty-inline">No notification events for this profile yet.</li>}</ol></section>
          </div>
        </>}
      </section>
    </DashboardLayout>
  );
}
