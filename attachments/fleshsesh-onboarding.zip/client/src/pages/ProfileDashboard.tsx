import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, ArrowUpRight, CheckCircle2, Clock3, FileImage, MapPin, RefreshCw, Sparkles } from "lucide-react";
import { useLocation } from "wouter";

const statusMeta = {
  pending_review: { label: "Pending review", tone: "pending", description: "Your profile is in the considered review queue." },
  in_review: { label: "In review", tone: "review", description: "A fleshsesh reviewer is currently assessing your profile." },
  profile_ready: { label: "Profile ready", tone: "ready", description: "Your look book is ready for approved introductions." },
  changes_requested: { label: "Update requested", tone: "changes", description: "A small update is needed before the next review." },
} as const;

function formatDate(value: Date | string) {
  return new Date(value).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

export default function ProfileDashboard() {
  const { isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();
  const dashboard = trpc.profile.dashboard.useQuery(undefined, { enabled: isAuthenticated, refetchOnWindowFocus: false });
  const profileData = dashboard.data;

  return (
    <DashboardLayout>
      <section className="profile-dashboard-shell">
        <header className="profile-dashboard-header">
          <div>
            <p className="dashboard-kicker">member profile / review desk</p>
            <h1>Your profile,<br /><em>in context.</em></h1>
          </div>
          <button type="button" className="dashboard-quiet-button" onClick={() => dashboard.refetch()} disabled={dashboard.isFetching}><RefreshCw size={15} className={dashboard.isFetching ? "is-spinning" : ""} /> Refresh status</button>
        </header>

        {loading || (isAuthenticated && dashboard.isLoading) ? (
          <div className="dashboard-loading"><span /><span /><span /> Loading your profile status</div>
        ) : dashboard.error ? (
          <section className="dashboard-empty-state dashboard-error-state">
            <div className="dashboard-empty-orbit"><RefreshCw size={24} /></div>
            <p className="dashboard-kicker">profile status unavailable</p>
            <h2>We could not reach<br /><em>your review desk.</em></h2>
            <p>Your saved profile is not affected. Please retry the status request, or return to onboarding if the issue continues.</p>
            <button type="button" className="dashboard-primary-button" onClick={() => dashboard.refetch()}><RefreshCw size={16} /> Try again</button>
          </section>
        ) : !profileData ? (
          <section className="dashboard-empty-state">
            <div className="dashboard-empty-orbit"><Sparkles size={24} /></div>
            <p className="dashboard-kicker">profile not submitted</p>
            <h2>Start the profile<br /><em>you want considered.</em></h2>
            <p>Complete your talent profile, practical details and visual selects to enter the fleshsesh review queue.</p>
            <button type="button" className="dashboard-primary-button" onClick={() => setLocation("/")}>Begin onboarding <ArrowUpRight size={16} /></button>
          </section>
        ) : (
          <div className="dashboard-content-grid">
            <section className="dashboard-status-card">
              <div className="status-card-heading">
                <div>
                  <p className="dashboard-kicker">current status</p>
                  <h2>{statusMeta[profileData.profile.reviewStatus].label}</h2>
                </div>
                <span className={`status-pill ${statusMeta[profileData.profile.reviewStatus].tone}`}><Clock3 size={13} /> {statusMeta[profileData.profile.reviewStatus].label}</span>
              </div>
              <p className="status-card-copy">{statusMeta[profileData.profile.reviewStatus].description}</p>
              <div className="status-card-meta"><span><CheckCircle2 size={15} /> Submitted {formatDate(profileData.profile.submittedAt)}</span><span><MapPin size={15} /> {profileData.profile.location}</span></div>
              <div className="status-stage-line"><span className="is-complete">Submitted</span><span className={profileData.profile.reviewStatus !== "pending_review" ? "is-complete" : "is-current"}>Review</span><span className={profileData.profile.reviewStatus === "profile_ready" ? "is-complete" : ""}>Ready</span></div>
            </section>

            <section className="dashboard-profile-card">
              <div className="dashboard-card-heading"><div><p className="dashboard-kicker">profile snapshot</p><h3>{profileData.profile.displayName}</h3></div><button type="button" className="dashboard-text-button" onClick={() => setLocation("/")}>Edit <ArrowUpRight size={13} /></button></div>
              <div className="dashboard-summary-tags"><span>{profileData.profile.profileType}</span>{JSON.parse(profileData.profile.focusAreas ?? "[]").slice(0, 3).map((focus: string) => <span key={focus}>{focus}</span>)}</div>
              <div className="dashboard-details"><div><small>Availability</small><strong>{profileData.profile.availability || "Not yet specified"}</strong></div><div><small>Measurements</small><strong>{[profileData.profile.height, profileData.profile.chestOrBust, profileData.profile.waist, profileData.profile.hips, profileData.profile.shoeSize].filter(Boolean).join(" · ") || "Not yet specified"}</strong></div></div>
            </section>

            <section className="dashboard-lookbook-card">
              <div className="dashboard-card-heading"><div><p className="dashboard-kicker">visual selects</p><h3>Look book</h3></div><span>{profileData.assets.length} / 4</span></div>
              {profileData.assets.length ? <div className="dashboard-lookbook-grid">{profileData.assets.map((asset, index) => <figure key={asset.id}><img src={asset.imageUrl} alt={`Look book image ${index + 1}`} style={{ objectPosition: asset.cropPosition }} /><figcaption>{String(index + 1).padStart(2, "0")}</figcaption></figure>)}</div> : <div className="dashboard-lookbook-empty"><FileImage size={20} /> Visual selects can be added from your profile.</div>}
            </section>

            <section className="dashboard-updates-card">
              <div className="dashboard-card-heading"><div><p className="dashboard-kicker">review queue</p><h3>Updates</h3></div></div>
              <ol className="review-update-list">{profileData.updates.map((update) => <li key={update.id}><span className={`update-dot ${statusMeta[update.status].tone}`} /><div><strong>{update.title}</strong><p>{update.message}</p><small>{formatDate(update.createdAt)}</small></div></li>)}</ol>
            </section>
          </div>
        )}

        <button type="button" className="dashboard-back-link" onClick={() => setLocation("/")}><ArrowLeft size={15} /> Return to onboarding</button>
      </section>
    </DashboardLayout>
  );
}
