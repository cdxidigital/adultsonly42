/**
 * fleshsesh creator profile interface: a private, editorial sequence with direct brand presence and non-explicit creative media motion.
 */
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  ExternalLink,
  CalendarDays,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  Compass,
  HeartHandshake,
  ImagePlus,
  MapPin,
  ShieldCheck,
  Sparkles,
  UserRound,
  X,
} from "lucide-react";
import { ChangeEvent, useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";

type Step = 0 | 1 | 2 | 3 | 4 | 5;
type LookbookStep = 0 | 1 | 2 | 3;
type OnboardingPhase = "intake" | "lookbook";
type LookbookDraftImage = { id: string; dataUrl?: string; storageKey?: string; imageUrl?: string; cropPosition: string; filename: string };
type ExistingLookbookAsset = { id: number; imageUrl: string; cropPosition: string; sortOrder: number };
type ExistingAssetEdit = { id: number; cropPosition: string; sortOrder: number; remove: boolean };
type DraftPayload = {
  step?: Step;
  onboardingPhase?: OnboardingPhase;
  lookbookStep?: LookbookStep;
  name?: string;
  location?: string;
  role?: string;
  intent?: string[];
  energy?: string;
  profileType?: string;
  profileFocus?: string[];
  height?: string;
  chestOrBust?: string;
  waist?: string;
  hips?: string;
  shoeSize?: string;
  availability?: string;
  visibility?: string;
  primaryPortrait?: { dataUrl?: string; storageKey?: string; imageUrl?: string };
  lookbookImages?: Array<{ dataUrl?: string; storageKey?: string; imageUrl?: string; cropPosition: string; filename?: string }>;
  replaceLookbook?: boolean;
  existingAssetEdits?: ExistingAssetEdit[];
};

const steps = ["Introduction", "Practice", "Interests", "Energy", "First impression"];
const fleshseshWebsiteUrl = "https://fleshsesh.com";

const interestOptions = [
  "Model & talent",
  "Creative direction",
  "Image making",
  "Design & culture",
  "Production",
  "Brand partnerships",
];

const energyOptions = [
  { label: "Quiet confidence", note: "Precise. Observant. Intentional." },
  { label: "In motion", note: "Curious. Social. Open to the next room." },
  { label: "Making noise", note: "Expressive. Unexpected. Unafraid of scale." },
];

const profileTypes = [
  { label: "Model", note: "Editorial, campaign, runway or e-commerce" },
  { label: "Creator", note: "Image, story, community or creative practice" },
  { label: "Talent", note: "Performance, presence, hosting or specialist work" },
  { label: "Industry partner", note: "Casting, agency, brand or production" },
];

const profileFocusOptions = ["Campaign & e-commerce", "Editorial", "Runway", "Beauty", "Performance", "Creative collaboration"];
const visibilityOptions = [
  { label: "Curated introductions", note: "Visible only when a relevant fleshsesh opportunity is in play." },
  { label: "Look-book ready", note: "Prepared for approved partners to review in confidence." },
  { label: "Keep private", note: "Saved for your return without being shared onward." },
];

const cropOptions = [
  { label: "Left", value: "20% 50%" },
  { label: "Centre", value: "50% 50%" },
  { label: "Right", value: "80% 50%" },
];
const MAX_LOOKBOOK_FILE_BYTES = 10 * 1024 * 1024;
const PRE_AUTH_DRAFT_KEY = "fleshsesh-onboarding-pre-auth-draft";

function readImageAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Unable to read ${file.name}.`));
    reader.onload = () => resolve(String(reader.result));
    reader.readAsDataURL(file);
  });
}

const brandWordmark = "/manus-storage/fleshsesh-wordmark-attached-alpha_fce528bf.png";
const brandLipsIcon = "/manus-storage/fleshsesh-lips-icon_217b91c5.png";
const introVideo = "/manus-storage/1000004596_c697c7fb.mp4";
const mobileIntroVideo = "/manus-storage/fleshsesh-logo-intro-mobile_90c9329c.mp4";

function ChoiceCard({
  active,
  label,
  note,
  onClick,
}: {
  active: boolean;
  label: string;
  note?: string;
  onClick: () => void;
}) {
  return (
    <button
      className={`choice-card ${active ? "is-active" : ""}`}
      type="button"
      onClick={onClick}
      aria-pressed={active}
    >
      <span className="choice-check">{active && <Check size={14} strokeWidth={3} />}</span>
      <span>
        <strong>{label}</strong>
        {note && <small>{note}</small>}
      </span>
    </button>
  );
}

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [, setLocationRoute] = useLocation();
  const [step, setStep] = useState<Step>(0);
  const [onboardingPhase, setOnboardingPhase] = useState<OnboardingPhase>("intake");
  const [lookbookStep, setLookbookStep] = useState<LookbookStep>(0);
  const [name, setName] = useState("");
  const [location, setLocation] = useState("Perth, WA");
  const [role, setRole] = useState("Creative / talent");
  const [intent, setIntent] = useState<string[]>(["Model & talent", "Creative direction"]);
  const [energy, setEnergy] = useState("Quiet confidence");
  const [primaryPortraitDataUrl, setPrimaryPortraitDataUrl] = useState("");
  const [primaryPortraitStorageKey, setPrimaryPortraitStorageKey] = useState("");
  const [profileType, setProfileType] = useState("Model");
  const [profileFocus, setProfileFocus] = useState<string[]>(["Campaign & e-commerce", "Editorial"]);
  const [height, setHeight] = useState("");
  const [chestOrBust, setChestOrBust] = useState("");
  const [waist, setWaist] = useState("");
  const [hips, setHips] = useState("");
  const [shoeSize, setShoeSize] = useState("");
  const [availability, setAvailability] = useState("");
  const [lookbookImages, setLookbookImages] = useState<LookbookDraftImage[]>([]);
  const [selectedLookbookImageId, setSelectedLookbookImageId] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState("");
  const [visibility, setVisibility] = useState("Curated introductions");
  const [complete, setComplete] = useState(false);
  const [showLoading, setShowLoading] = useState(true);
  const [loadingExiting, setLoadingExiting] = useState(false);
  const [videoActivated, setVideoActivated] = useState(false);
  const [existingLookbookAssets, setExistingLookbookAssets] = useState<ExistingLookbookAsset[]>([]);
  const [replaceLookbook, setReplaceLookbook] = useState(false);
  const [existingAssetEdits, setExistingAssetEdits] = useState<ExistingAssetEdit[]>([]);
  const [selectedExistingAssetId, setSelectedExistingAssetId] = useState<number | null>(null);
  const [formInitialized, setFormInitialized] = useState(false);
  const [draftSavedAt, setDraftSavedAt] = useState<Date | null>(null);
  const editor = trpc.profile.editor.useQuery(undefined, { enabled: isAuthenticated, refetchOnWindowFocus: false });
  const saveDraft = trpc.profile.saveDraft.useMutation({ onSuccess: () => setDraftSavedAt(new Date()) });

  const enterExperience = () => {
    setLoadingExiting(true);
    window.setTimeout(() => setShowLoading(false), 420);
  };

  useEffect(() => {
    const timer = window.setTimeout(enterExperience, 2600);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!showLoading || videoActivated) return;
    const activate = () => setVideoActivated(true);
    const options = { once: true, passive: true };
    window.addEventListener("pointerdown", activate, options);
    window.addEventListener("mousedown", activate, options);
    window.addEventListener("click", activate, options);
    window.addEventListener("keydown", activate, options);
    window.addEventListener("touchstart", activate, options);
    return () => {
      window.removeEventListener("pointerdown", activate);
      window.removeEventListener("mousedown", activate);
      window.removeEventListener("click", activate);
      window.removeEventListener("keydown", activate);
      window.removeEventListener("touchstart", activate);
    };
  }, [showLoading, videoActivated]);

  const currentStep = onboardingPhase === "intake" ? Math.min(step, 4) : 5 + lookbookStep;
  const totalSteps = 9;
  const percent = useMemo(() => ((currentStep + 1) / totalSteps) * 100, [currentStep]);

  const toggleIntent = (item: string) => {
    setIntent((items) => (items.includes(item) ? items.filter((value) => value !== item) : [...items, item]));
  };

  const toggleProfileFocus = (item: string) => {
    setProfileFocus((items) => (items.includes(item) ? items.filter((value) => value !== item) : [...items, item]));
  };

  const handleImage = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!file) return;
    if (!allowedTypes.includes(file.type) || file.size > MAX_LOOKBOOK_FILE_BYTES) {
      setUploadError(!allowedTypes.includes(file.type) ? "Use a JPEG, PNG or WebP image." : "The portrait must be 10 MB or smaller.");
      event.target.value = "";
      return;
    }
    void readImageAsDataUrl(file).then((dataUrl) => { setPrimaryPortraitDataUrl(dataUrl); setPrimaryPortraitStorageKey(""); }).catch((error: Error) => setUploadError(error.message));
    event.target.value = "";
  };

  const handleLookbookImages = (event: ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files ?? []);
    const remainingSlots = 4 - lookbookImages.length;
    const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
    const invalidFile = selectedFiles.find((file) => !allowedTypes.includes(file.type) || file.size > MAX_LOOKBOOK_FILE_BYTES);
    if (invalidFile) {
      setUploadError(!allowedTypes.includes(invalidFile.type) ? "Use a JPEG, PNG or WebP image." : "Each look-book image must be 10 MB or smaller.");
      event.target.value = "";
      return;
    }
    if (!remainingSlots) {
      setUploadError("Your look book already has four visual selects.");
      event.target.value = "";
      return;
    }
    if (selectedFiles.length > remainingSlots) setUploadError(`Only ${remainingSlots} more visual ${remainingSlots === 1 ? "select" : "selects"} can be added.`);
    else setUploadError("");

    void Promise.all(selectedFiles.slice(0, remainingSlots).map(async (file) => ({
      id: crypto.randomUUID(),
      filename: file.name,
      cropPosition: "50% 50%",
      dataUrl: await readImageAsDataUrl(file),
    }))).then((images) => {
      setLookbookImages((existing) => [...existing, ...images]);
      setSelectedLookbookImageId((current) => current ?? images[0]?.id ?? null);
    }).catch((error: Error) => setUploadError(error.message));
    event.target.value = "";
  };

  const updateCropPosition = (cropPosition: string) => {
    if (!selectedLookbookImageId) return;
    setLookbookImages((images) => images.map((image) => image.id === selectedLookbookImageId ? { ...image, cropPosition } : image));
  };

  const removeLookbookImage = (imageId: string) => {
    setLookbookImages((images) => images.filter((image) => image.id !== imageId));
    setSelectedLookbookImageId((selected) => selected === imageId ? null : selected);
  };

  const moveLookbookImage = (direction: -1 | 1) => {
    if (!selectedLookbookImageId) return;
    setLookbookImages((images) => {
      const index = images.findIndex((image) => image.id === selectedLookbookImageId);
      const nextIndex = index + direction;
      if (index < 0 || nextIndex < 0 || nextIndex >= images.length) return images;
      const reordered = [...images];
      [reordered[index], reordered[nextIndex]] = [reordered[nextIndex], reordered[index]];
      return reordered;
    });
  };

  const visibleExistingLookbookAssets = existingLookbookAssets
    .filter((asset) => !existingAssetEdits.find((edit) => edit.id === asset.id)?.remove)
    .sort((left, right) => (existingAssetEdits.find((edit) => edit.id === left.id)?.sortOrder ?? left.sortOrder) - (existingAssetEdits.find((edit) => edit.id === right.id)?.sortOrder ?? right.sortOrder));

  const updateExistingAssetEdit = (id: number, patch: Partial<Omit<ExistingAssetEdit, "id">>) => {
    setExistingAssetEdits((edits) => edits.map((edit) => edit.id === id ? { ...edit, ...patch } : edit));
  };

  const moveExistingLookbookAsset = (direction: -1 | 1) => {
    if (!selectedExistingAssetId) return;
    const index = visibleExistingLookbookAssets.findIndex((asset) => asset.id === selectedExistingAssetId);
    const selected = visibleExistingLookbookAssets[index];
    const neighbour = visibleExistingLookbookAssets[index + direction];
    if (!selected || !neighbour) return;
    const selectedOrder = existingAssetEdits.find((edit) => edit.id === selected.id)?.sortOrder ?? selected.sortOrder;
    const neighbourOrder = existingAssetEdits.find((edit) => edit.id === neighbour.id)?.sortOrder ?? neighbour.sortOrder;
    updateExistingAssetEdit(selected.id, { sortOrder: neighbourOrder });
    updateExistingAssetEdit(neighbour.id, { sortOrder: selectedOrder });
  };

  const profileSubmit = trpc.profile.submit.useMutation({
    onSuccess: () => setLocationRoute("/dashboard"),
  });

  useEffect(() => {
    if (!isAuthenticated || !editor.data || formInitialized) return;
    const profile = editor.data.profile;
    const savedDraft = editor.data.draft ? JSON.parse(editor.data.draft.payload) as DraftPayload : null;
    const localDraft = !savedDraft ? (() => {
      try {
        const raw = localStorage.getItem(PRE_AUTH_DRAFT_KEY);
        return raw ? JSON.parse(raw) as DraftPayload : null;
      } catch {
        return null;
      }
    })() : null;
    const activeDraft = savedDraft ?? localDraft;
    if (profile) {
      setExistingLookbookAssets((editor.data.assets ?? []).map((asset) => ({ id: asset.id, imageUrl: asset.imageUrl, cropPosition: asset.cropPosition, sortOrder: asset.sortOrder })));
      setExistingAssetEdits((editor.data.assets ?? []).map((asset) => ({ id: asset.id, cropPosition: asset.cropPosition, sortOrder: asset.sortOrder, remove: false })));
      setPrimaryPortraitDataUrl(profile.primaryPortraitUrl ?? "");
      setPrimaryPortraitStorageKey(profile.primaryPortraitStorageKey ?? "");
    }
    if (activeDraft) {
      setStep(activeDraft.step ?? 0);
      setOnboardingPhase(activeDraft.onboardingPhase ?? "intake");
      setLookbookStep(activeDraft.lookbookStep ?? 0);
      setName(activeDraft.name ?? profile?.displayName ?? "");
      setLocation(activeDraft.location ?? profile?.location ?? "Perth, WA");
      setRole(activeDraft.role ?? profile?.practiceRole ?? "Creative / talent");
      setIntent(activeDraft.intent ?? (profile?.intentAreas ? JSON.parse(profile.intentAreas) : ["Model & talent", "Creative direction"]));
      setEnergy(activeDraft.energy ?? profile?.energy ?? "Quiet confidence");
      setProfileType(activeDraft.profileType ?? profile?.profileType ?? "Model");
      setProfileFocus(activeDraft.profileFocus ?? (profile?.focusAreas ? JSON.parse(profile.focusAreas) : ["Campaign & e-commerce", "Editorial"]));
      setHeight(activeDraft.height ?? profile?.height ?? "");
      setChestOrBust(activeDraft.chestOrBust ?? profile?.chestOrBust ?? "");
      setWaist(activeDraft.waist ?? profile?.waist ?? "");
      setHips(activeDraft.hips ?? profile?.hips ?? "");
      setShoeSize(activeDraft.shoeSize ?? profile?.shoeSize ?? "");
      setAvailability(activeDraft.availability ?? profile?.availability ?? "");
      setVisibility(activeDraft.visibility ?? profile?.visibility ?? "Curated introductions");
      if (activeDraft.primaryPortrait) {
        setPrimaryPortraitDataUrl(activeDraft.primaryPortrait.dataUrl ?? activeDraft.primaryPortrait.imageUrl ?? "");
        setPrimaryPortraitStorageKey(activeDraft.primaryPortrait.storageKey ?? "");
      }
      if (activeDraft.lookbookImages?.length) {
        setLookbookImages(activeDraft.lookbookImages.map((image, index) => ({ id: crypto.randomUUID(), filename: image.filename ?? `saved-select-${index + 1}`, dataUrl: image.dataUrl, storageKey: image.storageKey, imageUrl: image.imageUrl, cropPosition: image.cropPosition })));
      }
      setReplaceLookbook(activeDraft.replaceLookbook ?? false);
      if (activeDraft.existingAssetEdits?.length) setExistingAssetEdits(activeDraft.existingAssetEdits);
      if (localDraft) localStorage.removeItem(PRE_AUTH_DRAFT_KEY);
    } else if (profile) {
      setName(profile.displayName);
      setLocation(profile.location);
      setRole(profile.practiceRole ?? "Creative / talent");
      setIntent(profile.intentAreas ? JSON.parse(profile.intentAreas) : ["Model & talent", "Creative direction"]);
      setEnergy(profile.energy ?? "Quiet confidence");
      setProfileType(profile.profileType);
      setProfileFocus(profile.focusAreas ? JSON.parse(profile.focusAreas) : ["Campaign & e-commerce", "Editorial"]);
      setHeight(profile.height ?? "");
      setChestOrBust(profile.chestOrBust ?? "");
      setWaist(profile.waist ?? "");
      setHips(profile.hips ?? "");
      setShoeSize(profile.shoeSize ?? "");
      setAvailability(profile.availability ?? "");
      setVisibility(profile.visibility);
    }
    setFormInitialized(true);
  }, [editor.data, formInitialized, isAuthenticated]);

  const buildDraftPayload = (): DraftPayload => ({
    step, onboardingPhase, lookbookStep, name, location, role, intent, energy, profileType, profileFocus, height, chestOrBust, waist, hips, shoeSize, availability, visibility,
    replaceLookbook,
    existingAssetEdits,
  });

  const saveProgress = () => {
    if (!isAuthenticated) {
      localStorage.setItem(PRE_AUTH_DRAFT_KEY, JSON.stringify(buildDraftPayload()));
      startLogin();
      return;
    }
    const portrait = primaryPortraitDataUrl ? (primaryPortraitStorageKey ? { storageKey: primaryPortraitStorageKey, imageUrl: primaryPortraitDataUrl } : { dataUrl: primaryPortraitDataUrl }) : undefined;
    saveDraft.mutate({
      payload: JSON.stringify(buildDraftPayload()),
      primaryPortrait: portrait,
      lookbookImages: lookbookImages.map((image) => image.storageKey ? { storageKey: image.storageKey, imageUrl: image.imageUrl ?? image.dataUrl ?? "", cropPosition: image.cropPosition } : { dataUrl: image.dataUrl ?? "", cropPosition: image.cropPosition }),
      replaceLookbook,
      existingAssetEdits,
    });
  };

  const goNext = () => {
    if (onboardingPhase === "intake") {
      if (step < 4) {
        setStep((value) => (value + 1) as Step);
        return;
      }
      setOnboardingPhase("lookbook");
      setLookbookStep(0);
      return;
    }
    if (lookbookStep < 3) {
      setLookbookStep((value) => (value + 1) as LookbookStep);
      return;
    }
    if (!isAuthenticated) {
      startLogin();
      return;
    }
    profileSubmit.mutate({
      displayName: name,
      practiceRole: role,
      intentAreas: intent,
      energy,
      profileType,
      location,
      height,
      chestOrBust,
      waist,
      hips,
      shoeSize,
      availability,
      focusAreas: profileFocus,
      visibility,
      primaryPortrait: primaryPortraitStorageKey ? { storageKey: primaryPortraitStorageKey, imageUrl: primaryPortraitDataUrl } : primaryPortraitDataUrl.startsWith("data:image/") ? { dataUrl: primaryPortraitDataUrl } : undefined,
      lookbookImages: lookbookImages.map((image) => image.storageKey ? { storageKey: image.storageKey, imageUrl: image.imageUrl ?? image.dataUrl ?? "", cropPosition: image.cropPosition } : { dataUrl: image.dataUrl ?? "", cropPosition: image.cropPosition }),
      assetMode: replaceLookbook || !existingLookbookAssets.length ? "replace" : "preserve",
      existingAssetEdits,
      submitForReview: true,
    });
  };

  const goBack = () => {
    if (onboardingPhase === "lookbook") {
      if (lookbookStep > 0) {
        setLookbookStep((value) => (value - 1) as LookbookStep);
        return;
      }
      setOnboardingPhase("intake");
      setStep(4);
      return;
    }
    setStep((value) => Math.max(value - 1, 0) as Step);
  };

  const remainingVisualCount = replaceLookbook ? lookbookImages.length : visibleExistingLookbookAssets.length;
  const needsNewLookbookImage = profileType !== "Industry partner" && remainingVisualCount < 1;
  const canContinue = onboardingPhase === "intake"
    ? (step === 0 && name.trim().length > 1) || (step === 1 && role.length > 0) || (step === 2 && intent.length > 0) || step === 3 || step === 4
    : (lookbookStep === 0 && profileType.length > 0 && profileFocus.length > 0) || (lookbookStep === 1 && height.length > 1 && availability.trim().length > 3) || (lookbookStep === 2 && (!needsNewLookbookImage || lookbookImages.length > 0)) || (lookbookStep === 3 && visibility.length > 0);

  const nextLabel = onboardingPhase === "intake"
    ? (step === 4 ? "Build look book" : "Continue")
    : (lookbookStep === 3 ? (isAuthenticated ? "Send for review" : "Sign in to send") : "Continue");

  const activeImage = primaryPortraitDataUrl || "/manus-storage/fleshsesh-lips-icon_217b91c5.png";

  if (showLoading) {
    return (
      <main className={`academy-loader ${loadingExiting ? "is-exiting" : ""} ${videoActivated ? "has-motion" : "is-static"}`} aria-label="Loading fleshsesh" onPointerDownCapture={() => setVideoActivated(true)} onKeyDownCapture={() => setVideoActivated(true)}>
        {videoActivated && <video className="academy-loader-video" autoPlay muted loop playsInline preload="metadata" aria-hidden="true"><source media="(max-width: 760px)" src={mobileIntroVideo} type="video/mp4" /><source src={introVideo} type="video/mp4" /></video>}
        <div className="academy-loader-video-wash" aria-hidden="true" />
        <div className="academy-loader-grain" aria-hidden="true" />
        <div className="academy-loader-orbit orbit-one" aria-hidden="true" />
        <div className="academy-loader-orbit orbit-two" aria-hidden="true" />
        <div className="academy-loader-video-signature" aria-hidden="true"><img src={brandLipsIcon} alt="" /></div>
        <motion.div className="academy-loader-content" initial={{ opacity: 0, y: 18, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}>
          <span className="academy-loader-kicker">private entry / 01</span>
          <div className="academy-loader-brand" aria-label="fleshsesh">
            <img className="academy-loader-logo" src={brandWordmark} alt="fleshsesh" />
          </div>
          <span className="academy-loader-rule" aria-hidden="true" />
          <p>{videoActivated ? "Preparing your private profile experience" : "Private profile experience"}</p>
        </motion.div>
        <div className="academy-loader-footer"><span>01 / 01</span><span>creator intake</span><button type="button" onClick={enterExperience}>Enter</button></div>
      </main>
    );
  }

  if (complete) {
    return (
      <main className="onboarding-shell completion-shell">
        <div className="texture-grid" />
        <section className="completion-card">
          <div className="completion-brand"><img className="platform-logo platform-logo-completion" src={brandWordmark} alt="fleshsesh" /><img className="completion-icon" src={brandLipsIcon} alt="" aria-hidden="true" /><span>fleshsesh / profile submitted</span></div>
          <div className="completion-orbit"><Check size={28} strokeWidth={2.5} /></div>
          <p className="eyebrow">Profile received</p>
          <h1>Thanks for<br /><em>showing up.</em></h1>
          <p className="completion-copy">Your talent profile and look book are now with the review team. We will contact you when there is a relevant next step.</p>
          <div className="next-callout">
            <CalendarDays size={18} />
            <span><strong>Next touchpoint</strong><small>Confirmation arrives within 2–3 working days.</small></span>
          </div>
          <button type="button" className="ink-button" onClick={() => setComplete(false)}>Review my details <ArrowLeft size={17} /></button>
        </section>
      </main>
    );
  }

  return (
    <main className="onboarding-shell">
      <div className="ambient-media" aria-hidden="true">
        <img className="ambient-shot shot-male" src="/manus-storage/fleshsesh-ambient-collective_1d600064.jpeg" alt="" />
        <img className="ambient-shot shot-female" src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1800&q=88" alt="" />
        <img className="ambient-shot shot-duo" src="/manus-storage/fleshsesh-ambient-duo_0deb64f8.jpg" alt="" />
        <span className="ambient-wash" />
        <div className="media-proof"><span>fleshsesh files</span><b>01 / 03</b></div>
      </div>
      <div className="ink-overlay" aria-hidden="true" />
      <div className="texture-grid" aria-hidden="true" />

      <aside className="chapter-rail" aria-label="Application progress">
        <div className="rail-top">
          <a href={fleshseshWebsiteUrl} target="_blank" rel="noreferrer" aria-label="Visit fleshsesh.com">
            <img className="platform-logo platform-logo-rail" src={brandWordmark} alt="fleshsesh" />
          </a>
        </div>
        <div className="rail-index">
          <span className="rail-current">0{currentStep + 1}</span>
          <span className="rail-total">/ 09</span>
        </div>
        <div className="rail-track"><motion.span animate={{ height: `${percent}%` }} transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1] }} /></div>
        <div className="rail-bottom"><span>creator<br />profile</span><span>2026</span></div>
      </aside>

      <header className="utility-bar">
        <div className="utility-copy"><span className="utility-dot" /> private application</div>
        <img className="utility-wordmark" src={brandWordmark} alt="fleshsesh" />
        <div className="utility-actions">
          <a className="quiet-link" href={fleshseshWebsiteUrl} target="_blank" rel="noreferrer"><ExternalLink size={15} /> fleshsesh.com</a>
          <button type="button" className="quiet-link" onClick={saveProgress} disabled={saveDraft.isPending}><ShieldCheck size={15} /> {saveDraft.isPending ? "saving draft" : "save draft"}</button>
        </div>
        <button type="button" className="utility-exit" onClick={saveProgress} aria-label="Save draft"><X size={18} /></button>
      </header>

      <section className="onboarding-stage">
        <div className="registration-mark reg-a">{onboardingPhase === "intake" ? "INTAKE" : "LOOK BOOK"} / {String(currentStep + 1).padStart(2, "0")}</div>
        <div className="registration-mark reg-b">PRIVATE / CONFIDENTIAL</div>

        <AnimatePresence mode="wait">
          <motion.div
            key={`${onboardingPhase}-${onboardingPhase === "intake" ? step : lookbookStep}`}
            className={`intake-card ${onboardingPhase === "lookbook" ? "lookbook-card-stage" : ""}`}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.24, ease: [0.23, 1, 0.32, 1] }}
          >
            <div className="card-header">
              <div>
                <p className="eyebrow">{onboardingPhase === "intake" ? steps[currentStep] : `Look book · ${["Direction", "Measurements & availability", "Visual selects", "Review setting"][lookbookStep]}`}</p>
                <span className="card-caption">{onboardingPhase === "intake" ? "Build the introduction people can place." : "Complete the practical profile and visual proof in one considered sequence."}</span>
              </div>
              <div className="orbital-number">0{currentStep + 1}</div>
            </div>

            {step === 0 && (
              <div className="step-content name-step">
                <h1>Before we meet,<br /><em>what should we call you?</em></h1>
                <p>Start with the name you want the right people to know.</p>
                <label className="editorial-input"><span>Your name</span><input autoFocus value={name} onChange={(event) => setName(event.target.value)} placeholder="Enter your name" /></label>
                <label className="editorial-input compact"><span>Base / location</span><span className="input-with-icon"><MapPin size={17} /><input value={location} onChange={(event) => setLocation(event.target.value)} /></span></label>
              </div>
            )}

            {step === 1 && (
              <div className="step-content role-step">
                <h1>Where does your<br /><em>point of view</em> begin?</h1>
                <p>Choose the lane closest to your current practice. You can keep adding layers later.</p>
                <div className="stacked-choices">
                  {["Creative / talent", "Artist / maker", "Industry / partner"].map((item) => <ChoiceCard key={item} label={item} active={role === item} onClick={() => setRole(item)} />)}
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="step-content intent-step">
                <h1>What are you here<br /><em>to make possible?</em></h1>
                <p>Select the conversations, rooms, and collaborations that feel relevant now.</p>
                <div className="intent-grid">
                  {interestOptions.map((item) => <ChoiceCard key={item} label={item} active={intent.includes(item)} onClick={() => toggleIntent(item)} />)}
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="step-content energy-step">
                <h1>Choose the energy<br /><em>you bring in.</em></h1>
                <p>There is no right answer. This helps us make introductions that have a pulse.</p>
                <div className="stacked-choices energy-choices">
                  {energyOptions.map((item) => <ChoiceCard key={item.label} label={item.label} note={item.note} active={energy === item.label} onClick={() => setEnergy(item.label)} />)}
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="step-content photo-step">
                <h1>Give us a<br /><em>first impression.</em></h1>
                <p>A clear portrait or a visual you feel close to. It is stored with your profile when you send for review.</p>
                <div className="image-uploader">
                  <img src={activeImage} alt="Selected profile preview" />
                  <label htmlFor="profile-image" className="image-upload-button"><ImagePlus size={18} /> {primaryPortraitDataUrl ? "Change portrait" : "Add portrait"}</label>
                  <input id="profile-image" type="file" accept="image/jpeg,image/png,image/webp" onChange={handleImage} />
                </div>
                <div className="finish-detail"><HeartHandshake size={18} /><span><strong>Kept on your terms.</strong><small>Your profile stays private until you choose to be discovered.</small></span></div>
              </div>
            )}

            {onboardingPhase === "lookbook" && lookbookStep === 0 && (
              <div className="step-content lookbook-profile-step">
                <h1>Shape the profile<br /><em>people will remember.</em></h1>
                <p>Set the direction for how your talent, work and point of view are introduced to the right rooms.</p>
                <div className="profile-type-grid">
                  {profileTypes.map((item) => <ChoiceCard key={item.label} label={item.label} note={item.note} active={profileType === item.label} onClick={() => setProfileType(item.label)} />)}
                </div>
                <div className="lookbook-section-label"><UserRound size={14} /> What should lead the look book?</div>
                <div className="profile-focus-tags">
                  {profileFocusOptions.map((item) => <button key={item} type="button" className={profileFocus.includes(item) ? "is-selected" : ""} onClick={() => toggleProfileFocus(item)} aria-pressed={profileFocus.includes(item)}>{item}</button>)}
                </div>
              </div>
            )}

            {onboardingPhase === "lookbook" && lookbookStep === 1 && (
              <div className="step-content measurements-step">
                <h1>Let the details<br /><em>hold their own.</em></h1>
                <p>Share the practical information that helps casting, creative and industry teams understand your current profile.</p>
                <div className="measurement-grid">
                  <label className="editorial-input"><span>Height *</span><input value={height} onChange={(event) => setHeight(event.target.value)} placeholder="e.g. 178 cm / 5 ft 10 in" /></label>
                  <label className="editorial-input"><span>Chest / bust</span><input value={chestOrBust} onChange={(event) => setChestOrBust(event.target.value)} placeholder="Optional" /></label>
                  <label className="editorial-input"><span>Waist</span><input value={waist} onChange={(event) => setWaist(event.target.value)} placeholder="Optional" /></label>
                  <label className="editorial-input"><span>Hips</span><input value={hips} onChange={(event) => setHips(event.target.value)} placeholder="Optional" /></label>
                  <label className="editorial-input"><span>Shoe size</span><input value={shoeSize} onChange={(event) => setShoeSize(event.target.value)} placeholder="Optional" /></label>
                  <label className="editorial-input"><span>Base / location</span><input value={location} onChange={(event) => setLocation(event.target.value)} placeholder="City, region" /></label>
                </div>
                <label className="availability-field"><span>General availability *</span><textarea value={availability} onChange={(event) => setAvailability(event.target.value)} placeholder="For example: Perth-based, available for local work with two weeks’ notice for interstate travel." /></label>
              </div>
            )}

            {onboardingPhase === "lookbook" && lookbookStep === 2 && (
              <div className="step-content lookbook-upload-step">
                <h1>Build a look book<br /><em>with a point of view.</em></h1>
                <p>{needsNewLookbookImage ? "Add at least one considered image, up to four. " : "Your existing visual selects are protected unless you choose to replace them. "}Each new file is checked locally before upload: JPEG, PNG or WebP, up to 10 MB.</p>
                {existingLookbookAssets.length > 0 && !replaceLookbook && <div className="existing-lookbook-note"><ShieldCheck size={16} /><span><strong>{visibleExistingLookbookAssets.length} visual {visibleExistingLookbookAssets.length === 1 ? "select is" : "selects are"} protected.</strong><small>Adjust a saved select below, or replace the full look book deliberately.</small></span><button type="button" onClick={() => { setReplaceLookbook(true); setSelectedExistingAssetId(null); }}>Replace selects</button></div>}
                {replaceLookbook && existingLookbookAssets.length > 0 && <button type="button" className="quiet-link restore-lookbook" onClick={() => { setReplaceLookbook(false); setLookbookImages([]); }}>Keep existing selects</button>}
                {(replaceLookbook || !existingLookbookAssets.length) && <label className="lookbook-upload-zone">
                  <ImagePlus size={22} />
                  <span><strong>Add visual selects</strong><small>JPG, PNG or WebP · up to four images</small></span>
                  <input type="file" accept="image/*" multiple onChange={handleLookbookImages} />
                </label>}
                {uploadError && <p className="upload-error" role="alert">{uploadError}</p>}
                <div className="lookbook-grid" aria-label="Look book image slots">
                  {!replaceLookbook && visibleExistingLookbookAssets.map((asset, index) => <button type="button" className={`lookbook-tile has-image is-protected ${selectedExistingAssetId === asset.id ? "is-selected" : ""}`} key={`existing-${asset.id}`} onClick={() => { setSelectedExistingAssetId(asset.id); setSelectedLookbookImageId(null); }}><img src={asset.imageUrl} alt={`Saved look book selection ${index + 1}`} style={{ objectPosition: existingAssetEdits.find((edit) => edit.id === asset.id)?.cropPosition ?? asset.cropPosition }} /><span>{String(index + 1).padStart(2, "0")}</span><small>Adjust saved select</small></button>)}
                {Array.from({ length: Math.max(0, 4 - (!replaceLookbook ? existingLookbookAssets.length : 0)) }).map((_, index) => lookbookImages[index] ? (
                    <button type="button" className={`lookbook-tile has-image ${selectedLookbookImageId === lookbookImages[index]?.id ? "is-selected" : ""}`} key={`lookbook-${index}`} onClick={() => setSelectedLookbookImageId(lookbookImages[index]?.id ?? null)}><img src={lookbookImages[index]?.imageUrl ?? lookbookImages[index]?.dataUrl ?? ""} alt={`Look book selection ${index + 1}`} style={{ objectPosition: lookbookImages[index]?.cropPosition }} /><span>{String(index + 1).padStart(2, "0")}</span><small>Adjust crop</small></button>
                  ) : (
                    <div className="lookbook-tile" key={`lookbook-${index}`}><span>{String(index + 1).padStart(2, "0")}</span><small>{index === 0 ? "Portrait" : index === 1 ? "Full look" : index === 2 ? "Detail" : "Context"}</small></div>
                  ))}
                </div>
                {selectedLookbookImageId && <div className="crop-controls"><div><span>Simple crop & order</span><small>Choose the frame position and the order your new visual selects should appear.</small></div><div className="crop-actions"><button type="button" onClick={() => moveLookbookImage(-1)}>Earlier</button><button type="button" onClick={() => moveLookbookImage(1)}>Later</button>{cropOptions.map((option) => <button type="button" key={option.value} className={lookbookImages.find((image) => image.id === selectedLookbookImageId)?.cropPosition === option.value ? "is-active" : ""} onClick={() => updateCropPosition(option.value)}>{option.label}</button>)}<button type="button" className="crop-remove" onClick={() => removeLookbookImage(selectedLookbookImageId)}>Remove</button></div></div>}
                {selectedExistingAssetId && !replaceLookbook && <div className="crop-controls"><div><span>Saved select controls</span><small>These adjustments are kept with your existing look book and do not create a replacement upload.</small></div><div className="crop-actions"><button type="button" onClick={() => moveExistingLookbookAsset(-1)}>Earlier</button><button type="button" onClick={() => moveExistingLookbookAsset(1)}>Later</button>{cropOptions.map((option) => <button type="button" key={option.value} className={(existingAssetEdits.find((edit) => edit.id === selectedExistingAssetId)?.cropPosition ?? existingLookbookAssets.find((asset) => asset.id === selectedExistingAssetId)?.cropPosition) === option.value ? "is-active" : ""} onClick={() => updateExistingAssetEdit(selectedExistingAssetId, { cropPosition: option.value })}>{option.label}</button>)}<button type="button" className="crop-remove" onClick={() => { updateExistingAssetEdit(selectedExistingAssetId, { remove: true }); setSelectedExistingAssetId(null); }}>Remove</button></div></div>}
              </div>
            )}

            {onboardingPhase === "lookbook" && lookbookStep === 3 && (
              <div className="step-content lookbook-review-step">
                <h1>Set the room<br /><em>you want to enter.</em></h1>
                <p>Choose how the completed profile should be held. You can adjust this later when your practice or availability changes.</p>
                <div className="visibility-options" role="radiogroup" aria-label="Profile visibility">
                  {visibilityOptions.map((item) => <button key={item.label} type="button" className={visibility === item.label ? "is-active" : ""} onClick={() => setVisibility(item.label)} role="radio" aria-checked={visibility === item.label}><span className="visibility-marker">{visibility === item.label && <Check size={13} strokeWidth={3} />}</span><span><strong>{item.label}</strong><small>{item.note}</small></span></button>)}
                </div>
                <div className="lookbook-review-note"><Sparkles size={17} /><span><strong>What happens next</strong><small>Your profile enters a considered review queue. We only make introductions when the work, person and opportunity line up.</small></span></div>
              </div>
            )}

            <div className="card-footer">
              <button type="button" className="back-button" disabled={onboardingPhase === "intake" && step === 0} onClick={goBack}><ArrowLeft size={17} /> Back</button>
              <div className="footer-progress">{Array.from({ length: totalSteps }).map((_, index) => <span key={index} className={index <= currentStep ? "is-done" : ""} />)}</div>
              <button type="button" className="next-button" disabled={!canContinue || profileSubmit.isPending} onClick={goNext}>{profileSubmit.isPending ? "Sending profile" : nextLabel} <ArrowRight size={17} /></button>
            </div>
            {draftSavedAt && <p className="draft-status" aria-live="polite">Draft saved at {draftSavedAt.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}.</p>}
            {profileSubmit.error && <p className="submission-error" role="alert">{profileSubmit.error.message}</p>}
          </motion.div>
        </AnimatePresence>

        <div className="side-signal">
          <Compass size={17} /><span>intentional<br />connection</span>
        </div>
      </section>

      <footer className="ambient-footer"><span><Clock3 size={14} /> Estimated time: 3 min</span><span><CircleHelp size={14} /> Need a hand?</span><span><Sparkles size={14} /> Private application</span></footer>
    </main>
  );
}
