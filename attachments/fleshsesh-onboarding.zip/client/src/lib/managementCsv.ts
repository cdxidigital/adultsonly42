export type ManagementCsvRow = {
  profile: {
    displayName: string;
    profileType: string;
    location: string;
    reviewStatus: string;
    submittedAt: Date | string;
  };
  user: { email: string | null } | null;
};

const statusLabels: Record<string, string> = {
  pending_review: "Pending review",
  in_review: "In review",
  profile_ready: "Profile ready",
  changes_requested: "Update requested",
};

function formatDate(value: Date | string) {
  return new Date(value).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

export function buildManagementCsv(rows: ManagementCsvRow[]) {
  const escape = (value: string) => `"${value.replaceAll('"', '""').replaceAll(String.fromCharCode(13), " ").replaceAll(String.fromCharCode(10), " ")}"`;
  const header = ["Name", "Profile type", "Location", "Email", "Status", "Submitted"];
  const lines = rows.map(({ profile, user }) => [
    profile.displayName,
    profile.profileType,
    profile.location,
    user?.email ?? "",
    statusLabels[profile.reviewStatus] ?? profile.reviewStatus,
    formatDate(profile.submittedAt),
  ].map(escape).join(","));
  return [header.map(escape).join(","), ...lines].join("\n");
}
