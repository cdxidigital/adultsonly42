import { index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

const reviewStatuses = ["pending_review", "in_review", "profile_ready", "changes_requested"] as const;

export const talentProfiles = mysqlTable("talentProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  displayName: varchar("displayName", { length: 160 }).notNull(),
  practiceRole: varchar("practiceRole", { length: 120 }),
  intentAreas: text("intentAreas"),
  energy: varchar("energy", { length: 120 }),
  profileType: varchar("profileType", { length: 80 }).notNull(),
  location: varchar("location", { length: 180 }).notNull(),
  height: varchar("height", { length: 32 }),
  chestOrBust: varchar("chestOrBust", { length: 32 }),
  waist: varchar("waist", { length: 32 }),
  hips: varchar("hips", { length: 32 }),
  shoeSize: varchar("shoeSize", { length: 32 }),
  availability: text("availability"),
  focusAreas: text("focusAreas"),
  visibility: varchar("visibility", { length: 80 }).notNull(),
  primaryPortraitStorageKey: varchar("primaryPortraitStorageKey", { length: 512 }),
  primaryPortraitUrl: varchar("primaryPortraitUrl", { length: 512 }),
  reviewStatus: mysqlEnum("reviewStatus", reviewStatuses).default("pending_review").notNull(),
  assignedReviewerId: int("assignedReviewerId"),
  profileVersion: int("profileVersion").default(1).notNull(),
  submittedAt: timestamp("submittedAt").defaultNow().notNull(),
  reviewUpdatedAt: timestamp("reviewUpdatedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdUnique: uniqueIndex("talentProfiles_userId_unique").on(table.userId),
  reviewQueueIndex: index("talentProfiles_reviewStatus_submittedAt_idx").on(table.reviewStatus, table.submittedAt),
  reviewerQueueIndex: index("talentProfiles_assignedReviewerId_reviewStatus_idx").on(table.assignedReviewerId, table.reviewStatus),
}));

export const lookbookAssets = mysqlTable("lookbookAssets", {
  id: int("id").autoincrement().primaryKey(),
  profileId: int("profileId").notNull(),
  storageKey: varchar("storageKey", { length: 512 }).notNull(),
  imageUrl: varchar("imageUrl", { length: 512 }).notNull(),
  cropPosition: varchar("cropPosition", { length: 32 }).notNull().default("50% 50%"),
  sortOrder: int("sortOrder").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  profileSortIndex: index("lookbookAssets_profileId_sortOrder_idx").on(table.profileId, table.sortOrder),
}));

export const profileReviewUpdates = mysqlTable("profileReviewUpdates", {
  id: int("id").autoincrement().primaryKey(),
  profileId: int("profileId").notNull(),
  status: mysqlEnum("status", reviewStatuses).notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  profileCreatedIndex: index("profileReviewUpdates_profileId_createdAt_idx").on(table.profileId, table.createdAt),
}));

export const profileDrafts = mysqlTable("profileDrafts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  payload: text("payload").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdUnique: uniqueIndex("profileDrafts_userId_unique").on(table.userId),
}));

export const profileInternalNotes = mysqlTable("profileInternalNotes", {
  id: int("id").autoincrement().primaryKey(),
  profileId: int("profileId").notNull(),
  authorUserId: int("authorUserId").notNull(),
  note: text("note").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  profileCreatedIndex: index("profileInternalNotes_profileId_createdAt_idx").on(table.profileId, table.createdAt),
}));

export const profileAuditEvents = mysqlTable("profileAuditEvents", {
  id: int("id").autoincrement().primaryKey(),
  profileId: int("profileId").notNull(),
  actorUserId: int("actorUserId"),
  eventType: varchar("eventType", { length: 80 }).notNull(),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  profileCreatedIndex: index("profileAuditEvents_profileId_createdAt_idx").on(table.profileId, table.createdAt),
}));

const notificationStatuses = ["pending", "sent", "failed"] as const;

export const notificationEvents = mysqlTable("notificationEvents", {
  id: int("id").autoincrement().primaryKey(),
  profileId: int("profileId"),
  eventType: varchar("eventType", { length: 80 }).notNull(),
  recipient: varchar("recipient", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  deliveryStatus: mysqlEnum("deliveryStatus", notificationStatuses).default("pending").notNull(),
  providerMessageId: varchar("providerMessageId", { length: 255 }),
  errorDetail: text("errorDetail"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  deliveredAt: timestamp("deliveredAt"),
}, (table) => ({
  profileCreatedIndex: index("notificationEvents_profileId_createdAt_idx").on(table.profileId, table.createdAt),
  deliveryIndex: index("notificationEvents_deliveryStatus_createdAt_idx").on(table.deliveryStatus, table.createdAt),
}));

export type TalentProfile = typeof talentProfiles.$inferSelect;
export type InsertTalentProfile = typeof talentProfiles.$inferInsert;
export type LookbookAsset = typeof lookbookAssets.$inferSelect;
export type ProfileReviewUpdate = typeof profileReviewUpdates.$inferSelect;
export type ProfileDraft = typeof profileDrafts.$inferSelect;
export type ProfileInternalNote = typeof profileInternalNotes.$inferSelect;
export type ProfileAuditEvent = typeof profileAuditEvents.$inferSelect;
export type NotificationEvent = typeof notificationEvents.$inferSelect;
