CREATE TABLE `notificationEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int,
	`eventType` varchar(80) NOT NULL,
	`recipient` varchar(320) NOT NULL,
	`subject` varchar(255) NOT NULL,
	`deliveryStatus` enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
	`providerMessageId` varchar(255),
	`errorDetail` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`deliveredAt` timestamp,
	CONSTRAINT `notificationEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `profileAuditEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int NOT NULL,
	`actorUserId` int,
	`eventType` varchar(80) NOT NULL,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `profileAuditEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `profileDrafts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`payload` text NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `profileDrafts_id` PRIMARY KEY(`id`),
	CONSTRAINT `profileDrafts_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `profileInternalNotes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int NOT NULL,
	`authorUserId` int NOT NULL,
	`note` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `profileInternalNotes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `talentProfiles` ADD `practiceRole` varchar(120);--> statement-breakpoint
ALTER TABLE `talentProfiles` ADD `intentAreas` text;--> statement-breakpoint
ALTER TABLE `talentProfiles` ADD `energy` varchar(120);--> statement-breakpoint
ALTER TABLE `talentProfiles` ADD `primaryPortraitStorageKey` varchar(512);--> statement-breakpoint
ALTER TABLE `talentProfiles` ADD `primaryPortraitUrl` varchar(512);--> statement-breakpoint
ALTER TABLE `talentProfiles` ADD `assignedReviewerId` int;--> statement-breakpoint
ALTER TABLE `talentProfiles` ADD `profileVersion` int DEFAULT 1 NOT NULL;--> statement-breakpoint
CREATE INDEX `notificationEvents_profileId_createdAt_idx` ON `notificationEvents` (`profileId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `notificationEvents_deliveryStatus_createdAt_idx` ON `notificationEvents` (`deliveryStatus`,`createdAt`);--> statement-breakpoint
CREATE INDEX `profileAuditEvents_profileId_createdAt_idx` ON `profileAuditEvents` (`profileId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `profileInternalNotes_profileId_createdAt_idx` ON `profileInternalNotes` (`profileId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `talentProfiles_reviewStatus_submittedAt_idx` ON `talentProfiles` (`reviewStatus`,`submittedAt`);--> statement-breakpoint
CREATE INDEX `talentProfiles_assignedReviewerId_reviewStatus_idx` ON `talentProfiles` (`assignedReviewerId`,`reviewStatus`);