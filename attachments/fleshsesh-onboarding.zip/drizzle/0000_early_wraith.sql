CREATE TABLE `lookbookAssets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`imageUrl` varchar(512) NOT NULL,
	`cropPosition` varchar(32) NOT NULL DEFAULT '50% 50%',
	`sortOrder` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lookbookAssets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `profileReviewUpdates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`profileId` int NOT NULL,
	`status` enum('pending_review','in_review','profile_ready','changes_requested') NOT NULL,
	`title` varchar(160) NOT NULL,
	`message` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `profileReviewUpdates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `talentProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`displayName` varchar(160) NOT NULL,
	`profileType` varchar(80) NOT NULL,
	`location` varchar(180) NOT NULL,
	`height` varchar(32),
	`chestOrBust` varchar(32),
	`waist` varchar(32),
	`hips` varchar(32),
	`shoeSize` varchar(32),
	`availability` text,
	`focusAreas` text,
	`visibility` varchar(80) NOT NULL,
	`reviewStatus` enum('pending_review','in_review','profile_ready','changes_requested') NOT NULL DEFAULT 'pending_review',
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	`reviewUpdatedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `talentProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `talentProfiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE INDEX `lookbookAssets_profileId_sortOrder_idx` ON `lookbookAssets` (`profileId`,`sortOrder`);--> statement-breakpoint
CREATE INDEX `profileReviewUpdates_profileId_createdAt_idx` ON `profileReviewUpdates` (`profileId`,`createdAt`);