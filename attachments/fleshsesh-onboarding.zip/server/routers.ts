import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { addProfileInternalNote, applyExistingLookbookAssetEdits, assignProfileReviewer, clearProfileDraft, createNotificationEvent, getManagementProfile, getManagementProfiles, getProfileEditorData, getTalentProfileDashboard, listManagementReviewers, resolveNotificationEvent, saveProfileDraft, saveTalentProfile, updateTalentProfileReviewStatus } from "./db";
import { buildProfileSubmittedNotification, buildReviewUpdatedNotification, ONBOARDING_NOTIFICATION_RECIPIENT, sendOnboardingNotification } from "./onboardingNotifications";
import { storagePut } from "./storage";

export const MAX_LOOKBOOK_FILE_BYTES = 10 * 1024 * 1024;
const dataUrlSchema = z.string().regex(/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/, "Use a JPEG, PNG, or WebP image.");
const reviewStatusSchema = z.enum(["pending_review", "in_review", "profile_ready", "changes_requested"]);
const cropPositionSchema = z.string().regex(/^\d{1,3}% \d{1,3}%$/);
const storedDraftAssetSchema = z.object({ storageKey: z.string().min(1).max(512), imageUrl: z.string().min(1).max(512), cropPosition: cropPositionSchema });
const incomingAssetSchema = z.union([z.object({ dataUrl: dataUrlSchema, cropPosition: cropPositionSchema }), storedDraftAssetSchema]);
const incomingPortraitSchema = z.union([z.object({ dataUrl: dataUrlSchema }), storedDraftAssetSchema.pick({ storageKey: true, imageUrl: true })]);
const existingAssetEditSchema = z.object({ id: z.number().int().positive(), cropPosition: cropPositionSchema, sortOrder: z.number().int().positive(), remove: z.boolean().default(false) });

const profilePayloadSchema = z.object({
  displayName: z.string().trim().min(2).max(160),
  practiceRole: z.string().trim().max(120).optional(),
  intentAreas: z.array(z.string().trim().min(1).max(80)).max(8).default([]),
  energy: z.string().trim().max(120).optional(),
  profileType: z.string().trim().min(2).max(80),
  location: z.string().trim().min(2).max(180),
  height: z.string().trim().max(32).optional(),
  chestOrBust: z.string().trim().max(32).optional(),
  waist: z.string().trim().max(32).optional(),
  hips: z.string().trim().max(32).optional(),
  shoeSize: z.string().trim().max(32).optional(),
  availability: z.string().trim().max(1200).optional(),
  focusAreas: z.array(z.string().trim().min(1).max(80)).min(1).max(8),
  visibility: z.string().trim().min(2).max(80),
  primaryPortrait: incomingPortraitSchema.optional(),
  lookbookImages: z.array(incomingAssetSchema).max(4),
  assetMode: z.enum(["preserve", "replace"]).default("replace"),
  existingAssetEdits: z.array(existingAssetEditSchema).max(4).default([]),
  submitForReview: z.boolean().default(true),
}).superRefine((value, ctx) => {
  if (value.profileType !== "Industry partner" && value.submitForReview && value.lookbookImages.length < 1 && value.assetMode === "replace") {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["lookbookImages"], message: "Add at least one visual select before sending a talent profile for review." });
  }
});

const draftInputSchema = z.object({
  payload: z.string().min(2).max(20000),
  primaryPortrait: incomingPortraitSchema.optional(),
  lookbookImages: z.array(incomingAssetSchema).max(4).default([]),
  replaceLookbook: z.boolean().default(false),
  existingAssetEdits: z.array(existingAssetEditSchema).max(4).default([]),
});

export function decodeLookbookImage(dataUrl: string) {
  const match = /^data:(image\/(jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!match) throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid image data." });
  const [, mimeType, , payload] = match;
  const bytes = Buffer.from(payload, "base64");
  if (bytes.length > MAX_LOOKBOOK_FILE_BYTES) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Each image must be 10 MB or smaller." });
  const extension = mimeType === "image/jpeg" ? "jpg" : mimeType.split("/")[1];
  return { bytes, mimeType, extension };
}

function assertOwnedDraftAsset(userId: number, asset: { storageKey: string; imageUrl: string }) {
  if (!asset.storageKey.startsWith(`talent-profiles/${userId}/drafts/`) || !asset.imageUrl.startsWith("/manus-storage/")) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Draft asset is not available for this profile." });
  }
}

async function resolveIncomingAsset(userId: number, asset: z.infer<typeof incomingAssetSchema>, index: number, destination: "drafts" | "lookbook") {
  if ("storageKey" in asset) {
    assertOwnedDraftAsset(userId, asset);
    return { storageKey: asset.storageKey, imageUrl: asset.imageUrl, cropPosition: asset.cropPosition, sortOrder: index + 1 };
  }
  const { bytes, mimeType, extension } = decodeLookbookImage(asset.dataUrl);
  const uploaded = await storagePut(`talent-profiles/${userId}/${destination}/lookbook-${Date.now()}-${index + 1}.${extension}`, bytes, mimeType);
  return { storageKey: uploaded.key, imageUrl: uploaded.url, cropPosition: asset.cropPosition, sortOrder: index + 1 };
}

async function resolveIncomingPortrait(userId: number, portrait: z.infer<typeof incomingPortraitSchema> | undefined, destination: "drafts" | "portrait") {
  if (!portrait) return undefined;
  if ("storageKey" in portrait) {
    assertOwnedDraftAsset(userId, portrait);
    return { storageKey: portrait.storageKey, imageUrl: portrait.imageUrl };
  }
  const { bytes, mimeType, extension } = decodeLookbookImage(portrait.dataUrl);
  const uploaded = await storagePut(`talent-profiles/${userId}/${destination}/portrait-${Date.now()}.${extension}`, bytes, mimeType);
  return { storageKey: uploaded.key, imageUrl: uploaded.url };
}

async function trackManagementNotification(input: { profileId?: number; eventType: string; subject: string; text: string }) {
  const eventId = await createNotificationEvent({ profileId: input.profileId, eventType: input.eventType, recipient: ONBOARDING_NOTIFICATION_RECIPIENT, subject: input.subject });
  const delivery = await sendOnboardingNotification({ subject: input.subject, text: input.text });
  if (eventId) await resolveNotificationEvent({ id: eventId, success: delivery.success, providerMessageId: delivery.providerMessageId, errorDetail: delivery.errorDetail });
  return delivery;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(ctx.req), maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  profile: router({
    dashboard: protectedProcedure.query(({ ctx }) => getTalentProfileDashboard(ctx.user.id)),
    editor: protectedProcedure.query(({ ctx }) => getProfileEditorData(ctx.user.id)),
    saveDraft: protectedProcedure.input(draftInputSchema).mutation(async ({ ctx, input }) => {
      let payload: Record<string, unknown>;
      try {
        payload = JSON.parse(input.payload) as Record<string, unknown>;
      } catch {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Draft content is not valid." });
      }
      const [primaryPortrait, lookbookImages] = await Promise.all([
        resolveIncomingPortrait(ctx.user.id, input.primaryPortrait, "drafts"),
        Promise.all(input.lookbookImages.map((asset, index) => resolveIncomingAsset(ctx.user.id, asset, index, "drafts"))),
      ]);
      return saveProfileDraft(ctx.user.id, JSON.stringify({ ...payload, primaryPortrait, lookbookImages, replaceLookbook: input.replaceLookbook, existingAssetEdits: input.existingAssetEdits }));
    }),
    clearDraft: protectedProcedure.mutation(({ ctx }) => clearProfileDraft(ctx.user.id)),
    managementList: adminProcedure.input(z.object({ status: z.union([reviewStatusSchema, z.literal("all")]).default("all"), search: z.string().trim().max(160).default("") }).optional()).query(({ input }) => getManagementProfiles(input ?? {})),
    managementDetail: adminProcedure.input(z.object({ profileId: z.number().int().positive() })).query(({ input }) => getManagementProfile(input.profileId)),
    managementReviewers: adminProcedure.query(() => listManagementReviewers()),
    submit: protectedProcedure.input(profilePayloadSchema).mutation(async ({ ctx, input }) => {
      const uploadedAssets = await Promise.all(input.lookbookImages.map((asset, index) => resolveIncomingAsset(ctx.user.id, asset, index, "lookbook")));
      const primaryPortrait = await resolveIncomingPortrait(ctx.user.id, input.primaryPortrait, "portrait");
      if (input.profileType !== "Industry partner" && input.submitForReview && input.assetMode === "preserve") {
        const editor = await getProfileEditorData(ctx.user.id);
        const removedAssetIds = new Set(input.existingAssetEdits.filter((edit) => edit.remove).map((edit) => edit.id));
        const remainingSavedAssets = (editor.assets ?? []).filter((asset) => !removedAssetIds.has(asset.id));
        if (!remainingSavedAssets.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Keep at least one visual select before sending a talent profile for review." });
      }
      const dashboard = await saveTalentProfile(ctx.user.id, { ...input, lookbookAssets: uploadedAssets, primaryPortrait }, { submitForReview: input.submitForReview, assetMode: input.assetMode, actorUserId: ctx.user.id });
      if (dashboard?.profile && input.existingAssetEdits.length) await applyExistingLookbookAssetEdits({ profileId: dashboard.profile.id, actorUserId: ctx.user.id, edits: input.existingAssetEdits });
      await clearProfileDraft(ctx.user.id);
      if (input.submitForReview && dashboard?.profile) {
        const notification = buildProfileSubmittedNotification({ displayName: input.displayName, profileType: input.profileType, location: input.location, availability: input.availability, focusAreas: input.focusAreas, lookbookCount: uploadedAssets.length || dashboard.assets.length, isUpdate: dashboard.updates.some((update) => update.title === "Profile updated") });
        await trackManagementNotification({ profileId: dashboard.profile.id, eventType: dashboard.updates.some((update) => update.title === "Profile updated") ? "profile_updated" : "profile_submitted", ...notification });
      }
      return dashboard;
    }),
    updateStatus: adminProcedure.input(z.object({ profileId: z.number().int().positive(), status: reviewStatusSchema, title: z.string().trim().min(2).max(160), message: z.string().trim().min(2).max(2000) })).mutation(async ({ ctx, input }) => {
      const result = await updateTalentProfileReviewStatus({ ...input, actorUserId: ctx.user.id });
      const notification = buildReviewUpdatedNotification(input);
      await trackManagementNotification({ profileId: input.profileId, eventType: "member_review_update", ...notification });
      return result;
    }),
    addInternalNote: adminProcedure.input(z.object({ profileId: z.number().int().positive(), note: z.string().trim().min(2).max(4000) })).mutation(({ ctx, input }) => addProfileInternalNote({ ...input, authorUserId: ctx.user.id })),
    assignReviewer: adminProcedure.input(z.object({ profileId: z.number().int().positive(), reviewerId: z.number().int().positive().nullable() })).mutation(({ ctx, input }) => assignProfileReviewer({ ...input, actorUserId: ctx.user.id })),
  }),
});

export type AppRouter = typeof appRouter;
