import { TRPCError } from "@trpc/server";
import { describe, expect, it } from "vitest";
import { decodeLookbookImage } from "./routers";

describe("look-book image validation", () => {
  it("accepts a valid PNG data URL and preserves mime information", () => {
    const image = decodeLookbookImage("data:image/png;base64,aGVsbG8=");

    expect(image.mimeType).toBe("image/png");
    expect(image.extension).toBe("png");
    expect(image.bytes.toString()).toBe("hello");
  });

  it("rejects non-image data URLs", () => {
    expect(() => decodeLookbookImage("data:text/plain;base64,aGVsbG8=")).toThrow(TRPCError);
  });
});
