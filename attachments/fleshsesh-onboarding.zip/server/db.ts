import { and, desc, eq, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, lookbookAssets, notificationEvents, profileAuditEvents, profileDrafts, profileInternalNotes, profileReviewUpdates, talentProfiles, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export type SavedLookbookAsset = {
  storageKey: string;
  imageUrl: string;
  cropPosition: string;
  sortOrder: number;
};

export type TalentProfileInput = {
  displayName: string;
  practiceRole?: string;
  intentAreas?: string[];
  energy?: string;
  profileType: string;
  location: string;
  height?: string;
  chestOrBust?: string;
  waist?: string;
  hips?: string;
  shoeSize?: string;
  availability?: string;
  focusAreas: string[];
  visibility: string;
  lookbookAssets: SavedLookbookAsset[];
  primaryPortrait?: { storageKey: string; imageUrl: string };
};

export type ReviewStatus = "pending_review" | "in_review" | "profile_ready" | "changes_requested";
type DatabaseClient = NonNullable<Awaited<ReturnType<typeof getDb>>>;

export async function saveTalentProfile(userId: number, input: TalentProfileInput, options: { submitForReview: boolean; assetMode?: "preserve" | "replace"; actorUserId?: number } = { submitForReview: true }) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");

  const existing = await db.select().from(talentProfiles).where(eq(talentProfiles.userId, userId)).limit(1);
  const now = new Date();
  const isUpdate = Boolean(existing[0]);
  if (input.profileType !== "Industry partner" && options.submitForReview && !input.lookbookAssets.length && (!isUpdate || options.assetMode === "replace")) {
    throw new Error("Add at least one visual select before sending a talent profile for review.");
  }
  const shouldResetReview = !isUpdate || options.submitForReview;
  const values = {
    displayName: input.displayName,
    practiceRole: input.practiceRole || null,
    intentAreas: JSON.stringify(input.intentAreas ?? []),
    energy: input.energy || null,
    profileType: input.profileType,
    location: input.location,
    height: input.height || null,
    chestOrBust: input.chestOrBust || null,
    waist: input.waist || null,
    hips: input.hips || null,
    shoeSize: input.shoeSize || null,
    availability: input.availability || null,
    focusAreas: JSON.stringify(input.focusAreas),
    visibility: input.visibility,
    primaryPortraitStorageKey: input.primaryPortrait?.storageKey ?? existing[0]?.primaryPortraitStorageKey ?? null,
    primaryPortraitUrl: input.primaryPortrait?.imageUrl ?? existing[0]?.primaryPortraitUrl ?? null,
    ...(shouldResetReview ? { reviewStatus: "pending_review" as const, reviewUpdatedAt: now } : {}),
  };

  let profileId: number;
  if (existing[0]) {
    profileId = existing[0].id;
    await db.update(talentProfiles).set({ ...values, profileVersion: (existing[0].profileVersion ?? 1) + 1 }).where(eq(talentProfiles.id, profileId));
    if (options.assetMode === "replace") await db.delete(lookbookAssets).where(eq(lookbookAssets.profileId, profileId));
  } else {
    await db.insert(talentProfiles).values({ userId, ...values, reviewStatus: "pending_review", submittedAt: now });
    const created = await db.select({ id: talentProfiles.id }).from(talentProfiles).where(eq(talentProfiles.userId, userId)).limit(1);
    if (!created[0]) throw new Error("Profile could not be created");
    profileId = created[0].id;
  }

  if (input.lookbookAssets.length && (!isUpdate || options.assetMode === "replace")) {
    await db.insert(lookbookAssets).values(input.lookbookAssets.map((asset) => ({
      profileId,
      storageKey: asset.storageKey,
      imageUrl: asset.imageUrl,
      cropPosition: asset.cropPosition,
      sortOrder: asset.sortOrder,
    })));
  }

  await db.insert(profileAuditEvents).values({
    profileId,
    actorUserId: options.actorUserId ?? userId,
    eventType: isUpdate ? (options.submitForReview ? "profile_resubmitted" : "profile_saved") : "profile_submitted",
    metadata: JSON.stringify({ profileVersion: (existing[0]?.profileVersion ?? 0) + 1, assetMode: options.assetMode ?? "preserve" }),
    createdAt: now,
  });

  if (!isUpdate || options.submitForReview) {
    await db.insert(profileReviewUpdates).values({
      profileId,
      status: "pending_review",
      title: isUpdate ? "Profile updated" : "Profile submitted",
      message: isUpdate
        ? "Your updated profile has returned to the review queue."
        : "Your profile is now in the review queue. We will update you when there is a considered next step.",
      createdAt: now,
    });
  }

  return getTalentProfileDashboard(userId);
}

export async function getTalentProfileDashboard(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");

  const profile = await db.select().from(talentProfiles).where(eq(talentProfiles.userId, userId)).limit(1);
  if (!profile[0]) return null;

  const [assets, updates] = await Promise.all([
    db.select().from(lookbookAssets).where(eq(lookbookAssets.profileId, profile[0].id)).orderBy(lookbookAssets.sortOrder),
    db.select().from(profileReviewUpdates).where(eq(profileReviewUpdates.profileId, profile[0].id)).orderBy(desc(profileReviewUpdates.createdAt)),
  ]);

  return { profile: profile[0], assets, updates };
}

export async function getProfileEditorData(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  const [dashboard, draft] = await Promise.all([
    getTalentProfileDashboard(userId),
    db.select().from(profileDrafts).where(eq(profileDrafts.userId, userId)).limit(1),
  ]);
  return { ...dashboard, draft: draft[0] ?? null };
}

export async function saveProfileDraft(userId: number, payload: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  await db.insert(profileDrafts).values({ userId, payload }).onDuplicateKeyUpdate({ set: { payload, updatedAt: new Date() } });
  return { success: true as const };
}

export async function clearProfileDraft(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  await db.delete(profileDrafts).where(eq(profileDrafts.userId, userId));
  return { success: true as const };
}

export async function getManagementProfiles(filters: { status?: ReviewStatus | "all"; search?: string } = {}) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");

  const conditions = [];
  if (filters.status && filters.status !== "all") {
    conditions.push(eq(talentProfiles.reviewStatus, filters.status));
  }

  const search = filters.search?.trim();
  if (search) {
    const term = `%${search}%`;
    conditions.push(or(
      like(talentProfiles.displayName, term),
      like(talentProfiles.location, term),
      like(users.email, term),
    ));
  }

  const rows = await db
    .select()
    .from(talentProfiles)
    .leftJoin(users, eq(talentProfiles.userId, users.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(talentProfiles.submittedAt));

  return rows.map(({ talentProfiles: profile, users: user }) => ({
    profile,
    user: user ? { id: user.id, name: user.name, email: user.email } : null,
  }));
}

export async function getManagementProfile(profileId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");

  const row = await db
    .select()
    .from(talentProfiles)
    .leftJoin(users, eq(talentProfiles.userId, users.id))
    .where(eq(talentProfiles.id, profileId))
    .limit(1);
  if (!row[0]) return null;

  const [assets, updates, internalNotes, auditEvents, deliveryEvents] = await Promise.all([
    db.select().from(lookbookAssets).where(eq(lookbookAssets.profileId, profileId)).orderBy(lookbookAssets.sortOrder),
    db.select().from(profileReviewUpdates).where(eq(profileReviewUpdates.profileId, profileId)).orderBy(desc(profileReviewUpdates.createdAt)),
    db.select().from(profileInternalNotes).where(eq(profileInternalNotes.profileId, profileId)).orderBy(desc(profileInternalNotes.createdAt)),
    db.select().from(profileAuditEvents).where(eq(profileAuditEvents.profileId, profileId)).orderBy(desc(profileAuditEvents.createdAt)),
    db.select().from(notificationEvents).where(eq(notificationEvents.profileId, profileId)).orderBy(desc(notificationEvents.createdAt)),
  ]);

  return {
    profile: row[0].talentProfiles,
    user: row[0].users ? { id: row[0].users.id, name: row[0].users.name, email: row[0].users.email } : null,
    assets,
    updates,
    internalNotes,
    auditEvents,
    deliveryEvents,
  };
}

export async function updateTalentProfileReviewStatus(input: {
  profileId: number;
  status: ReviewStatus;
  title: string;
  message: string;
  actorUserId?: number;
}, dbOverride?: DatabaseClient) {
  const db = dbOverride ?? await getDb();
  if (!db) throw new Error("Database is unavailable");

  const existing = await db.select({ id: talentProfiles.id }).from(talentProfiles).where(eq(talentProfiles.id, input.profileId)).limit(1);
  if (!existing[0]) throw new Error("Profile not found");

  const now = new Date();
  await db.update(talentProfiles).set({ reviewStatus: input.status, reviewUpdatedAt: now }).where(eq(talentProfiles.id, input.profileId));
  await db.insert(profileReviewUpdates).values({
    profileId: input.profileId,
    status: input.status,
    title: input.title,
    message: input.message,
    createdAt: now,
  });
  await db.insert(profileAuditEvents).values({
    profileId: input.profileId,
    actorUserId: input.actorUserId ?? null,
    eventType: "member_update_published",
    metadata: JSON.stringify({ status: input.status, title: input.title }),
    createdAt: now,
  });

  return { success: true as const, reviewUpdatedAt: now };
}

export async function addProfileInternalNote(input: { profileId: number; authorUserId: number; note: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  const now = new Date();
  await db.insert(profileInternalNotes).values({ ...input, createdAt: now });
  await db.insert(profileAuditEvents).values({ profileId: input.profileId, actorUserId: input.authorUserId, eventType: "internal_note_added", metadata: null, createdAt: now });
  return { success: true as const };
}

export async function assignProfileReviewer(input: { profileId: number; reviewerId: number | null; actorUserId: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  const now = new Date();
  await db.update(talentProfiles).set({ assignedReviewerId: input.reviewerId, reviewUpdatedAt: now }).where(eq(talentProfiles.id, input.profileId));
  await db.insert(profileAuditEvents).values({ profileId: input.profileId, actorUserId: input.actorUserId, eventType: "reviewer_assignment_changed", metadata: JSON.stringify({ reviewerId: input.reviewerId }), createdAt: now });
  return { success: true as const };
}

export async function applyExistingLookbookAssetEdits(input: {
  profileId: number;
  actorUserId: number;
  edits: Array<{ id: number; cropPosition: string; sortOrder: number; remove: boolean }>;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  const assets = await db.select({ id: lookbookAssets.id }).from(lookbookAssets).where(eq(lookbookAssets.profileId, input.profileId));
  const ownedAssetIds = new Set(assets.map((asset) => asset.id));
  const validEdits = input.edits.filter((edit) => ownedAssetIds.has(edit.id));
  if (validEdits.length !== input.edits.length) throw new Error("A requested look-book asset is not part of this profile.");

  for (const edit of validEdits) {
    if (edit.remove) {
      await db.delete(lookbookAssets).where(and(eq(lookbookAssets.profileId, input.profileId), eq(lookbookAssets.id, edit.id)));
    } else {
      await db.update(lookbookAssets).set({ cropPosition: edit.cropPosition, sortOrder: edit.sortOrder }).where(and(eq(lookbookAssets.profileId, input.profileId), eq(lookbookAssets.id, edit.id)));
    }
  }
  if (validEdits.length) {
    await db.insert(profileAuditEvents).values({
      profileId: input.profileId,
      actorUserId: input.actorUserId,
      eventType: "lookbook_assets_edited",
      metadata: JSON.stringify({ editedAssetIds: validEdits.map((edit) => edit.id), removedAssetIds: validEdits.filter((edit) => edit.remove).map((edit) => edit.id) }),
      createdAt: new Date(),
    });
  }
  return { success: true as const };
}

export async function listManagementReviewers() {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  const rows = await db.select({ id: users.id, name: users.name, email: users.email }).from(users).where(eq(users.role, "admin")).orderBy(users.name);
  return rows;
}

export async function createNotificationEvent(input: { profileId?: number | null; eventType: string; recipient: string; subject: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  await db.insert(notificationEvents).values({ profileId: input.profileId ?? null, eventType: input.eventType, recipient: input.recipient, subject: input.subject, deliveryStatus: "pending" });
  const created = await db.select({ id: notificationEvents.id }).from(notificationEvents).orderBy(desc(notificationEvents.id)).limit(1);
  return created[0]?.id;
}

export async function resolveNotificationEvent(input: { id: number; success: boolean; providerMessageId?: string | null; errorDetail?: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  await db.update(notificationEvents).set({ deliveryStatus: input.success ? "sent" : "failed", providerMessageId: input.providerMessageId ?? null, errorDetail: input.errorDetail ?? null, deliveredAt: input.success ? new Date() : null }).where(eq(notificationEvents.id, input.id));
}
