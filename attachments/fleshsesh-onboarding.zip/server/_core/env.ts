export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  resendApiKey: process.env.RESEND_API_KEY ?? "",
  onboardingNotificationRecipient: process.env.ONBOARDING_NOTIFICATION_RECIPIENT ?? "models@fleshsesh.com",
  onboardingNotificationFrom: process.env.ONBOARDING_NOTIFICATION_FROM ?? "fleshsesh onboarding <onboarding@fleshsesh.com>",
};
