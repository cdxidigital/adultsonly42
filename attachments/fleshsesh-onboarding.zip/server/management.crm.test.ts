import { NOT_ADMIN_ERR_MSG } from "@shared/const";
import { beforeEach, describe, expect, it, vi } from "vitest";

const listProfilesMock = vi.hoisted(() => vi.fn());
const detailProfileMock = vi.hoisted(() => vi.fn());

vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof import("./db")>("./db");
  return { ...actual, getManagementProfiles: listProfilesMock, getManagementProfile: detailProfileMock };
});

import { appRouter } from "./routers";
import { buildManagementCsv } from "../client/src/lib/managementCsv";
import type { TrpcContext } from "./_core/context";

function createUserContext(role: "user" | "admin" = "user"): TrpcContext {
  return {
    user: {
      id: 9,
      openId: "management-reviewer",
      name: "Management reviewer",
      email: "reviewer@example.com",
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

beforeEach(() => {
  listProfilesMock.mockReset();
  detailProfileMock.mockReset();
});

describe("management CRM procedures", () => {
  it("blocks non-admin users from the management queue", async () => {
    const caller = appRouter.createCaller(createUserContext());
    await expect(caller.profile.managementList({ status: "all", search: "" })).rejects.toThrow(NOT_ADMIN_ERR_MSG);
  });

  it("allows administrators to query a filtered management queue", async () => {
    listProfilesMock.mockResolvedValue([]);
    const caller = appRouter.createCaller(createUserContext("admin"));

    await expect(caller.profile.managementList({ status: "in_review", search: "Perth" })).resolves.toEqual([]);
    expect(listProfilesMock).toHaveBeenCalledWith({ status: "in_review", search: "Perth" });
  });

  it("serializes filtered CRM rows with safe CSV quoting", () => {
    const csv = buildManagementCsv([{
      profile: { displayName: "A, Model", profileType: "Model", location: "Perth", reviewStatus: "pending_review", submittedAt: "2026-08-27T00:00:00.000Z" },
      user: { email: "a\"model@example.com" },
    }]);

    expect(csv).toContain('"A, Model","Model","Perth","a""model@example.com","Pending review"');
    expect(csv).not.toContain("\\n");
  });

  it("allows administrators to retrieve a complete profile dossier", async () => {
    detailProfileMock.mockResolvedValue({ profile: { id: 7 }, user: null, assets: [], updates: [] });
    const caller = appRouter.createCaller(createUserContext("admin"));

    await expect(caller.profile.managementDetail({ profileId: 7 })).resolves.toMatchObject({ profile: { id: 7 } });
    expect(detailProfileMock).toHaveBeenCalledWith(7);
  });
});
