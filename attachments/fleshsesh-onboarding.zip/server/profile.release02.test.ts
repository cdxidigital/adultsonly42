import { NOT_ADMIN_ERR_MSG } from "@shared/const";
import { beforeEach, describe, expect, it, vi } from "vitest";

const saveDraftMock = vi.hoisted(() => vi.fn());
const addNoteMock = vi.hoisted(() => vi.fn());
const assignReviewerMock = vi.hoisted(() => vi.fn());
const saveProfileMock = vi.hoisted(() => vi.fn());
const clearDraftMock = vi.hoisted(() => vi.fn());
const applyExistingAssetEditsMock = vi.hoisted(() => vi.fn());
const profileEditorMock = vi.hoisted(() => vi.fn());

vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof import("./db")>("./db");
  return {
    ...actual,
    saveProfileDraft: saveDraftMock,
    addProfileInternalNote: addNoteMock,
    assignProfileReviewer: assignReviewerMock,
    saveTalentProfile: saveProfileMock,
    clearProfileDraft: clearDraftMock,
    applyExistingLookbookAssetEdits: applyExistingAssetEditsMock,
    getProfileEditorData: profileEditorMock,
  };
});

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function context(role: "user" | "admin" = "user"): TrpcContext {
  return {
    user: { id: 24, openId: "release-two-user", name: "Release Two", email: "release.two@example.com", loginMethod: "manus", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

beforeEach(() => {
  saveDraftMock.mockReset();
  addNoteMock.mockReset();
  assignReviewerMock.mockReset();
  saveProfileMock.mockReset();
  clearDraftMock.mockReset();
  applyExistingAssetEditsMock.mockReset();
  profileEditorMock.mockReset();
  saveDraftMock.mockResolvedValue({ success: true });
  addNoteMock.mockResolvedValue({ success: true });
  assignReviewerMock.mockResolvedValue({ success: true });
  clearDraftMock.mockResolvedValue({ success: true });
  applyExistingAssetEditsMock.mockResolvedValue({ success: true });
  profileEditorMock.mockResolvedValue({ profile: { id: 3 }, assets: [{ id: 7 }] });
});

describe("Release 0.2 profile integrity contracts", () => {
  it("lets a signed-in member persist a compact onboarding draft", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.profile.saveDraft({ payload: JSON.stringify({ name: "Draft talent", step: 2 }) })).resolves.toEqual({ success: true });
    expect(saveDraftMock).toHaveBeenCalledWith(24, expect.stringContaining("Draft talent"));
  });

  it("persists managed portrait and look-book references inside an image-rich draft", async () => {
    const caller = appRouter.createCaller(context());
    await caller.profile.saveDraft({
      payload: JSON.stringify({ name: "Image Draft" }),
      primaryPortrait: { storageKey: "talent-profiles/24/drafts/portrait-1.jpg", imageUrl: "/manus-storage/talent-profiles/24/drafts/portrait-1.jpg" },
      lookbookImages: [{ storageKey: "talent-profiles/24/drafts/lookbook-1.jpg", imageUrl: "/manus-storage/talent-profiles/24/drafts/lookbook-1.jpg", cropPosition: "50% 50%" }],
      replaceLookbook: true,
    });
    expect(saveDraftMock).toHaveBeenCalledWith(24, expect.stringContaining("lookbook-1.jpg"));
    expect(saveDraftMock).toHaveBeenCalledWith(24, expect.stringContaining("replaceLookbook"));
  });

  it("requires a visual select when a talent-type profile is sent for review", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.profile.submit({ displayName: "No Select Model", profileType: "Model", location: "Perth, WA", availability: "Available with two weeks notice.", focusAreas: ["Editorial"], visibility: "Curated introductions", lookbookImages: [], assetMode: "replace", submitForReview: true })).rejects.toThrow("Add at least one visual select");
    expect(saveProfileMock).not.toHaveBeenCalled();
  });

  it("allows an existing visual set to be preserved on a material profile update", async () => {
    saveProfileMock.mockResolvedValue({ profile: { id: 3 }, assets: [{ id: 7 }], updates: [] });
    const caller = appRouter.createCaller(context());
    await caller.profile.submit({ displayName: "Existing Model", practiceRole: "Creative / talent", intentAreas: ["Model & talent"], energy: "Quiet confidence", profileType: "Model", location: "Perth, WA", availability: "Available for local work.", focusAreas: ["Editorial"], visibility: "Curated introductions", lookbookImages: [], assetMode: "preserve", submitForReview: false });
    expect(saveProfileMock).toHaveBeenCalledWith(24, expect.objectContaining({ lookbookAssets: [] }), expect.objectContaining({ assetMode: "preserve", submitForReview: false }));
  });

  it("forwards deliberate saved-look-book edits only after the member profile is saved", async () => {
    saveProfileMock.mockResolvedValue({ profile: { id: 3 }, assets: [{ id: 7 }], updates: [] });
    const caller = appRouter.createCaller(context());
    await caller.profile.submit({ displayName: "Existing Model", profileType: "Model", location: "Perth, WA", availability: "Available for local work.", focusAreas: ["Editorial"], visibility: "Curated introductions", lookbookImages: [], assetMode: "preserve", existingAssetEdits: [{ id: 7, cropPosition: "80% 50%", sortOrder: 1, remove: false }], submitForReview: false });
    expect(applyExistingAssetEditsMock).toHaveBeenCalledWith({ profileId: 3, actorUserId: 24, edits: [{ id: 7, cropPosition: "80% 50%", sortOrder: 1, remove: false }] });
  });

  it("blocks a preserved talent profile from removing its final visual select", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.profile.submit({ displayName: "Existing Model", profileType: "Model", location: "Perth, WA", availability: "Available for local work.", focusAreas: ["Editorial"], visibility: "Curated introductions", lookbookImages: [], assetMode: "preserve", existingAssetEdits: [{ id: 7, cropPosition: "50% 50%", sortOrder: 1, remove: true }], submitForReview: true })).rejects.toThrow("Keep at least one visual select");
    expect(saveProfileMock).not.toHaveBeenCalled();
  });

  it("blocks members from private management-note access", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.profile.addInternalNote({ profileId: 4, note: "Private casting context." })).rejects.toThrow(NOT_ADMIN_ERR_MSG);
  });

  it("writes private notes and reviewer assignments with the authenticated management actor", async () => {
    const caller = appRouter.createCaller(context("admin"));
    await caller.profile.addInternalNote({ profileId: 4, note: "Private casting context." });
    await caller.profile.assignReviewer({ profileId: 4, reviewerId: 24 });
    expect(addNoteMock).toHaveBeenCalledWith({ profileId: 4, note: "Private casting context.", authorUserId: 24 });
    expect(assignReviewerMock).toHaveBeenCalledWith({ profileId: 4, reviewerId: 24, actorUserId: 24 });
  });
});
