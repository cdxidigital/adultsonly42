import { ENV } from "./_core/env";

export const ONBOARDING_NOTIFICATION_RECIPIENT = ENV.onboardingNotificationRecipient;
export const ONBOARDING_NOTIFICATION_FROM = ENV.onboardingNotificationFrom;

type OnboardingNotification = {
  subject: string;
  text: string;
};

export type NotificationDeliveryResult = {
  success: boolean;
  providerMessageId?: string;
  errorDetail?: string;
};

export async function sendOnboardingNotification(notification: OnboardingNotification): Promise<NotificationDeliveryResult> {
  if (!ENV.resendApiKey) {
    console.warn("[Onboarding email] RESEND_API_KEY is not configured");
    return { success: false, errorDetail: "RESEND_API_KEY is not configured" };
  }

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${ENV.resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: ONBOARDING_NOTIFICATION_FROM,
        to: [ONBOARDING_NOTIFICATION_RECIPIENT],
        subject: notification.subject,
        text: notification.text,
      }),
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(`[Onboarding email] Resend rejected notification (${response.status})${detail ? `: ${detail}` : ""}`);
      return { success: false, errorDetail: detail || `Resend rejected notification (${response.status})` };
    }

    const payload = await response.json().catch(() => ({})) as { id?: string };
    return { success: true, providerMessageId: payload.id };
  } catch (error) {
    console.warn("[Onboarding email] Delivery failed:", error);
    return { success: false, errorDetail: error instanceof Error ? error.message : "Unexpected delivery error" };
  }
}

export function buildProfileSubmittedNotification(input: {
  displayName: string;
  profileType: string;
  location: string;
  availability?: string;
  focusAreas: string[];
  lookbookCount: number;
  isUpdate: boolean;
}) {
  const action = input.isUpdate ? "updated" : "submitted";
  return {
    subject: `fleshsesh profile ${action}: ${input.displayName}`,
    text: [
      `A fleshsesh talent profile has been ${action}.`,
      "",
      `Name: ${input.displayName}`,
      `Profile type: ${input.profileType}`,
      `Location: ${input.location}`,
      `Availability: ${input.availability || "Not specified"}`,
      `Focus areas: ${input.focusAreas.join(", ")}`,
      `Look-book images: ${input.lookbookCount}`,
      "",
      "Review the submission in the fleshsesh review desk.",
    ].join("\n"),
  };
}

export function buildReviewUpdatedNotification(input: {
  profileId: number;
  status: string;
  title: string;
  message: string;
}) {
  return {
    subject: `fleshsesh review update: ${input.title}`,
    text: [
      "A fleshsesh profile review status has been updated.",
      "",
      `Profile ID: ${input.profileId}`,
      `Status: ${input.status}`,
      `Update: ${input.title}`,
      `Message: ${input.message}`,
    ].join("\n"),
  };
}
