import { afterEach, describe, expect, it, vi } from "vitest";
import {
  ONBOARDING_NOTIFICATION_RECIPIENT,
  buildProfileSubmittedNotification,
  buildReviewUpdatedNotification,
  sendOnboardingNotification,
} from "./onboardingNotifications";

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

describe("onboarding notifications", () => {
  it("always targets the models review inbox", () => {
    expect(ONBOARDING_NOTIFICATION_RECIPIENT).toBe("models@fleshsesh.com");
    expect(buildProfileSubmittedNotification({
      displayName: "Test Model",
      profileType: "Model",
      location: "Perth, WA",
      focusAreas: ["Editorial"],
      lookbookCount: 2,
      isUpdate: false,
    }).subject).toContain("Test Model");
  });

  it("builds reviewer updates with the queue context", () => {
    const notification = buildReviewUpdatedNotification({
      profileId: 12,
      status: "in_review",
      title: "Profile in review",
      message: "A reviewer is assessing the profile.",
    });

    expect(notification.text).toContain("Profile ID: 12");
    expect(notification.text).toContain("in_review");
  });

  it("returns a failed delivery result when Resend rejects delivery without throwing", async () => {
    vi.stubEnv("RESEND_API_KEY", "test-key");
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("invalid sender", { status: 422 })));

    await expect(sendOnboardingNotification({ subject: "Test", text: "Test" })).resolves.toMatchObject({ success: false, errorDetail: "invalid sender" });
  });
});
