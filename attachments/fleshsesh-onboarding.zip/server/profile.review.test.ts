import { beforeEach, describe, expect, it, vi } from "vitest";
import { NOT_ADMIN_ERR_MSG } from "@shared/const";

const updateStatusMock = vi.hoisted(() => vi.fn());
const saveProfileMock = vi.hoisted(() => vi.fn());
const clearDraftMock = vi.hoisted(() => vi.fn());
const createNotificationEventMock = vi.hoisted(() => vi.fn());
const resolveNotificationEventMock = vi.hoisted(() => vi.fn());
const sendNotificationMock = vi.hoisted(() => vi.fn());

vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof import("./db")>("./db");
  return {
    ...actual,
    updateTalentProfileReviewStatus: updateStatusMock,
    saveTalentProfile: saveProfileMock,
    clearProfileDraft: clearDraftMock,
    createNotificationEvent: createNotificationEventMock,
    resolveNotificationEvent: resolveNotificationEventMock,
  };
});

vi.mock("./onboardingNotifications", async () => {
  const actual = await vi.importActual<typeof import("./onboardingNotifications")>("./onboardingNotifications");
  return { ...actual, sendOnboardingNotification: sendNotificationMock };
});

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createUserContext(role: "user" | "admin" = "user"): TrpcContext {
  return {
    user: { id: 9, openId: "profile-owner", name: "Profile owner", email: "profile@example.com", loginMethod: "manus", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

beforeEach(() => {
  updateStatusMock.mockReset();
  saveProfileMock.mockReset();
  clearDraftMock.mockReset();
  createNotificationEventMock.mockReset();
  resolveNotificationEventMock.mockReset();
  sendNotificationMock.mockReset();
  clearDraftMock.mockResolvedValue({ success: true });
  createNotificationEventMock.mockResolvedValue(31);
  resolveNotificationEventMock.mockResolvedValue(undefined);
  sendNotificationMock.mockResolvedValue({ success: true, providerMessageId: "email_123" });
});

describe("profile review updates", () => {
  it("blocks non-admin users from writing queue status updates", async () => {
    const caller = appRouter.createCaller(createUserContext());
    await expect(caller.profile.updateStatus({ profileId: 1, status: "in_review", title: "Profile review started", message: "A reviewer has opened this profile." })).rejects.toThrow(NOT_ADMIN_ERR_MSG);
  });

  it("records actor identity and a delivery event for an administrator member update", async () => {
    updateStatusMock.mockResolvedValue({ success: true, reviewUpdatedAt: new Date("2026-08-15T00:00:00.000Z") });
    const caller = appRouter.createCaller(createUserContext("admin"));

    await expect(caller.profile.updateStatus({ profileId: 1, status: "profile_ready", title: "Profile ready", message: "The profile is ready for approved introductions." })).resolves.toMatchObject({ success: true });

    expect(updateStatusMock).toHaveBeenCalledWith({ profileId: 1, status: "profile_ready", title: "Profile ready", message: "The profile is ready for approved introductions.", actorUserId: 9 });
    expect(createNotificationEventMock).toHaveBeenCalledWith(expect.objectContaining({ profileId: 1, eventType: "member_review_update" }));
    expect(resolveNotificationEventMock).toHaveBeenCalledWith(expect.objectContaining({ id: 31, success: true, providerMessageId: "email_123" }));
  });

  it("tracks a management inbox notification after an industry-partner profile submission", async () => {
    saveProfileMock.mockResolvedValue({ profile: { id: 12, reviewStatus: "pending_review" }, assets: [], updates: [{ title: "Profile submitted" }] });
    const caller = appRouter.createCaller(createUserContext());

    await caller.profile.submit({
      displayName: "Test Partner",
      practiceRole: "Industry / partner",
      intentAreas: ["Brand partnerships"],
      energy: "Quiet confidence",
      profileType: "Industry partner",
      location: "Perth, WA",
      availability: "Available with two weeks notice.",
      focusAreas: ["Creative collaboration"],
      visibility: "Curated introductions",
      lookbookImages: [],
      assetMode: "replace",
      submitForReview: true,
    });

    expect(saveProfileMock).toHaveBeenCalledWith(9, expect.objectContaining({ practiceRole: "Industry / partner", intentAreas: ["Brand partnerships"], energy: "Quiet confidence" }), expect.objectContaining({ submitForReview: true, assetMode: "replace", actorUserId: 9 }));
    expect(createNotificationEventMock).toHaveBeenCalledWith(expect.objectContaining({ profileId: 12, eventType: "profile_submitted" }));
    expect(sendNotificationMock).toHaveBeenCalledWith(expect.objectContaining({ subject: expect.stringContaining("Test Partner") }));
  });
});
