import { describe, expect, it } from "vitest";
import { updateTalentProfileReviewStatus } from "./db";

describe("review queue persistence", () => {
  it("writes the new status, timestamp, and timeline update for an existing profile", async () => {
    const writes: { profile?: Record<string, unknown>; events: Record<string, unknown>[] } = { events: [] };
    const fakeDb = {
      select: () => ({ from: () => ({ where: () => ({ limit: async () => [{ id: 41 }] }) }) }),
      update: () => ({ set: (values: Record<string, unknown>) => {
        writes.profile = values;
        return { where: async () => undefined };
      } }),
      insert: () => ({ values: async (values: Record<string, unknown>) => {
        writes.events.push(values);
      } }),
    };

    const result = await updateTalentProfileReviewStatus({
      profileId: 41,
      status: "in_review",
      title: "Profile review started",
      message: "A reviewer has opened this profile.",
    }, fakeDb as any);

    expect(result.success).toBe(true);
    expect(writes.profile).toMatchObject({ reviewStatus: "in_review" });
    expect(writes.profile?.reviewUpdatedAt).toBeInstanceOf(Date);
    expect(writes.events[0]).toMatchObject({
      profileId: 41,
      status: "in_review",
      title: "Profile review started",
      message: "A reviewer has opened this profile.",
    });
    expect(writes.events[0]?.createdAt).toBeInstanceOf(Date);
    expect(writes.events[1]).toMatchObject({ profileId: 41, eventType: "member_update_published" });
  });
});
