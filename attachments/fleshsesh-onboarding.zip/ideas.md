# Private Application — Neutral Design Direction

## Three Initial Directions

| Theme Name | Very Brief Intro | Probability |
| --- | --- | --- |
| After Hours Editorial | A deliberate blend of fashion-editorial restraint and intimate casting-room confidence, built around portraiture, black ink, and a singular hot-red signal. | 0.06 |
| Signal Garden | A light, almost botanical onboarding experience using pale mineral tones, photography fragments, and rounded sensual geometry. | 0.03 |
| Noir Relay | A sharp, high-tech black interface with red system markers and kinetic product panels, designed to feel like a private creative network. | 0.08 |

## Neutralised Direction: After Hours Editorial

### Design Movement
Contemporary **fashion editorial** meets a considered mobile-native application. The application should feel like the opening spread of an independent magazine: cinematic, sparse, and self-possessed rather than a conventional SaaS onboarding funnel.

### Core Principles
1. **Composure before decoration.** The screen uses dramatic scale, negative space, and one visual decision at a time.
2. **Intimacy with agency.** The product speaks directly and confidently, but each member always understands what happens next and why.
3. **Editorial tension.** Dense high-contrast type is paired with quiet utility type, while precise red indicators add visual urgency.
4. **Tactile hierarchy.** Cards, controls, and progress indicators feel materially present through ink-black surfaces, fine borders, and restrained motion.

### Color Philosophy
Near-black (#101010) establishes a protected, private space and lets imagery remain the emotional anchor. Bone white (#F1EFEA) softens the experience away from sterile white UI, while a subdued mineral accent (#B8AFA2) supports orientation, progress, and confirmation without acting as a signature brand cue.

### Layout Paradigm
Use a **framed editorial sequence**, not a standard centered form. On desktop, the onboarding card is intentionally offset within a cinematic cover composition, with a slim left-side chapter rail. On mobile, it becomes a near-full-bleed story card, keeping navigation at the periphery and decision-making in the thumb zone.

### Signature Elements
1. A recurring narrow **chapter rail** with an oversized numeral and vertical progress rule.
2. Fine **registration marks** and restrained corner labels inspired by contact sheets and print proofs.
3. A subtle **orbit marker** that moves between steps as a visible record of momentum.

### Interaction Philosophy
Interactions should be affirming and controlled. Answers select with a crisp snap, the step card shifts only after a deliberate action, and the member can go back at any time. Progress is concrete rather than gamified; no confetti, no artificial urgency, and no noisy microcopy.

## Style Decisions

- Every onboarding step retains a restrained adult editorial image anchor through the background media sequence and proof-file treatment; the imagery remains sensual and fashion-led rather than explicit.
- Pink is a fleshsesh proof-mark only: it is reserved for the sticker mark, active chapter and progress states, selections, and critical orientation labels.
- The chapter rail remains the primary navigation identity, carrying the oversized numeral, vertical rule, and progress signal at every breakpoint.

### Animation
Use 180–260ms custom ease-out transitions. Each step enters with a 12px upward translation and opacity fade; selected choice cards receive a 1px red edge and a minimal scale of 1.01. The orbit marker travels along the chapter rail with a spring-like but short transform. All non-essential motion is disabled for reduced-motion preferences.

### Typography System
**Bodoni Moda** is the editorial display face for identity moments, prompt headlines, and key numerals. **Manrope** is the utility face for readable labels, helper text, and interactive controls. Headlines use tight tracking and an editorial italic accent only for one word at a time; utility copy remains calm, compact, and high-contrast.

### Application Voice
Headlines are declarative and intimate; CTAs are concise and action-led; microcopy is direct, clear, and free of generic tech jargon. No brand name, proprietary mark, market position, or product-specific promise appears in the interface.

> “A profile with a point of view.”

> “Show us how you move through the world.”

### Identity Treatment
No logo, wordmark, trademark colour, or identifying symbol appears in the experience. The application is framed only with quiet utility labels and functional progress signals.

## Style Decisions

The later request to apply the **fleshsesh** identity supersedes the neutral identity-treatment note above. The official pink sticker wordmark is used as the singular primary brand cue in the chapter rail and profile-submitted confirmation, rather than repeatedly in peripheral chrome. Pink is controlled as an editorial proof mark for active progress, selected choices, and critical orientation; secondary utility icons remain muted. Decorative labels have been reduced so the prompt, progress, privacy, and navigation retain priority.
