# Authenticated Profile and Review Verification

The onboarding and dashboard UI can be checked unauthenticated, but persisted profile submission and populated review updates require a consenting authenticated account. This document records the manual verification path needed before a wider production rollout.

## Member Submission

Sign in through the dashboard or the final onboarding action. Complete the nine-stage onboarding flow with a valid height, location, general availability, and one or more JPEG, PNG, or WebP look-book assets no larger than 10 MB each. Select each preview, adjust its simple left, centre, or right crop position, and submit the profile.

Confirm that the application redirects to `/dashboard`, where the visible current status is **Pending review**, the selected visual assets appear with their chosen crop positions, and the first review-queue entry records the submission time.

## Reviewer Queue Update

An administrator can call the protected `profile.updateStatus` procedure with a profile ID, status, title, and message. Verify that the member dashboard refreshes to show the new status and the additional timeline entry. The update procedure is deliberately administrator-only; non-admin callers are rejected by the accompanying unit test.

## Responsive Checks

Repeat the submission and populated-dashboard checks at a mobile viewport. Confirm that the measurement fields stack cleanly, look-book previews remain selectable, crop controls remain reachable, and the review timeline is legible without horizontal scrolling.

## Modular Fleshsesh Dashboard Branding Check

The restored fleshsesh wordmark is wired into the authenticated dashboard sidebar header, while the separate red lips asset is used as the compact icon in collapsed navigation and mobile header contexts. Visual confirmation of that exact authenticated state remains dependent on a consenting signed-in test account in the live preview. Once such a session is available, confirm that the expanded desktop sidebar presents the wordmark with a supporting lips icon, the collapsed sidebar uses the lips icon alone, and the mobile header keeps both treatments clear and balanced.

The matching unauthenticated dashboard sign-in presentation has been checked at desktop and mobile widths. It uses the standalone wordmark as the primary logo, with the red lips icon separated below it. This preserves the same modular hierarchy used by the onboarding loader, utility bar, authenticated dashboard sidebar, and mobile header.

## Populated Dashboard Polish Check

The fleshsesh dashboard treatment now includes editorial registration lines, restrained file metadata, status-card proof marks, refined look-book frames, and a spaced review-update timeline. The shell and empty state have been checked responsively. The final live check remains to submit a real profile with an authorized test account, then confirm the populated **Pending review** status card, uploaded look-book grid, and subsequent reviewer update retain this hierarchy on desktop and mobile.

## Completed Live Verification — 19 August 2026

An authenticated profile for **Adam** was confirmed in the persisted data store with its initial **Pending review** state and **Profile submitted** queue entry. The populated dashboard was reviewed on desktop and mobile, including profile details, look-book state, status card, and review timeline.

With explicit user authorisation, the protected `profile.updateStatus` procedure then changed the profile to **In review** with the message **“Verification update — review in progress.”** The dashboard was refreshed and confirmed the new status, descriptive copy, progress treatment, and newest timeline entry across desktop and mobile views.

With separate explicit authorisation, the existing profile was re-submitted through all nine authenticated onboarding stages. The visible **Send for review** action redirected directly to `/dashboard`, restored the profile to **Pending review**, and placed **Profile updated** at the top of the review queue. The redirected dashboard was then verified at desktop and mobile widths, confirming the status card, profile snapshot, and full three-entry timeline.

## Navigation and onboarding notification refinement

The authenticated dashboard sidebar now uses the supplied fleshsesh wordmark as a link to `https://fleshsesh.com`, includes a dedicated **Visit fleshsesh.com** action, and keeps the same website route available in the mobile header. The onboarding rail and utility bar also expose the fleshsesh.com return path. Intake labels now name the actual sequence—Introduction, Practice, Interests, Energy, First impression—followed by the Look book stages for Direction, Measurements & availability, Visual selects, and Review setting.

Submission and reviewer-status events are routed server-side to `models@fleshsesh.com` through Resend. The destination and sender are server configuration values, with the requested inbox as the default. The configured Resend account currently has no verified sending domains, so live delivery is not yet available; verify a sending domain and set `ONBOARDING_NOTIFICATION_FROM` before treating email delivery as complete. Unit tests cover the Resend credential, helper payloads, and both router dispatch paths.

## Management CRM visual verification

The management queue was checked in the live preview at desktop and mobile widths. The sidebar presents the supplied fleshsesh wordmark, the Management CRM entry, and the fleshsesh.com return link. The queue supports search, status filters, filtered CSV export, submission metadata, and a clear private-review note. The profile dossier was checked on mobile with stacked overview, review controls, look-book state, and review history; the persisted Pending review badge correctly uses the pending tone.
