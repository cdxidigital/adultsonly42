# fleshsesh Product & Operating Platform Audit

**Audit date:** 27 August 2026  
**Scope:** Talent onboarding, member profile experience, management CRM, data model, authentication, notification delivery, and launch readiness.  
**Assessment basis:** Current source implementation, existing automated tests, documented manual verification, and desktop/mobile preview review. This is an implementation audit, not a legal-compliance opinion.

## Executive assessment

The application is a polished **talent-profile intake and review prototype** with an attractive editorial onboarding sequence, OAuth-backed member access, persisted profile records, look-book asset storage, a status timeline, and a new management review desk. It is credible as a controlled beta for a small internal review team. The management surface already provides the right visual starting point: authorised staff can locate a profile, inspect its submitted details and visual selects, change its review status, and export a filtered queue.

It is **not yet a complete management CRM or production-ready agency operating platform**. The main blockers are information loss in the onboarding journey, a review model that cannot distinguish member-visible updates from private management notes, undeliverable email notifications until a sending domain is verified, and missing consent, lifecycle, assignment, and opportunity-management controls. The next release should therefore protect the intake record and establish an auditable review workflow before expanding into bookings or broad automation.

> **Bottom line:** Treat the present release as `Intake + Review Desk v0.1`. The recommended next build is `Talent Record Integrity & Review Operations v0.2`, followed by `Shortlists, Opportunities & Booking Operations v0.3`.

## What is working now

| Area | Current capability | Evidence | Readiness |
| --- | --- | --- | --- |
| Editorial onboarding | Nine-stage flow covering introduction, practice, interests, energy, first impression, direction, measurements, visual selects, and visibility. | `client/src/pages/Home.tsx` | Strong experience; incomplete record capture. |
| Member identity | OAuth-protected profile dashboard with current review state, profile snapshot, look-book, and timeline. | `ProfileDashboard.tsx`; protected `profile.dashboard` procedure | Suitable for beta. |
| Visual asset capture | JPEG, PNG, and WebP look-book upload with a 10 MB per-file cap, up to four selects, and simple crop positioning. | `Home.tsx`; `routers.ts` | Useful baseline; asset governance is incomplete. |
| Management review desk | Admin-only profile queue, text search, status filter, filtered CSV export, profile dossier, and status-change control. | `ManagementCRM.tsx`; `managementList` and `managementDetail` | Useful internal MVP. |
| Authorisation | Protected member procedures and administrator-only management/review endpoints. | `server/_core/trpc.ts`; `server/management.crm.test.ts` | Baseline access control is present. |
| Review history | Status updates are timestamped and rendered to member and management timelines. | `profileReviewUpdates`; `updateTalentProfileReviewStatus` | Good foundation; lacks actor and privacy separation. |
| Technical checks | Automated tests, TypeScript, production build, and desktop/mobile CRM screenshots passed at the latest checkpoint. | Checkpoint `6fbbfbc6` | Sound regression baseline. |

## Priority gap register

| Priority | Missing capability or risk | Why it matters | Recommended implementation |
| --- | --- | --- | --- |
| **P0** | **Onboarding discards data the experience asks for.** Role, interests, energy, and the first-impression image are held in client state but are not included in the submit contract or schema. The initial image is only a local preview. | The management team cannot use several high-signal answers that the applicant believes they supplied. This weakens matching and undermines trust. | Add structured fields for `practiceRole`, `intentAreas`, `energy`, and `primaryPortraitAsset`; persist the portrait through managed storage; expose them in dashboard and CRM. Add contract tests proving round-trip persistence. |
| **P0** | **Look-book completion is optional in code, despite the experience and verification guide describing it as required.** The backend accepts `0–4` images and the front-end permits continuation with none. | A review queue can receive profiles lacking the core visual material needed by modelling, casting, or creative review. | Decide the business rule explicitly. For talent/model types, require at least one look-book asset; allow a no-image exception only for industry partners, with a stated reason. Validate on client and server. |
| **P0** | **Profile edits are destructive resubmissions.** Saving an existing profile resets status to Pending review, deletes all existing look-book assets, and replaces the profile values. | One small availability update can erase prior visual material and invalidate active reviewer work. It also creates unwanted queue churn. | Separate `saveDraft`, `memberEdit`, and `submitForReview` operations. Preserve asset records by default, support explicit add/remove/reorder, and only reset status when a material change is submitted. Store version snapshots. |
| **P0** | **No true draft/resume capability.** The interface states that details are saved locally or for the session, but the flow contains no persistent draft store. | Users can lose a lengthy application on refresh, device switch, or interrupted sign-in; the current message is inaccurate. | Implement authenticated draft persistence server-side, with an optional local pre-auth draft. Restore on re-entry and show a clear “saved” timestamp. Remove unsupported save claims until this exists. |
| **P0** | **Review updates have no privacy boundary.** A single status update and message become both the member timeline entry and the management notification. | Internal reviewer notes cannot be recorded safely; staff may accidentally expose operational commentary to applicants. | Create separate `internalNotes` and `memberUpdates` tables. Require a visibility choice on each review action. Include reviewer identity and immutable event metadata. |
| **P0** | **Email delivery is not live.** The Resend wrapper intentionally fails safely, but the configured account has no verified sending domain and delivery is not persisted or retried. | `models@fleshsesh.com` will not reliably receive onboarding or review alerts. Operational review can silently fail. | Verify a Resend domain, set `ONBOARDING_NOTIFICATION_FROM`, and execute a controlled delivery check. Add a durable notification-event/outbox record with status, provider ID, retries, and management visibility. |
| **P0** | **Fresh-account first-time submission has not been verified.** Existing re-submission and status updates were tested, but a genuinely first profile and pristine timeline remain open. | The most important user journey lacks production proof and could reveal schema, OAuth, or redirect problems. | Sign in with a fresh consenting test account, submit a valid profile, confirm one initial `Profile submitted` event, then test desktop and mobile dashboard/CRM visibility. Preserve this as release evidence. |
| **P0** | **Consent and privacy controls are absent.** There is a privacy button, but it opens a browser alert; there are no recorded terms, privacy, image-use, communications, age/eligibility, or data-retention acknowledgements. | Talent, image, and measurement data is sensitive. A production platform needs consent evidence aligned to the agency’s reviewed policy. | Obtain legal/privacy copy, then add versioned consent records, required acknowledgements, withdrawal flow, data export/deletion request pathway, and a real privacy/terms surface. Seek jurisdiction-specific advice before launch. |
| **P1** | **The CRM is a queue, not yet a relationship-management system.** It has no tags, shortlists, reviewer assignments, internal notes, reminders, next action, pipeline owner, or candidate health signals. | Management cannot coordinate multiple reviewers or turn submissions into a managed talent portfolio. | Add reviewer assignment, private notes, tags, saved shortlists, follow-up tasks, archive/withdraw states, and a “next action” field. Present queue age and ownership in the list view. |
| **P1** | **The review workflow has only four broad statuses.** There are no booking, availability, compliance, representation, or relationship stages. | Every non-ready outcome becomes a free-text status update, which makes reporting and workflow automation unreliable. | Introduce a documented state model: `draft`, `submitted`, `triage`, `reviewing`, `changes_requested`, `shortlisted`, `approved`, `inactive`, `withdrawn`, and `archived`, with allowed transitions and reason codes. |
| **P1** | **No opportunity, client, job, or booking entity exists.** | The platform cannot answer “who is right for this client brief?”, create a shortlist, request availability, or track a booking. | Add `clients`, `opportunities`, `shortlists`, `shortlistEntries`, `availabilityRequests`, and `bookings`. Link talent to roles/opportunities without exposing private data publicly. |
| **P1** | **Limited filtering and no pagination.** Search only covers display name, location, and email; all profiles load at once. There are no indexes for the management filter pattern. | The queue will become slow and hard to operate as talent volume increases. | Add database indexes for status and submission/review dates; implement server-side pagination, sorting, filter chips for type/focus/location/availability/owner, and saved views. |
| **P1** | **No record of who changed a profile or why.** Review updates do not include reviewer ID. | Accountability, handover, and conflict resolution are weak. | Add `actorUserId`, action type, before/after JSON snapshot, and immutable audit event records. Show actor and timestamp in the management dossier. |
| **P1** | **No member notification channel.** Review changes only attempt to notify the management inbox, not the profile owner. | Applicants must repeatedly open the dashboard and may miss requests for changes. | Once consent and sender verification exist, notify the member for member-visible `changes_requested`, `approved`, and booking/availability actions. Keep message sends approval-gated where a human-written message is involved. |
| **P1** | **No member-side safe edit experience.** The dashboard’s Edit action returns to a blank onboarding flow instead of loading persisted fields. | Members cannot confidently update availability or one image without resubmitting their entire record. | Build `/profile/edit` prefilled from the saved profile; provide independent asset management, review-impact disclosures, and a separate submit-for-review confirmation. |
| **P1** | **Single hard-coded admin role.** There is no reviewer/manager/owner separation, invitation workflow, or least-privilege access. | As the management team grows, any admin can do everything and there is no accountable permission model. | Replace binary roles with capability-based roles: `owner`, `manager`, `reviewer`, `talent-member`, and optionally `partner`. Add admin invitations and role-change audit events. |
| **P2** | **Asset governance is incomplete.** Uploads lack EXIF stripping, image resizing/derivative generation, malware screening, HEIC guidance, upload retry, and explicit storage-access validation. | Submitted images may be unnecessarily large, contain unwanted metadata, fail on common devices, or have inappropriate sharing characteristics. | Add server-side image normalization and metadata stripping, virus scanning where required, thumbnail generation, original/derivative policy, upload retry feedback, and an S3 ACL review. |
| **P2** | **No compliance-document or release workflow.** | Image rights, representation terms, ID/eligibility checks, usage consents, and contracts cannot be managed as records. | Add versioned documents, signed-status tracking, expiration dates, and restricted management views. Do not collect sensitive identity documents until the storage, retention, and access model is approved. |
| **P2** | **No management command view or operational metrics.** The CRM header shows only visible-profile count. | Management cannot identify aged reviews, workload, conversion, bottlenecks, or outreach effectiveness. | Create a management home with queue age, stage counts, reviewer workload, compliance gaps, and time-to-first-review. Use only aggregated operational data; avoid invented benchmarks. |
| **P2** | **No availability calendar or booking coordination.** The system stores a free-text availability field only. | The platform cannot operationalise talent availability or avoid double booking. | Add availability windows, travel radius, blackout dates, opportunity holds, and booking confirmations. Start with consented staff entry before calendar integrations. |
| **P2** | **No controlled external partner portal.** | Brands, casting teams, and production partners cannot review approved profiles through scoped access. | Add time-limited, token-scoped shortlists with watermarked asset delivery, view logging, expiry, revocation, and a clear invalid-token state. |
| **P2** | **Accessibility and inclusive capture need a formal pass.** Screens show good contrast and mobile stacking, but there is no documented keyboard, screen-reader, form-error summary, focus-order, or reduced-motion acceptance test. | Editorial interfaces can be visually strong yet difficult to complete for keyboard and assistive-technology users. | Add semantic fieldset/legend usage, inline and summary errors, focus management between steps, keyboard-only QA, accessible crop control labels, and automated accessibility checks. |
| **P2** | **Dark mode is fixed, not a user preference.** The app is set to dark theme and does not expose the requested accessible mode switch or persisted preference. | It misses a previously requested feature and limits comfort/accessibility in operational use. | Add a visible light/dark setting using the existing theme provider, persist it locally, and verify both themes for onboarding, dashboard, and CRM. |
| **P3** | **No analytics or funnel instrumentation.** | The team cannot quantify where applicants abandon onboarding, which assets fail, or how long review stages take. | Add privacy-conscious, consent-aligned event tracking for step progression, validation failures, successful submission, queue age, and state transitions. |
| **P3** | **No communication centre or approval queue.** | There is no safe way to manage drafts, replies, notes, or outreach across talent and clients. | Add a unified message record and approvals. Any AI-assisted or bulk outbound message must remain a draft until a named staff member confirms it. |

## Data-model gap map

The current schema contains `users`, `talentProfiles`, `lookbookAssets`, and `profileReviewUpdates`. That is sufficient for one mutable profile and a basic status timeline, but it cannot express the operating system needed for a multi-person talent agency.

| Domain | Current state | Required next model |
| --- | --- | --- |
| Talent identity | One profile per user, mutable in place. | `talentProfiles`, `profileVersions`, `talentTags`, `talentContacts`, `talentConsents`, `talentDocuments`. |
| Visual assets | Image URL, storage key, crop position, sort order. | `assets`, derivatives, metadata/rights status, original retention rule, approval state, and explicit visibility. |
| Review operations | Status timeline only. | `reviewAssignments`, `internalNotes`, `memberUpdates`, `auditEvents`, `tasks`, state-transition reason codes. |
| Opportunities | Not represented. | `clients`, `contacts`, `opportunities`, `roleBriefs`, `shortlists`, `shortlistEntries`, `availabilityRequests`, `bookings`. |
| Communications | A non-durable management email attempt. | `notificationEvents`, `messageThreads`, `messageDrafts`, approval status, delivery outcomes, and recipient consent. |
| Access | Binary `user`/`admin`. | Team membership and capability roles with staff invitation, audit, and least-privilege policies. |

## Recommended implementation sequence

### Release 0.2 — Talent record integrity and review operations

Make the profile trustworthy before adding more automation. This release should persist the full onboarding payload, store the hero portrait, enforce the chosen look-book rule, and provide genuine drafts/resume. It should split internal review notes from member-visible communication, attach each action to its reviewer, prevent destructive asset replacement, and introduce explicit profile lifecycle transitions. Finish by verifying a Resend sender, storing notification outcomes, and completing the fresh-account first-time submission test.

**Exit criteria:** A new consenting account can start, pause, resume, submit, and edit an application without silent data loss. Management can assign work and make a private note without revealing it to the member. A member-visible request reaches both their dashboard and a recorded delivery event. The intake record has a version history.

### Release 0.3 — Talent CRM and shortlist workflow

Convert the review desk into a usable day-to-day management workspace. Implement queues by owner and age, tags, saved shortlists, advanced filtering, archive/withdraw handling, and a management command overview. Add the client and opportunity data model, then allow staff to create a private role brief and attach talent profiles to a shortlist.

**Exit criteria:** A manager can find suitable talent by type, location, focus, availability, and status; assign a reviewer; place profiles in an opportunity shortlist; and track the next action without using an external spreadsheet.

### Release 0.4 — Booking, compliance, and controlled sharing

Add structured availability, booking holds, release/document status, and token-scoped partner shortlists. This is the point to assess legal, privacy, retention, insurance, and contractual requirements with qualified advisers, because the platform will be coordinating personal data and commercial relationships more directly.

**Exit criteria:** Staff can issue a controlled partner-facing shortlist, request or record availability, preserve asset rights/consent records, and audit access to sensitive profile material.

### Release 0.5 — Intelligence and management reporting

Add dashboard metrics, queue-time indicators, applicant funnel signals, and approval-gated messaging support. Any automated matching or suggested action should be explainable to staff, use the minimum necessary data, and never send a client- or talent-facing message without named human approval.

## Immediate build order

| Order | Work item | Dependency | Outcome |
| --- | --- | --- | --- |
| 1 | Fix onboarding record fidelity, portrait persistence, and look-book rule. | Schema migration and storage workflow. | No hidden data loss. |
| 2 | Add persisted draft/resume and prefilled member edit route. | Work item 1. | Members can return safely. |
| 3 | Split private notes from member updates; add reviewer actor/audit events. | Schema migration. | Safe internal review. |
| 4 | Verify Resend sender and create durable notification events. | Verified domain and approved sender. | Observable communications. |
| 5 | Run fresh-account first-time verification. | Fresh consenting account. | Release-critical proof. |
| 6 | Add management assignments, tags, queue age, and advanced filters. | Work items 1–3. | Functional talent CRM. |
| 7 | Model clients, opportunities, and shortlists. | Work item 6. | Operational matching workflow. |

## Audit conclusion

The platform has the right foundation and an appropriately distinctive fleshsesh presentation. The next value is not another visual layer; it is a **reliable talent record, safe review collaboration, and a traceable route from profile to opportunity**. The proposed sequence delivers that without overbuilding bookings, partner portals, or automation before the underlying consent, data, and review model is dependable.

## Evidence sources

| Source | Audit use |
| --- | --- |
| `client/src/pages/Home.tsx` | Onboarding steps, client-state-only fields, upload/validation behaviour, and submission payload. |
| `client/src/pages/ProfileDashboard.tsx` | Member dashboard capabilities and edit/re-entry behaviour. |
| `client/src/pages/ManagementCRM.tsx` | Current management queue, dossier, review update, filtering, and export surface. |
| `server/routers.ts` | Exposed member/admin contracts and server-side asset handling. |
| `server/db.ts` | Profile update semantics, asset deletion, review history, search, and retrieval model. |
| `drizzle/schema.ts` | Current database entities, profile uniqueness, and available audit fields. |
| `server/onboardingNotifications.ts` | Delivery wrapper and supported email event scope. |
| `docs/profile-review-verification.md` | Live verification evidence and unresolved sender/fresh-account dependencies. |
