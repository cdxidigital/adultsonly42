export type MintMembershipInput = {
  memberId: string;
  passNumber: string;
};

export type MintResult = {
  tokenId: string;
  transactionHash: string;
};

export interface BlockchainService {
  mintMembership(input: MintMembershipInput): Promise<MintResult>;
}

export const mockBlockchainService: BlockchainService = {
  async mintMembership({ passNumber }) {
    const tokenId = passNumber.replace(/\D/g, "") || "1";
    const transactionHash = `0xmockfleshpass${tokenId.padStart(8, "0")}`;

    return { tokenId, transactionHash };
  },
};