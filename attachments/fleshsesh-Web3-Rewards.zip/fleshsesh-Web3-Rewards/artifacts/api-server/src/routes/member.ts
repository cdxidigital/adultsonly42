import { and, desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  ClaimFleshPassBody,
  ConnectWalletBody,
  GetMemberActivityResponse,
  GetMemberDashboardResponse,
  GetMemberWalletResponse,
  GetRewardsCatalogResponse,
  RedeemRewardBody,
  RedeemRewardResponse,
} from "@workspace/api-zod";
import {
  activityEntries,
  fleshMembers,
  memberships,
  nftClaims,
  pointsAccounts,
  redemptions,
  rewards,
  wallets,
  db,
} from "@workspace/db";
import { mockBlockchainService } from "../lib/blockchain";

const router: IRouter = Router();
const DEMO_MEMBER_ID = "member_demo_01";
let seedPromise: Promise<void> | undefined;

async function ensureSeedData() {
  if (!seedPromise) {
    seedPromise = seedDatabase();
  }
  await seedPromise;
}

async function seedDatabase() {
  const existing = await db
    .select({ id: fleshMembers.id })
    .from(fleshMembers)
    .where(eq(fleshMembers.id, DEMO_MEMBER_ID))
    .limit(1);

  if (existing.length > 0) {
    return;
  }

  await db.transaction(async (tx) => {
    await tx.insert(fleshMembers).values({
      id: DEMO_MEMBER_ID,
      displayName: "Alex Morgan",
      username: "@alexm",
      initials: "AM",
      streak: 12,
      collectibles: 3,
      memberSince: "September 2024",
    });
    await tx.insert(pointsAccounts).values({
      memberId: DEMO_MEMBER_ID,
      available: 4280,
      pending: 500,
      lifetimeEarned: 11640,
      lifetimeSpent: 7360,
    });
    await tx.insert(memberships).values({
      memberId: DEMO_MEMBER_ID,
      tier: "vip",
      label: "VIP member",
      passNumber: "FLESH PASS #004281",
      eligibleToClaim: true,
      claimed: false,
      utility: ["Early access to drops", "15% creator store boost", "VIP campaign access"],
    });
    await tx.insert(wallets).values({
      memberId: DEMO_MEMBER_ID,
      status: "embedded",
      walletType: "Embedded wallet",
      address: "0x7A3b...4281",
      network: "Base Sepolia",
      provider: "FLESH Wallet",
    });
    await tx.insert(rewards).values([
      {
        id: "reward-platform-credit",
        name: "$5 platform credit",
        description: "Use it toward your next fleshsesh purchase.",
        pointsCost: 500,
        category: "Platform",
        accent: "pink",
      },
      {
        id: "reward-feature-unlock",
        name: "Premium feature unlock",
        description: "Unlock one month of a selected premium feature.",
        pointsCost: 1000,
        category: "Access",
        accent: "violet",
      },
      {
        id: "reward-creator-boost",
        name: "Creator profile boost",
        description: "Give a creator you support a visibility boost.",
        pointsCost: 750,
        category: "Creator",
        accent: "orange",
      },
      {
        id: "reward-limited-collectible",
        name: "Limited collectible",
        description: "Claim a campaign collectible for your collection.",
        pointsCost: 1500,
        category: "Collectible",
        accent: "blue",
      },
    ]);
    await tx.insert(activityEntries).values([
      {
        id: "activity-monthly-membership",
        memberId: DEMO_MEMBER_ID,
        kind: "membership",
        label: "Monthly membership",
        amount: 250,
        state: "available",
        createdAt: new Date("2026-09-14T08:30:00.000Z"),
      },
      {
        id: "activity-academy-completion",
        memberId: DEMO_MEMBER_ID,
        kind: "academy",
        label: "Academy completion",
        amount: 500,
        state: "available",
        createdAt: new Date("2026-09-11T14:20:00.000Z"),
      },
      {
        id: "activity-creator-boost",
        memberId: DEMO_MEMBER_ID,
        kind: "redemption",
        label: "Creator profile boost",
        amount: -750,
        state: "redeemed",
        createdAt: new Date("2026-09-08T10:00:00.000Z"),
      },
      {
        id: "activity-referral",
        memberId: DEMO_MEMBER_ID,
        kind: "referral",
        label: "Referral reward",
        amount: 750,
        state: "available",
        createdAt: new Date("2026-09-03T18:45:00.000Z"),
      },
    ]);
  });
}

router.use(async (_req, res, next) => {
  try {
    await ensureSeedData();
    next();
  } catch (error) {
    res.status(500).json({ error: "Rewards data is temporarily unavailable." });
  }
});

router.get("/me/dashboard", async (_req, res) => {
  const [member] = await db.select().from(fleshMembers).where(eq(fleshMembers.id, DEMO_MEMBER_ID));
  const [points] = await db.select().from(pointsAccounts).where(eq(pointsAccounts.memberId, DEMO_MEMBER_ID));
  const [membership] = await db.select().from(memberships).where(eq(memberships.memberId, DEMO_MEMBER_ID));
  const [wallet] = await db.select().from(wallets).where(eq(wallets.memberId, DEMO_MEMBER_ID));

  const data = GetMemberDashboardResponse.parse({
    member: {
      id: member.id,
      displayName: member.displayName,
      username: member.username,
      initials: member.initials,
    },
    points: {
      available: points.available,
      pending: points.pending,
      lifetimeEarned: points.lifetimeEarned,
      lifetimeSpent: points.lifetimeSpent,
    },
    membership: {
      tier: membership.tier,
      label: membership.label,
      passNumber: membership.passNumber,
      eligibleToClaim: membership.eligibleToClaim,
      claimed: membership.claimed,
      tokenId: membership.tokenId,
      utility: membership.utility,
    },
    wallet: {
      status: wallet.status,
      walletType: wallet.walletType,
      address: wallet.address,
      network: wallet.network,
      provider: wallet.provider,
    },
    stats: {
      streak: member.streak,
      collectibles: member.collectibles,
      memberSince: member.memberSince,
    },
  });
  res.json(data);
});

router.get("/me/activity", async (_req, res) => {
  const rows = await db
    .select()
    .from(activityEntries)
    .where(eq(activityEntries.memberId, DEMO_MEMBER_ID))
    .orderBy(desc(activityEntries.createdAt))
    .limit(20);
  res.json(GetMemberActivityResponse.parse(rows.map((row) => ({
    id: row.id,
    kind: row.kind,
    label: row.label,
    amount: row.amount,
    state: row.state,
    createdAt: row.createdAt.toISOString(),
  }))));
});

router.get("/rewards/catalog", async (_req, res) => {
  const rows = await db.select().from(rewards);
  res.json(GetRewardsCatalogResponse.parse(rows));
});

router.get("/me/wallet", async (_req, res) => {
  const [wallet] = await db.select().from(wallets).where(eq(wallets.memberId, DEMO_MEMBER_ID));
  res.json(GetMemberWalletResponse.parse(wallet));
});

router.post("/wallet/connect", async (req, res) => {
  const input = ConnectWalletBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: "Enter a valid wallet address and network." });
    return;
  }
  const [wallet] = await db
    .update(wallets)
    .set({
      status: "connected",
      walletType: "External wallet",
      address: input.data.address,
      network: input.data.network,
      provider: "Connected by member",
    })
    .where(eq(wallets.memberId, DEMO_MEMBER_ID))
    .returning();
  res.json(GetMemberWalletResponse.parse(wallet));
});

router.post("/rewards/redeem", async (req, res) => {
  const input = RedeemRewardBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: "Choose a reward to redeem." });
    return;
  }

  const existing = await db
    .select()
    .from(redemptions)
    .where(and(eq(redemptions.memberId, DEMO_MEMBER_ID), eq(redemptions.idempotencyKey, input.data.idempotencyKey)))
    .limit(1);
  if (existing[0]) {
    const [points] = await db.select().from(pointsAccounts).where(eq(pointsAccounts.memberId, DEMO_MEMBER_ID));
    res.json(RedeemRewardResponse.parse({
      redemptionId: existing[0].id,
      rewardId: existing[0].rewardId,
      pointsCost: existing[0].pointsCost,
      remainingBalance: points.available,
      message: "This reward was already redeemed.",
    }));
    return;
  }

  const [reward] = await db
    .select()
    .from(rewards)
    .where(and(eq(rewards.id, input.data.rewardId), eq(rewards.available, true)));
  if (!reward) {
    res.status(400).json({ error: "That reward is no longer available." });
    return;
  }

  const result = await db.transaction(async (tx) => {
    const [points] = await tx
      .select()
      .from(pointsAccounts)
      .where(eq(pointsAccounts.memberId, DEMO_MEMBER_ID))
      .for("update");
    if (!points || points.available < reward.pointsCost) {
      return null;
    }

    const redemptionId = `redemption_${Date.now()}`;
    await tx
      .update(pointsAccounts)
      .set({
        available: points.available - reward.pointsCost,
        lifetimeSpent: points.lifetimeSpent + reward.pointsCost,
      })
      .where(eq(pointsAccounts.memberId, DEMO_MEMBER_ID));
    await tx.insert(redemptions).values({
      id: redemptionId,
      memberId: DEMO_MEMBER_ID,
      rewardId: reward.id,
      pointsCost: reward.pointsCost,
      idempotencyKey: input.data.idempotencyKey,
    });
    await tx.insert(activityEntries).values({
      id: `activity_${redemptionId}`,
      memberId: DEMO_MEMBER_ID,
      kind: "redemption",
      label: reward.name,
      amount: -reward.pointsCost,
      state: "redeemed",
    });
    return {
      redemptionId,
      rewardId: reward.id,
      pointsCost: reward.pointsCost,
      remainingBalance: points.available - reward.pointsCost,
    };
  });

  if (!result) {
    res.status(400).json({ error: "You do not have enough FLESH Points for that reward." });
    return;
  }

  res.json(RedeemRewardResponse.parse({
    ...result,
    message: `${reward.name} is ready for you.`,
  }));
});

router.post("/nft/claim", async (req, res) => {
  const input = ClaimFleshPassBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: "Claim request is missing an idempotency key." });
    return;
  }

  const existing = await db
    .select()
    .from(nftClaims)
    .where(and(eq(nftClaims.memberId, DEMO_MEMBER_ID), eq(nftClaims.idempotencyKey, input.data.idempotencyKey)))
    .limit(1);
  if (existing[0]) {
    res.json({
      status: "already_claimed",
      tokenId: existing[0].tokenId,
      transactionHash: existing[0].transactionHash,
      message: "Your FLESH Pass is already in your collection.",
    });
    return;
  }

  const [membership] = await db.select().from(memberships).where(eq(memberships.memberId, DEMO_MEMBER_ID));
  if (membership.claimed && membership.tokenId) {
    res.json({
      status: "already_claimed",
      tokenId: membership.tokenId,
      transactionHash: "0xmockfleshpassalreadyclaimed",
      message: "Your FLESH Pass is already in your collection.",
    });
    return;
  }
  if (!membership.eligibleToClaim) {
    res.status(400).json({ error: "Your account is not eligible to claim a FLESH Pass yet." });
    return;
  }

  const mint = await mockBlockchainService.mintMembership({
    memberId: DEMO_MEMBER_ID,
    passNumber: membership.passNumber,
  });
  const claimId = `claim_${Date.now()}`;
  await db.transaction(async (tx) => {
    await tx.insert(nftClaims).values({
      id: claimId,
      memberId: DEMO_MEMBER_ID,
      tokenId: mint.tokenId,
      transactionHash: mint.transactionHash,
      idempotencyKey: input.data.idempotencyKey,
    });
    await tx
      .update(memberships)
      .set({ claimed: true, tokenId: mint.tokenId })
      .where(eq(memberships.memberId, DEMO_MEMBER_ID));
  });

  res.json({
    status: "minted",
    tokenId: mint.tokenId,
    transactionHash: mint.transactionHash,
    message: "Your FLESH Pass has been added to your collection.",
  });
});

export default router;