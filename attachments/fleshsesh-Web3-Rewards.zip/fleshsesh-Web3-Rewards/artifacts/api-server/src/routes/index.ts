import { Router, type IRouter } from "express";
import healthRouter from "./health";
import memberRouter from "./member";

const router: IRouter = Router();

router.use(healthRouter);
router.use(memberRouter);

export default router;
