import { AlertTriangle, ArrowRight, Check, Coins, Copy, RefreshCw, Sparkles, WalletCards } from 'lucide-react';
import { useState, type ReactNode } from 'react';
import { Link } from 'wouter';

export function SectionHeading({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return <div className="mb-5 flex items-end justify-between gap-4"><div>{eyebrow && <div className="mono-font mb-2 text-[10px] font-medium uppercase tracking-[.18em] text-muted-foreground">{eyebrow}</div>}<h2 className="display-font text-2xl font-bold tracking-[-.035em] text-foreground md:text-[28px]">{title}</h2></div>{action}</div>;
}

export function PageIntro({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="mb-9 flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><div className="mono-font mb-3 text-[10px] font-medium uppercase tracking-[.2em] text-[hsl(var(--chart-2))]">{eyebrow}</div><h1 className="display-font text-4xl font-bold tracking-[-.055em] md:text-[48px]">{title}</h1>{description && <p className="mt-3 max-w-[580px] text-sm leading-6 text-muted-foreground">{description}</p>}</div>{action}</div>;
}

export function Button({ children, variant = 'primary', className = '', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'outline' | 'soft' | 'quiet' }) {
  const variants = {
    primary: 'bg-primary text-primary-foreground hover:translate-y-[-1px] hover:shadow-md',
    outline: 'border border-border bg-card text-foreground hover:border-primary/35 hover:bg-secondary',
    soft: 'bg-accent text-accent-foreground hover:translate-y-[-1px] hover:shadow-md',
    quiet: 'text-muted-foreground hover:bg-secondary hover:text-foreground',
  };
  return <button {...props} className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-45 ${variants[variant]} ${className}`} />;
}

export function QueryState({ loading, error, onRetry, children }: { loading: boolean; error: boolean; onRetry: () => void; children: ReactNode }) {
  if (loading) return <div className="grid gap-4 md:grid-cols-3"><div className="skeleton-shimmer h-44 rounded-2xl" /><div className="skeleton-shimmer h-44 rounded-2xl" /><div className="skeleton-shimmer h-44 rounded-2xl" /></div>;
  if (error) return <div className="rounded-2xl border border-[hsl(var(--destructive)/.25)] bg-[hsl(var(--destructive)/.06)] p-7 text-center"><AlertTriangle className="mx-auto mb-3 text-destructive" size={22} /><p className="font-semibold">We could not open your room.</p><p className="mt-1 text-sm text-muted-foreground">Give it another moment, then try again.</p><Button onClick={onRetry} variant="outline" className="mt-5"><RefreshCw size={15} />Try again</Button></div>;
  return children;
}

export function StatusPill({ label, tone = 'neutral' }: { label: string; tone?: 'good' | 'pending' | 'neutral' | 'bad' }) {
  const styles = { good: 'bg-[hsl(var(--chart-2)/.12)] text-[hsl(var(--chart-2))]', pending: 'bg-accent/25 text-[hsl(34_65%_37%)]', neutral: 'bg-secondary text-muted-foreground', bad: 'bg-destructive/10 text-destructive' };
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.08em] ${styles[tone]}`}><span className={`h-1.5 w-1.5 rounded-full ${tone === 'good' ? 'bg-[hsl(var(--chart-2))]' : tone === 'bad' ? 'bg-destructive' : tone === 'pending' ? 'bg-[hsl(34_65%_37%)]' : 'bg-muted-foreground'}`} />{label}</span>;
}

export function Points({ amount, className = '' }: { amount: number; className?: string }) {
  return <span className={`mono-font tabular-nums ${className}`}>{amount.toLocaleString()}</span>;
}

export function CopyAddress({ address }: { address: string }) {
  const [copied, setCopied] = useState(false);
  const short = `${address.slice(0, 6)}…${address.slice(-4)}`;
  const copy = async () => { await navigator.clipboard?.writeText(address); setCopied(true); window.setTimeout(() => setCopied(false), 1400); };
  return <button type="button" onClick={copy} data-testid="button-copy-address" className="mono-font inline-flex items-center gap-2 text-xs text-muted-foreground transition hover:text-foreground">{copied ? <Check size={14} className="text-[hsl(var(--chart-2))]" /> : <Copy size={14} />} {copied ? 'Copied' : short}</button>;
}

export function QuickLink({ href, icon: Icon, label, detail }: { href: string; icon: typeof ArrowRight; label: string; detail: string }) {
  return <Link href={href} data-testid={`quick-link-${label.toLowerCase().replaceAll(' ', '-')}`} className="group flex items-center justify-between rounded-2xl border border-border bg-card p-4 transition duration-200 hover:-translate-y-0.5 hover:border-primary/25 hover:shadow-md"><span className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-foreground"><Icon size={16} /></span><span><span className="block text-sm font-semibold">{label}</span><span className="mt-0.5 block text-xs text-muted-foreground">{detail}</span></span></span><ArrowRight size={16} className="text-muted-foreground transition group-hover:translate-x-1 group-hover:text-foreground" /></Link>;
}

export const activityIcon = (kind: string) => kind.toLowerCase().includes('redeem') ? <Sparkles size={16} /> : kind.toLowerCase().includes('wallet') ? <WalletCards size={16} /> : kind.toLowerCase().includes('claim') ? <Check size={16} /> : <Coins size={16} />;
export const stateTone = (state: string): 'good' | 'pending' | 'neutral' | 'bad' => state === 'available' || state === 'redeemed' ? 'good' : state === 'pending' ? 'pending' : 'bad';
export const stateLabel = (state: string) => state.replace('_', ' ');
export const formatDate = (value: string) => new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(value));
export const formatRelative = (value: string) => { const diff = Date.now() - new Date(value).getTime(); const hours = Math.floor(diff / 3600000); if (hours < 1) return 'Just now'; if (hours < 24) return `${hours}h ago`; const days = Math.floor(hours / 24); return days < 7 ? `${days}d ago` : formatDate(value); };