import { getHealthCheckQueryKey, useHealthCheck } from '@workspace/api-client-react';
import { ArrowUpRight, CircleHelp, Command, LayoutGrid, Sparkles, WalletCards, Activity, Settings2, Gem, Menu, X } from 'lucide-react';
import { useState, type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';

const navItems = [
  { href: '/', label: 'Overview', icon: LayoutGrid },
  { href: '/rewards', label: 'Rewards', icon: Sparkles },
  { href: '/collection', label: 'Collection', icon: Gem },
  { href: '/wallet', label: 'Wallet', icon: WalletCards },
  { href: '/activity', label: 'Activity', icon: Activity },
];

function NavLink({ href, label, icon: Icon, onNavigate }: { href: string; label: string; icon: typeof LayoutGrid; onNavigate?: () => void }) {
  const [location] = useLocation();
  const active = href === '/' ? location === '/' : location.startsWith(href);
  return (
    <Link
      href={href}
      onClick={onNavigate}
      data-testid={`link-${label.toLowerCase()}`}
      className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200 ${
        active ? 'bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--sidebar-foreground))] shadow-sm' : 'text-[hsl(var(--sidebar-foreground)/.58)] hover:bg-[hsl(var(--sidebar-accent)/.65)] hover:text-[hsl(var(--sidebar-foreground))]'
      }`}
    >
      <Icon size={17} strokeWidth={active ? 2.4 : 1.8} className={active ? 'text-[hsl(var(--sidebar-primary))]' : 'opacity-80'} />
      <span>{label}</span>
      {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[hsl(var(--sidebar-primary))]" />}
    </Link>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey() } });
  const [location] = useLocation();
  const pageName = navItems.find((item) => item.href !== '/' && location.startsWith(item.href))?.label ?? 'Overview';

  return (
    <div className="grain min-h-[100dvh] bg-background text-foreground">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[248px] flex-col bg-sidebar px-5 py-6 md:flex">
        <Link href="/" data-testid="link-brand" className="mb-10 flex items-center gap-3 px-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))]">
            <Command size={19} strokeWidth={2.5} />
          </span>
          <span className="display-font text-[21px] font-bold tracking-[-.04em] text-[hsl(var(--sidebar-foreground))]">fleshsesh</span>
        </Link>
        <div className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.18em] text-[hsl(var(--sidebar-foreground)/.34)]">Member room</div>
        <nav className="flex flex-col gap-1">
          {navItems.map((item) => <NavLink key={item.href} {...item} />)}
        </nav>
        <div className="mt-auto">
          <Link href="/settings" data-testid="link-settings" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-[hsl(var(--sidebar-foreground)/.58)] transition hover:bg-[hsl(var(--sidebar-accent)/.65)] hover:text-[hsl(var(--sidebar-foreground))]">
            <Settings2 size={17} strokeWidth={1.8} />
            <span>Settings</span>
          </Link>
          <div className="mt-5 border-t border-[hsl(var(--sidebar-border))] pt-5">
            <div className="flex items-center gap-2 px-3 text-[11px] text-[hsl(var(--sidebar-foreground)/.4)]">
              <span className={`h-1.5 w-1.5 rounded-full ${health.isError ? 'bg-red-300' : 'bg-[hsl(var(--sidebar-primary))]'}`} />
              {health.isError ? 'Room is resting' : 'Room is open'}
            </div>
            <a href="https://fleshsesh.com" target="_blank" rel="noreferrer" data-testid="link-fleshsesh-site" className="mt-3 flex items-center gap-2 px-3 text-xs text-[hsl(var(--sidebar-foreground)/.52)] transition hover:text-[hsl(var(--sidebar-primary))]">
              Visit fleshsesh.com <ArrowUpRight size={13} />
            </a>
          </div>
        </div>
      </aside>

      <div className="md:pl-[248px]">
        <header className="sticky top-0 z-30 flex h-[76px] items-center justify-between border-b border-border/70 bg-background/90 px-5 backdrop-blur-xl md:px-10">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setMobileOpen(true)} data-testid="button-open-menu" className="grid h-9 w-9 place-items-center rounded-lg border border-border md:hidden">
              <Menu size={18} />
            </button>
            <div className="hidden text-xs font-medium text-muted-foreground md:block">Your private rewards room</div>
            <div className="text-sm font-semibold md:hidden">{pageName}</div>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/settings" data-testid="link-header-settings" className="hidden items-center gap-2 text-xs font-medium text-muted-foreground transition hover:text-foreground sm:flex">
              <CircleHelp size={16} />
              Help & preferences
            </Link>
            <Link href="/" data-testid="link-header-profile" className="grid h-9 w-9 place-items-center rounded-full bg-primary text-xs font-bold text-primary-foreground">FS</Link>
          </div>
        </header>
        <main className="mx-auto w-full max-w-[1420px] px-5 py-7 pb-24 md:px-10 md:py-10 md:pb-12">{children}</main>
      </div>

      <nav className="fixed inset-x-3 bottom-3 z-30 flex items-center justify-around rounded-2xl border border-border bg-card/95 p-2 shadow-lg backdrop-blur-xl md:hidden">
        {navItems.slice(0, 4).map(({ href, label, icon: Icon }) => {
          const active = href === '/' ? location === '/' : location.startsWith(href);
          return <Link href={href} key={href} data-testid={`mobile-link-${label.toLowerCase()}`} className={`grid min-w-[56px] place-items-center gap-1 rounded-xl px-2 py-1.5 text-[9px] font-semibold ${active ? 'bg-secondary text-foreground' : 'text-muted-foreground'}`}><Icon size={17} /><span>{label}</span></Link>;
        })}
      </nav>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 bg-primary/40 backdrop-blur-sm md:hidden" onClick={() => setMobileOpen(false)}>
          <div className="flex h-full w-[280px] flex-col bg-sidebar px-5 py-6 shadow-2xl" onClick={(event) => event.stopPropagation()}>
            <div className="flex items-center justify-between">
              <Link href="/" onClick={() => setMobileOpen(false)} data-testid="mobile-link-brand" className="flex items-center gap-3">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-[hsl(var(--sidebar-primary))] text-[hsl(var(--sidebar-primary-foreground))]"><Command size={19} /></span>
                <span className="display-font text-[21px] font-bold text-[hsl(var(--sidebar-foreground))]">fleshsesh</span>
              </Link>
              <button type="button" onClick={() => setMobileOpen(false)} data-testid="button-close-menu" className="text-[hsl(var(--sidebar-foreground)/.65)]"><X size={20} /></button>
            </div>
            <nav className="mt-10 flex flex-col gap-1">{navItems.map((item) => <NavLink key={item.href} {...item} onNavigate={() => setMobileOpen(false)} />)}</nav>
            <Link href="/settings" onClick={() => setMobileOpen(false)} data-testid="mobile-link-settings" className="mt-auto flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-[hsl(var(--sidebar-foreground)/.6)]"><Settings2 size={17} />Settings</Link>
          </div>
        </div>
      )}
    </div>
  );
}