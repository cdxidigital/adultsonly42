# fleshsesh Web3

fleshsesh Web3 is a member rewards room where users can view FLESH Points, redeem utility perks, manage wallet state, and claim a FLESH Pass.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/fleshsesh-web3/` — React/Vite member application and routes.
- `artifacts/api-server/src/routes/member.ts` — member dashboard, rewards, wallet, and FLESH Pass API.
- `lib/api-spec/openapi.yaml` — source of truth for the typed member API.
- `lib/db/src/schema/fleshsesh.ts` — Drizzle schema for member, points, rewards, wallet, activity, redemption, and claim data.
- `artifacts/api-server/src/lib/blockchain.ts` — service boundary with the local mock blockchain adapter.

## Architecture decisions

- The first vertical slice uses a server-owned demo member and persistent PostgreSQL data so the product is functional before external auth and wallet infrastructure are selected.
- Blockchain behavior is isolated behind `BlockchainService`; the first adapter is deterministic and mock-only, with no production chain or token economics enabled.
- Points remain integer off-chain ledger values; redemption and pass claims use idempotency keys and server-side writes.
- The member UI intentionally presents Web3 as membership utility and ownership, not as trading or speculation.

## Product

- Members see available, pending, and lifetime FLESH Points.
- Members can browse a rewards shelf, filter by category, and redeem eligible rewards.
- Members can claim a FLESH Pass through the mock blockchain adapter.
- Members can review activity, inspect the embedded wallet, and connect an external wallet address.
- Collection, settings, and collectibles surfaces are present with clear coming-soon states.

## User preferences

The product should preserve lowercase `fleshsesh` styling and keep the experience premium, utility-focused, and Web2-first.

## Gotchas

- API and frontend workflows must be restarted after backend or run-command changes.
- `pnpm run typecheck` is the canonical workspace check; the frontend build needs `PORT` and `BASE_PATH` when run outside its managed workflow.
- Run API codegen after changing `lib/api-spec/openapi.yaml`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
