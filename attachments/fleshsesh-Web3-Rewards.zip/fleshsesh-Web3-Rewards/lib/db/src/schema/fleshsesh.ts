import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const fleshMembers = pgTable("flesh_members", {
  id: text("id").primaryKey(),
  displayName: text("display_name").notNull(),
  username: text("username").notNull(),
  initials: text("initials").notNull(),
  streak: integer("streak").notNull().default(0),
  collectibles: integer("collectibles").notNull().default(0),
  memberSince: text("member_since").notNull(),
});

export const pointsAccounts = pgTable("points_accounts", {
  memberId: text("member_id")
    .primaryKey()
    .references(() => fleshMembers.id),
  available: integer("available").notNull().default(0),
  pending: integer("pending").notNull().default(0),
  lifetimeEarned: integer("lifetime_earned").notNull().default(0),
  lifetimeSpent: integer("lifetime_spent").notNull().default(0),
});

export const memberships = pgTable("memberships", {
  memberId: text("member_id")
    .primaryKey()
    .references(() => fleshMembers.id),
  tier: text("tier").notNull(),
  label: text("label").notNull(),
  passNumber: text("pass_number").notNull(),
  eligibleToClaim: boolean("eligible_to_claim").notNull().default(false),
  claimed: boolean("claimed").notNull().default(false),
  tokenId: text("token_id"),
  utility: jsonb("utility").$type<string[]>().notNull().default([]),
});

export const wallets = pgTable("wallets", {
  memberId: text("member_id")
    .primaryKey()
    .references(() => fleshMembers.id),
  status: text("status").notNull().default("embedded"),
  walletType: text("wallet_type").notNull(),
  address: text("address"),
  network: text("network").notNull(),
  provider: text("provider").notNull(),
});

export const rewards = pgTable("rewards", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  pointsCost: integer("points_cost").notNull(),
  category: text("category").notNull(),
  available: boolean("available").notNull().default(true),
  accent: text("accent").notNull(),
});

export const activityEntries = pgTable("activity_entries", {
  id: text("id").primaryKey(),
  memberId: text("member_id")
    .notNull()
    .references(() => fleshMembers.id),
  kind: text("kind").notNull(),
  label: text("label").notNull(),
  amount: integer("amount").notNull(),
  state: text("state").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const redemptions = pgTable("redemptions", {
  id: text("id").primaryKey(),
  memberId: text("member_id")
    .notNull()
    .references(() => fleshMembers.id),
  rewardId: text("reward_id")
    .notNull()
    .references(() => rewards.id),
  pointsCost: integer("points_cost").notNull(),
  idempotencyKey: text("idempotency_key").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const nftClaims = pgTable("nft_claims", {
  id: text("id").primaryKey(),
  memberId: text("member_id")
    .notNull()
    .references(() => fleshMembers.id),
  tokenId: text("token_id").notNull(),
  transactionHash: text("transaction_hash").notNull(),
  idempotencyKey: text("idempotency_key").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertFleshMemberSchema = createInsertSchema(fleshMembers);
export const insertPointsAccountSchema = createInsertSchema(pointsAccounts);
export const insertMembershipSchema = createInsertSchema(memberships);
export const insertWalletSchema = createInsertSchema(wallets);
export const insertRewardSchema = createInsertSchema(rewards);
export const insertActivityEntrySchema = createInsertSchema(activityEntries);
export const insertRedemptionSchema = createInsertSchema(redemptions);
export const insertNftClaimSchema = createInsertSchema(nftClaims);

export type FleshMember = z.infer<typeof insertFleshMemberSchema>;
export type PointsAccount = z.infer<typeof insertPointsAccountSchema>;
export type Membership = z.infer<typeof insertMembershipSchema>;
export type Wallet = z.infer<typeof insertWalletSchema>;
export type Reward = z.infer<typeof insertRewardSchema>;