---
name: Generated client DOM types
description: TypeScript configuration needed by the generated React API client.
---

The generated Orval fetch client uses `Headers.entries()`, so the API client library must include both `dom` and `dom.iterable` in its TypeScript `lib` settings.

**Why:** The workspace's generated client typechecked only after `dom.iterable` was enabled; without it, every codegen run surfaced `Headers.entries()` errors even though the generated code was valid in the browser.

**How to apply:** If generated client typechecking starts failing on `Headers.entries()`, check the library tsconfig before editing generated output.